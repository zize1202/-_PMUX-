onerror {quit -code 2 -f}
run -all
puts "OBSERVED low_default.q=[examine -radix binary /interface_probe/u_low_default/q]"
puts "OBSERVED low_default.devclrn=[examine -radix binary /interface_probe/u_low_default/devclrn]"
puts "OBSERVED low_default.devpor=[examine -radix binary /interface_probe/u_low_default/devpor]"
puts "OBSERVED high_default.q=[examine -radix binary /interface_probe/u_high_default/q]"
puts "OBSERVED high_default.devclrn=[examine -radix binary /interface_probe/u_high_default/devclrn]"
puts "OBSERVED high_default.devpor=[examine -radix binary /interface_probe/u_high_default/devpor]"
puts "OBSERVED low_explicit.q=[examine -radix binary /interface_probe/u_low_explicit/q]"
puts "OBSERVED low_explicit.devclrn=[examine -radix binary /interface_probe/u_low_explicit/devclrn]"
puts "OBSERVED low_explicit.devpor=[examine -radix binary /interface_probe/u_low_explicit/devpor]"
puts "OBSERVED high_explicit.q=[examine -radix binary /interface_probe/u_high_explicit/q]"
puts "OBSERVED high_explicit.devclrn=[examine -radix binary /interface_probe/u_high_explicit/devclrn]"
puts "OBSERVED high_explicit.devpor=[examine -radix binary /interface_probe/u_high_explicit/devpor]"
quit -code 0 -f
