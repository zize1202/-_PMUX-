`timescale 1ns/1ps
module interface_probe;
wire low_default, high_default, low_explicit, high_explicit;
dffeas #(.power_up("low"),.is_wysiwyg("TRUE")) u_low_default (.d(1'b0),.clk(1'b0),.ena(1'b0),.clrn(1'b1),.prn(1'b1),.aload(1'b0),.asdata(1'b0),.sclr(1'b0),.sload(1'b0),.q(low_default));
dffeas #(.power_up("high"),.is_wysiwyg("TRUE")) u_high_default (.d(1'b0),.clk(1'b0),.ena(1'b0),.clrn(1'b1),.prn(1'b1),.aload(1'b0),.asdata(1'b0),.sclr(1'b0),.sload(1'b0),.q(high_default));
dffeas #(.power_up("low"),.is_wysiwyg("TRUE")) u_low_explicit (.d(1'b0),.clk(1'b0),.ena(1'b0),.clrn(1'b1),.prn(1'b1),.aload(1'b0),.asdata(1'b0),.sclr(1'b0),.sload(1'b0),.devclrn(1'b1),.devpor(1'b1),.q(low_explicit));
dffeas #(.power_up("high"),.is_wysiwyg("TRUE")) u_high_explicit (.d(1'b0),.clk(1'b0),.ena(1'b0),.clrn(1'b1),.prn(1'b1),.aload(1'b0),.asdata(1'b0),.sclr(1'b0),.sload(1'b0),.devclrn(1'b1),.devpor(1'b1),.q(high_explicit));
initial begin #3; $stop; end
endmodule
