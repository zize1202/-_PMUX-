r30 厂家 DFFEAS 附加复测

这是本次 r30 的新运行，未使用 r29 九例结果改标签。
官方九例共 40,684 个采样点全部通过，每例 samples.csv 与冻结 r30 逐字节一致；失配、X/Z输出及契约失败均为0。逐一核对实际643个参考/候选物理FF在时间0的最终Q值，全部一致且为确定0/1。test2无FF。
九例在run_001仅执行了一批正常流程，没有失败后换模型/改刺激重跑。本次不改原设计、受限模型、旧七图、原代码或冻结ZIP。

实际厂家模型与边界
厂家库来自本机现有安装 D:/Downloads/modelsim_ae/altera/verilog/altera，原_info元数据为QuartusII11.0Build157SJ、Model Technology、OV;L;6.6d;45；实际仿真器是ModelSim SE-64 10.4。
日志确实加载altera.dffeas和PRIM_GDFF_LOW，test4同时加载PRIM_GDFF_HIGH；没有编译或加载自写work.dffeas。
每例只编译冻结reference/candidate导出和原testbench。LUT仍为冻结网表导出的实际真值表表达式。因此结论称“厂家DFFEAS复测”，不是完整厂家门级、布局布线、SDF时序仿真或厂家全域形式证明。

唯一导出适配
冻结r30已显式保留真实power_up和is_wysiwyg，本次均不改。原十端口含真实SCLR/SLOAD/ASDATA及原有clock/ENA/CLRN等逐一对应JSON。
只给厂商额外的devclrn/devpor连接1，表示器件正常工作、全局清零与全局上电复位不激活。原RTL外部输入、复位和clock未固定或改动；原刺激、testbench、run.do和采样判定逐字节保留。
ADAPTER_AUDIT.json保存全部实例前后行，撤去两个全局端口补充即可逐字节恢复冻结Verilog。
此前真实接口探针发现未连接devclrn/devpor时为Z，不是默认1；该接口证据按原字节复制至interface_probe并用INTERFACE_PROBE_SOURCE.json标明来源，未将它声称为新r30九例数据。

隔离与不可变输入
本次使用新的厂家库副本。原厂家库全部122个文件、全局modelsim.ini和冻结r30的364个清单文件保持原SHA。
ModelSim仅自动改副本_info并增加dffeas/PRIM_GDFF_LOW/HIGH的六个asm64/rw64缓存文件；副本所有原始DAT/DBS/VHD及其他原文件（除缓存索引_info）不变。
旧vendor_dffeas_probe/run_002的ERROR原报告完整保留，不改成PASS。本批从开始就明示允许并核验自动缓存刷新，使用独立报告。全部新临时目录、WLF、VCD和编译输出在D盘；未改全局环境或许可证。

与项目七图的关系
原七图仍是冻结r30受限模型运行的真实VCD重绘，不改称厂家库波形。本附加批使用实际厂家FF得到完全相同的有效输出采样，并保留自己的VCD/WLF和日志。它补充模型可信度，不替代无候选端zinit的完整源逻辑零形式等价证明。
该结论限定既定二值控制激励及正常器件全局条件，不延伸到X/Z控制、亚稳态、异常器件全局状态或硬件延迟。

检索
CASE_SUMMARY.csv：九例计数。
run_001/report.json：工具SHA、实际命令、库身份、每例加载与PASS、不可变输入和缓存审计。
run_001/<案例>/vsim.exe.log：厂家Loading和TCL_FINAL。
run_001/<案例>/samples.csv、simulation.vcd、simulation.wlf：本次新数据。
run_001/<案例>/ADAPTER_AUDIT.json、INITIAL_Q_AUDIT.json：逐实例接口和时间0 Q。
INDEPENDENT_AUDIT.json：另一套只读检查器/正则VCD解析器的复核；不声称另一个人复核。
FILE_MANIFEST.json、PACKAGE_AUDIT.json：最终文件与ZIP读回审计。

复跑（必须新输出目录）
python -X utf8 D:/PMUX_20261102_delivery/research/r30_vendor_ff/run_batch.py --source D:/PMUX_20261102_delivery/research/r30_modelsim --out D:/PMUX_20261102_delivery/research/r30_vendor_ff/replay_001
需本机原厂库、ModelSim与合法许可；更换安装位置须调整脚本LIB/BIN/BASE_INI并重新核对库身份。不得以自写模型替代厂家库仍沿用本报告。
证据ZIP不包括厂家库二进制、编译库/缓存、仿真器或许可文件。
