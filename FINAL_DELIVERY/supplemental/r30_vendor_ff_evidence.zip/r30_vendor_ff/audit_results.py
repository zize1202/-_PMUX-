"""Read-only second audit; does not import the batch runner or its VCD parser."""
from pathlib import Path
import csv, datetime, hashlib, json, re

ROOT=Path(__file__).resolve().parent
RUN=ROOT/'run_001'
SOURCE=Path('D:/PMUX_20261102_delivery/research/r30_modelsim')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def inv(p):return {q.relative_to(p).as_posix():{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(p.rglob('*')) if q.is_file()}

def initial(file, paths):
    chunks=[]
    with file.open(encoding='utf-8') as f:
        for line in f:
            if line.startswith('#') and int(line.strip()[1:])>0:break
            chunks.append(line)
    text=''.join(chunks);header,body=text.split('$enddefinitions $end',1)
    scopes=[]; ids={}
    for directive in re.findall(r'\$(?:scope|upscope|var)\b.*?\$end',header,re.S):
        fields=directive.split()
        if fields[0]=='$scope':scopes.append(fields[2])
        elif fields[0]=='$upscope':scopes.pop()
        else:
            path='/'.join(scopes+[fields[4]])
            if path in paths:
                assert fields[2]=='1';ids.setdefault(fields[3],[]).append(path)
    values={}
    for match in re.finditer(r'(?m)^(?:([01xXzZ])(\S+)|b([01xXzZ]+)\s+(\S+))\s*$',body):
        value=match[1] or match[3];code=match[2] or match[4]
        for path in ids.get(code,[]):values[path]=value.lower()
    assert set(values)==set(paths)
    return values

def main():
    r=read(RUN/'report.json');old=read(SOURCE/'simulation_report.json');man=read(SOURCE/'FILE_MANIFEST.json')
    assert r['status']=='PASS' and r['complete'] and r['all_nine_pass']
    assert len(r['cases'])==9 and len({c['id'] for c in r['cases']})==9
    assert r['source_manifest_sha256']==sha(SOURCE/'FILE_MANIFEST.json')
    for row in man['files']:assert sha(SOURCE/row['path'])==row['sha256']
    byid={c['id']:c for c in old['cases']};cases=[]
    for item in r['cases']:
        cid=item['id'];d=RUN/cid;c=byid[cid];paths=[];count=0
        for arm in ('reference','candidate'):
            assert (d/('frozen_'+arm+'.v')).read_bytes()==(SOURCE/cid/(arm+'.v')).read_bytes()
            assert (d/(arm+'.post_abc9.json')).read_bytes()==(SOURCE/cid/(arm+'.post_abc9.json')).read_bytes()
            converted=(d/(arm+'.v')).read_bytes()
            reverse=converted.replace(b", .devclrn(1'b1), .devpor(1'b1)",b'')
            assert reverse==(SOURCE/cid/(arm+'.v')).read_bytes()
            m=read(d/(arm+'.post_abc9.json'))['modules'][c['top']]
            for i,(_,cell) in enumerate(m['cells'].items()):
                if cell['type']!='dffeas':continue
                count+=1;name='ff_'+str(i);paths.append('zero_'+cid+'_tb/'+arm+'/'+name+'/q')
                instance=re.search(r'dffeas #\(.*?\)\s+'+name+r'\s*\(.*?\);',converted.decode()).group()
                assert '.is_wysiwyg("'+cell['parameters']['is_wysiwyg']+'")' in instance
                assert '.power_up("'+cell['parameters']['power_up']+'")' in instance
                assert ".devclrn(1'b1)" in instance and ".devpor(1'b1)" in instance
                for port,bits in cell['connections'].items():
                    assert len(bits)==1
                    v='n'+str(bits[0]) if isinstance(bits[0],int) else "1'b"+bits[0]
                    assert '.'+port+'('+v+')' in instance
            assert not re.search(rb'\bmodule\s+dffeas\b',converted)
        for name in ('testbench.sv','stimulus.hex','run.do','stimulus_manifest.json'):
            assert (d/name).read_bytes()==(SOURCE/cid/name).read_bytes()
        assert (d/'samples.csv').read_bytes()==(SOURCE/cid/'samples.csv').read_bytes()
        rows=list(csv.DictReader((d/'samples.csv').open()));assert len(rows)==c['expected_checks']
        assert all(all(row[k]=='0' for k in ('mismatch','unknown_output','contract_failed')) for row in rows)
        actual=initial(d/'simulation.vcd',paths);expected=initial(SOURCE/cid/'simulation.vcd',paths)
        assert actual==expected and all(v in ('0','1') for v in actual.values())
        assert actual==read(d/'INITIAL_Q_AUDIT.json')['vendor_values']
        log=(d/'vsim.exe.log').read_text(errors='replace');assert 'Loading work.dffeas' not in log
        assert not count or 'Loading altera.dffeas' in log
        assert not re.search(r'(?mi)^# \*\* (?:Error|Fatal)',log)
        assert re.search(r'TCL_FINAL failed=0 finished=1 checked='+str(len(rows))+r' contract_failed=0',log)
        compile_command=item['commands'][1]['argv'];assert compile_command[-3:]==['reference.v','candidate.v','testbench.sv']
        ini=(d/'modelsim.ini').read_text();assert 'altera = '+(RUN/'vendor_altera').as_posix() in ini
        for command in item['commands']:assert command['returncode']==0
        cases.append({'id':cid,'checked':len(rows),'identical_frozen_csv':True,'ff_initial_values_reparsed':len(actual),'all_actual_design_pins_and_parameters_preserved':True,'passed':True})
    before=r['library_before'];library=Path(r['vendor_library']);copy=inv(RUN/'vendor_altera')
    assert inv(library)==before
    assert all(copy.get(k)==v for k,v in before.items() if k!='_info')
    assert set(before)<=set(copy)
    assert all(Path(k).name in ('verilog.asm64','verilog.rw64') for k in set(copy)-set(before))
    assert sha('D:/Downloads/modelsim.ini')==r['base_ini_sha256']
    original_probe=ROOT.parent/'vendor_dffeas_probe/run_002/report.json';assert read(original_probe)['status']=='ERROR'
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,
            'scope':'Separate read-only checker and regex VCD parser; not an independent human reviewer. Vendor FF finite-sample re-test only.',
            'run_report_sha256':sha(RUN/'report.json'),'auditor_sha256':sha(__file__),
            'cases':cases,'total_checked':sum(c['checked'] for c in cases),'total_initial_ff_q_verified':sum(c['ff_initial_values_reparsed'] for c in cases),
            'original_vendor_files_verified':len(before),'all_original_ir_unchanged':True,'global_ini_unchanged':True,
            'frozen_r30_files_verified':len(man['files']),'original_probe_error_preserved_sha256':sha(original_probe)}
    assert result['total_checked']==40684 and result['total_initial_ff_q_verified']==sum(c['ff_instances'] for c in r['cases'])
    (ROOT/'INDEPENDENT_AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
