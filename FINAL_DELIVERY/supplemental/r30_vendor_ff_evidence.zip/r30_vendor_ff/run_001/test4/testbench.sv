`timescale 1ns/1ps
module zero_test4_tb;
parameter integer EXPECTED=4092;
reg clk=0;
reg reset_n=1;
reg ena=0;
reg [4:0] datain=0;
wire [5:0] reference_dataout;
wire [5:0] candidate_dataout;
wire reference_only_5b;
wire candidate_only_5b;
wire reference_datain_5bis7;
wire candidate_datain_5bis7;
wire reference_data_dp;
wire candidate_data_dp;
wire reference_data_dn;
wire candidate_data_dn;
reference_dut reference(.clk(clk), .reset_n(reset_n), .ena(ena), .datain(datain), .dataout(reference_dataout), .only_5b(reference_only_5b), .datain_5bis7(reference_datain_5bis7), .data_dp(reference_data_dp), .data_dn(reference_data_dn));
wire [9:0] reference_outputs = {reference_data_dn, reference_data_dp, reference_datain_5bis7, reference_only_5b, reference_dataout};
candidate_dut candidate(.clk(clk), .reset_n(reset_n), .ena(ena), .datain(datain), .dataout(candidate_dataout), .only_5b(candidate_only_5b), .datain_5bis7(candidate_datain_5bis7), .data_dp(candidate_data_dp), .data_dn(candidate_data_dn));
wire [9:0] candidate_outputs = {candidate_data_dn, candidate_data_dp, candidate_datain_5bis7, candidate_only_5b, candidate_dataout};
wire mismatch=(reference_outputs !== candidate_outputs);
wire unknown_output=((^reference_outputs === 1'bx) || (^candidate_outputs === 1'bx));
integer checked=0, failed=0, cycle=-1, sample=0, phase=0, contract_failed=0, expected_only5b=0, fh;
reg finished=0;
reg [6:0] vectors[0:1361];
task compare_outputs;
begin
  checked=checked+1;
  if (mismatch || unknown_output) failed=failed+1;
  if ((phase==0 && (reference_outputs !== 0 || candidate_outputs !== 0)) || (phase<3 && ((reference_only_5b !== expected_only5b[0]) || (candidate_only_5b !== expected_only5b[0])))) begin
    contract_failed=contract_failed+1; failed=failed+1;
    $display("INITIALIZATION_CONTRACT_FAILED time=%0t phase=%0d ref=%h candidate=%h expected_only5b=%0d",$time,phase,reference_outputs,candidate_outputs,expected_only5b);
  end
  $fdisplay(fh,"%0t,%0d,%0d,%0d,%h,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d",$time,phase,cycle,sample,reference_outputs,candidate_outputs,mismatch,unknown_output,contract_failed,reset_n,clk,reference_only_5b,candidate_only_5b);
end
endtask
initial begin
  fh=$fopen("samples.csv","w");
  $fdisplay(fh,"time_ps,phase,cycle,sample,reference_hex,candidate_hex,mismatch,unknown_output,contract_failed,reset_n,clk,reference_only_5b,candidate_only_5b");
  $readmemh("stimulus.hex",vectors);
  #1; sample=0; compare_outputs;
  #4; sample=1; compare_outputs;
  #5; reset_n=0; phase=1; expected_only5b=1;
  #1; sample=2; compare_outputs;
  #4; sample=3; compare_outputs;
  #5; reset_n=1; phase=2;
  #1; sample=4; compare_outputs;
  #4; sample=5; compare_outputs;
  #1; // Separate the final prelude sample from the next input change in VCD time.
  phase=3;
  for(cycle=0;cycle<1362;cycle=cycle+1) begin
    reset_n=vectors[cycle][0 +: 1];
    ena=vectors[cycle][1 +: 1];
    datain=vectors[cycle][2 +: 5];
    #1; sample=1; compare_outputs;
    #3; clk=1;
    #1; sample=2; compare_outputs;
    #4; clk=0;
    #1; sample=3; compare_outputs;
  end
  finished=1;
  $display("ZERO_RESULT case=test4 checked=%0d expected=%0d failed=%0d contract_failed=%0d finished=%0d cycles=%0d seed=20261104 time_ps=%0t",checked,EXPECTED,failed,contract_failed,finished,cycle,$time);
  $fclose(fh);
  #10; $stop;
end
endmodule
