`timescale 1ns/1ps
module zero_test2_tb;
parameter integer EXPECTED=4196;
reg clk=0;
reg a=0;
reg b=0;
reg c=0;
reg d=0;
reg [4:0] dataa=0;
reg [4:0] datab=0;
reg [4:0] datac=0;
reg [4:0] datad=0;
wire [4:0] reference_out;
wire [4:0] candidate_out;
reference_dut reference(.clk(clk), .a(a), .b(b), .c(c), .d(d), .dataa(dataa), .datab(datab), .datac(datac), .datad(datad), .out(reference_out));
wire [4:0] reference_outputs = {reference_out};
candidate_dut candidate(.clk(clk), .a(a), .b(b), .c(c), .d(d), .dataa(dataa), .datab(datab), .datac(datac), .datad(datad), .out(candidate_out));
wire [4:0] candidate_outputs = {candidate_out};
wire mismatch=(reference_outputs !== candidate_outputs);
wire unknown_output=((^reference_outputs === 1'bx) || (^candidate_outputs === 1'bx));
integer checked=0, failed=0, cycle=-1, sample=0, phase=0, contract_failed=0, expected_only5b=0, fh;
reg finished=0;
reg [23:0] vectors[0:1397];
task compare_outputs;
begin
  checked=checked+1;
  if (mismatch || unknown_output) failed=failed+1;
  $fdisplay(fh,"%0t,%0d,%0d,%0d,%h,%h,%0d,%0d,%0d",$time,phase,cycle,sample,reference_outputs,candidate_outputs,mismatch,unknown_output,contract_failed);
end
endtask
initial begin
  fh=$fopen("samples.csv","w");
  $fdisplay(fh,"time_ps,phase,cycle,sample,reference_hex,candidate_hex,mismatch,unknown_output,contract_failed");
  $readmemh("stimulus.hex",vectors);
  #1; sample=0; compare_outputs;
  #4; sample=1; compare_outputs;
  #20;
  #1; // Separate the final prelude sample from the next input change in VCD time.
  phase=3;
  for(cycle=0;cycle<1398;cycle=cycle+1) begin
    a=vectors[cycle][0 +: 1];
    b=vectors[cycle][1 +: 1];
    c=vectors[cycle][2 +: 1];
    d=vectors[cycle][3 +: 1];
    dataa=vectors[cycle][4 +: 5];
    datab=vectors[cycle][9 +: 5];
    datac=vectors[cycle][14 +: 5];
    datad=vectors[cycle][19 +: 5];
    #1; sample=1; compare_outputs;
    #3; clk=1;
    #1; sample=2; compare_outputs;
    #4; clk=0;
    #1; sample=3; compare_outputs;
  end
  finished=1;
  $display("ZERO_RESULT case=test2 checked=%0d expected=%0d failed=%0d contract_failed=%0d finished=%0d cycles=%0d seed=20261102 time_ps=%0t",checked,EXPECTED,failed,contract_failed,finished,cycle,$time);
  $fclose(fh);
  #10; $stop;
end
endmodule
