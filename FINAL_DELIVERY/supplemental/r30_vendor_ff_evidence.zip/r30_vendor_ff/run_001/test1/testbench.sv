`timescale 1ns/1ps
module zero_test1_tb;
parameter integer EXPECTED=5594;
reg clock=0;
reg reset=0;
reg valid=0;
reg [15:0] I0=0;
reg [15:0] I1=0;
reg [15:0] I2=0;
reg [15:0] I3=0;
reg [15:0] I4=0;
reg [15:0] I5=0;
reg [15:0] I6=0;
reg [15:0] I7=0;
reg [15:0] Q0=0;
reg [15:0] Q1=0;
reg [15:0] Q2=0;
reg [15:0] Q3=0;
reg [15:0] Q4=0;
reg [15:0] Q5=0;
reg [15:0] Q6=0;
reg [15:0] Q7=0;
wire reference_por6_out;
wire candidate_por6_out;
wire reference_inter0007_out;
wire candidate_inter0007_out;
wire [11:0] reference_inter0008_out;
wire [11:0] candidate_inter0008_out;
wire [11:0] reference_inter0009_out;
wire [11:0] candidate_inter0009_out;
reference_dut reference(.clock(clock), .reset(reset), .valid(valid), .I0(I0), .I1(I1), .I2(I2), .I3(I3), .I4(I4), .I5(I5), .I6(I6), .I7(I7), .Q0(Q0), .Q1(Q1), .Q2(Q2), .Q3(Q3), .Q4(Q4), .Q5(Q5), .Q6(Q6), .Q7(Q7), .por6_out(reference_por6_out), .inter0007_out(reference_inter0007_out), .inter0008_out(reference_inter0008_out), .inter0009_out(reference_inter0009_out));
wire [25:0] reference_outputs = {reference_inter0009_out, reference_inter0008_out, reference_inter0007_out, reference_por6_out};
candidate_dut candidate(.clock(clock), .reset(reset), .valid(valid), .I0(I0), .I1(I1), .I2(I2), .I3(I3), .I4(I4), .I5(I5), .I6(I6), .I7(I7), .Q0(Q0), .Q1(Q1), .Q2(Q2), .Q3(Q3), .Q4(Q4), .Q5(Q5), .Q6(Q6), .Q7(Q7), .por6_out(candidate_por6_out), .inter0007_out(candidate_inter0007_out), .inter0008_out(candidate_inter0008_out), .inter0009_out(candidate_inter0009_out));
wire [25:0] candidate_outputs = {candidate_inter0009_out, candidate_inter0008_out, candidate_inter0007_out, candidate_por6_out};
wire mismatch=(reference_outputs !== candidate_outputs);
wire unknown_output=((^reference_outputs === 1'bx) || (^candidate_outputs === 1'bx));
integer checked=0, failed=0, cycle=-1, sample=0, phase=0, contract_failed=0, expected_only5b=0, fh;
reg finished=0;
reg [257:0] vectors[0:1863];
task compare_outputs;
begin
  checked=checked+1;
  if (mismatch || unknown_output) failed=failed+1;
  $fdisplay(fh,"%0t,%0d,%0d,%0d,%h,%h,%0d,%0d,%0d",$time,phase,cycle,sample,reference_outputs,candidate_outputs,mismatch,unknown_output,contract_failed);
end
endtask
initial begin
  fh=$fopen("samples.csv","w");
  $fdisplay(fh,"time_ps,phase,cycle,sample,reference_hex,candidate_hex,mismatch,unknown_output,contract_failed");
  $readmemh("stimulus.hex",vectors);
  #1; sample=0; compare_outputs;
  #4; sample=1; compare_outputs;
  #20;
  #1; // Separate the final prelude sample from the next input change in VCD time.
  phase=3;
  for(cycle=0;cycle<1864;cycle=cycle+1) begin
    reset=vectors[cycle][0 +: 1];
    valid=vectors[cycle][1 +: 1];
    I0=vectors[cycle][2 +: 16];
    I1=vectors[cycle][18 +: 16];
    I2=vectors[cycle][34 +: 16];
    I3=vectors[cycle][50 +: 16];
    I4=vectors[cycle][66 +: 16];
    I5=vectors[cycle][82 +: 16];
    I6=vectors[cycle][98 +: 16];
    I7=vectors[cycle][114 +: 16];
    Q0=vectors[cycle][130 +: 16];
    Q1=vectors[cycle][146 +: 16];
    Q2=vectors[cycle][162 +: 16];
    Q3=vectors[cycle][178 +: 16];
    Q4=vectors[cycle][194 +: 16];
    Q5=vectors[cycle][210 +: 16];
    Q6=vectors[cycle][226 +: 16];
    Q7=vectors[cycle][242 +: 16];
    #1; sample=1; compare_outputs;
    #3; clock=1;
    #1; sample=2; compare_outputs;
    #4; clock=0;
    #1; sample=3; compare_outputs;
  end
  finished=1;
  $display("ZERO_RESULT case=test1 checked=%0d expected=%0d failed=%0d contract_failed=%0d finished=%0d cycles=%0d seed=20261101 time_ps=%0t",checked,EXPECTED,failed,contract_failed,finished,cycle,$time);
  $fclose(fh);
  #10; $stop;
end
endmodule
