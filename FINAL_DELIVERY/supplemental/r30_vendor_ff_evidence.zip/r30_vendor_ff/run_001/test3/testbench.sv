`timescale 1ns/1ps
module zero_test3_tb;
parameter integer EXPECTED=4064;
reg clk=0;
reg cs=0;
reg sr_in=0;
wire [7:0] reference_gpioout;
wire [7:0] candidate_gpioout;
wire reference_sr_out;
wire candidate_sr_out;
reference_dut reference(.clk(clk), .cs(cs), .sr_in(sr_in), .gpioout(reference_gpioout), .sr_out(reference_sr_out));
wire [8:0] reference_outputs = {reference_sr_out, reference_gpioout};
candidate_dut candidate(.clk(clk), .cs(cs), .sr_in(sr_in), .gpioout(candidate_gpioout), .sr_out(candidate_sr_out));
wire [8:0] candidate_outputs = {candidate_sr_out, candidate_gpioout};
wire mismatch=(reference_outputs !== candidate_outputs);
wire unknown_output=((^reference_outputs === 1'bx) || (^candidate_outputs === 1'bx));
integer checked=0, failed=0, cycle=-1, sample=0, phase=0, contract_failed=0, expected_only5b=0, fh;
reg finished=0;
reg [1:0] vectors[0:1353];
task compare_outputs;
begin
  checked=checked+1;
  if (mismatch || unknown_output) failed=failed+1;
  $fdisplay(fh,"%0t,%0d,%0d,%0d,%h,%h,%0d,%0d,%0d",$time,phase,cycle,sample,reference_outputs,candidate_outputs,mismatch,unknown_output,contract_failed);
end
endtask
initial begin
  fh=$fopen("samples.csv","w");
  $fdisplay(fh,"time_ps,phase,cycle,sample,reference_hex,candidate_hex,mismatch,unknown_output,contract_failed");
  $readmemh("stimulus.hex",vectors);
  #1; sample=0; compare_outputs;
  #4; sample=1; compare_outputs;
  #20;
  #1; // Separate the final prelude sample from the next input change in VCD time.
  phase=3;
  for(cycle=0;cycle<1354;cycle=cycle+1) begin
    cs=vectors[cycle][0 +: 1];
    sr_in=vectors[cycle][1 +: 1];
    #1; sample=1; compare_outputs;
    #3; clk=1;
    #1; sample=2; compare_outputs;
    #4; clk=0;
    #1; sample=3; compare_outputs;
  end
  finished=1;
  $display("ZERO_RESULT case=test3 checked=%0d expected=%0d failed=%0d contract_failed=%0d finished=%0d cycles=%0d seed=20261103 time_ps=%0t",checked,EXPECTED,failed,contract_failed,finished,cycle,$time);
  $fclose(fh);
  #10; $stop;
end
endmodule
