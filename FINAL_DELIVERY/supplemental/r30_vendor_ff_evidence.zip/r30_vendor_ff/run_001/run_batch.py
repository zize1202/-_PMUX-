"""Re-test frozen r30 endpoints using the installed vendor DFFEAS library.

No local DFFEAS implementation is compiled. Only vendor-global normal-device
pins are added. Existing actual JSON is_wysiwyg/power_up parameters are retained.
The frozen testbench, stimuli, sampling decisions and ten design pins are exact.
"""
from pathlib import Path
import argparse, csv, datetime, hashlib, json, os, re, shutil, subprocess, time

HERE = Path(__file__).resolve().parent
DEFAULT_SOURCE = Path('D:/PMUX_20261102_delivery/research/r30_modelsim')
LIB = Path('D:/Downloads/modelsim_ae/altera/verilog/altera')
BIN = Path('D:/Downloads/win64')
BASE_INI = Path('D:/Downloads/modelsim.ini')

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, x): Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def inventory(p):
    return {v.relative_to(p).as_posix(): {'sha256':sha(v), 'bytes':v.stat().st_size}
            for v in sorted(p.rglob('*')) if v.is_file()}

def audit_cache(before, copied):
    after=inventory(copied)
    changed=[k for k,v in before.items() if after.get(k)!=v]
    added=sorted(set(after)-set(before)); removed=sorted(set(before)-set(after))
    ok=set(changed)<={'_info'} and not removed and all(Path(p).name in ('verilog.asm64','verilog.rw64') for p in added)
    return {'passed':ok,'changed_original_files':changed,'added_files':added,'removed_files':removed,
            'original_ir_unchanged':all(after.get(k)==v for k,v in before.items() if k!='_info'),'after':after}

def adapt(raw, module):
    original=raw.decode('utf-8'); text=original; instances=[]
    for index,(name,c) in enumerate(module['cells'].items()):
        if c['type']!='dffeas': continue
        p=c['parameters']; assert set(p)=={'power_up','is_wysiwyg'}
        assert p['power_up'] in ('low','high') and p['is_wysiwyg']=='TRUE'
        line=next(v for v in original.splitlines() if re.search(r'\bff_'+str(index)+r'\s*\(',v))
        assert line.startswith('dffeas #(') and line.endswith(');')
        for pin,bits in c['connections'].items():
            assert len(bits)==1
            bit=bits[0]; expr='n'+str(bit) if isinstance(bit,int) else "1'b"+bit
            assert '.'+pin+'('+expr+')' in line,(name,pin)
        parameters='#(.power_up("'+p['power_up']+'"), .is_wysiwyg("'+p['is_wysiwyg']+'"))'
        assert line.count(parameters)==1
        replacement=line[:-2]+", .devclrn(1'b1), .devpor(1'b1));"
        assert text.count(line)==1; text=text.replace(line,replacement)
        assert replacement.replace(", .devclrn(1'b1), .devpor(1'b1));",');')==line
        instances.append({'instance':'ff_'+str(index),'cell':name,'power_up':p['power_up'],
                          'is_wysiwyg':p['is_wysiwyg'],'original_line':line,'adapted_line':replacement})
    restored=text
    for row in instances: restored=restored.replace(row['adapted_line'],row['original_line'])
    assert restored.encode('utf-8')==raw
    assert not re.search(r'\bmodule\s+dffeas\b',text)
    return text.encode('utf-8'),instances

def initial_q_values(vcd, top, all_instances):
    wanted={top+'/'+arm+'/'+row['instance']+'/q' for arm,rows in all_instances.items() for row in rows}
    codes={}; scope=[]; values={}; header=True
    with vcd.open(encoding='utf-8',errors='strict') as f:
        for line in f:
            s=line.strip()
            if header:
                parts=s.split()
                if s.startswith('$scope '): scope.append(parts[2])
                elif s.startswith('$upscope '): scope.pop()
                elif s.startswith('$var '):
                    path='/'.join(scope+[parts[4]])
                    if path in wanted: codes.setdefault(parts[3],[]).append(path)
                elif s.startswith('$enddefinitions'): header=False
                continue
            if s.startswith('#'):
                if int(s[1:])>0: break
                continue
            if s and s[0] in '01xXzZ':
                for path in codes.get(s[1:],[]): values[path]=s[0].lower()
            elif s.startswith('b'):
                val,code=s[1:].split()
                for path in codes.get(code,[]): values[path]=val.lower()
    assert set(values)==wanted,('missing initial FF Q values',sorted(wanted-set(values)))
    return values

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--source',type=Path,default=DEFAULT_SOURCE)
    ap.add_argument('--out',type=Path,required=True); args=ap.parse_args()
    source=args.source.resolve(); out=args.out.resolve()
    if out.exists(): ap.error('Refusing to overwrite evidence')
    original=read(source/'simulation_report.json'); manifest=read(source/'FILE_MANIFEST.json')
    assert original['all_nine_pass'] and original['total_checked']==40684
    for row in manifest['files']: assert sha(source/row['path'])==row['sha256']
    probe=read(HERE/'interface_probe/report.json'); assert probe['status']=='PASS' and probe['vendor_loaded']
    assert probe['observed']['low_explicit.q']=='0' and probe['observed']['high_explicit.q']=='1'
    before=inventory(LIB); assert before==probe['before_original']
    ini_before=sha(BASE_INI); out.mkdir(parents=True); copied=out/'vendor_altera'; shutil.copytree(LIB,copied)
    assert inventory(copied)==before
    shutil.copy2(__file__,out/'run_batch.py')
    r={'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'scope':'Vendor DFFEAS re-test only. LUTs remain the exact exported truth-table logic. No SDF or full vendor-cell timing simulation.',
       'source_checkpoint':str(source),'candidate_label':original['candidate_label'],
       'source_report_sha256':sha(source/'simulation_report.json'),'source_manifest_sha256':sha(source/'FILE_MANIFEST.json'),
       'source_checkpoint_status_sha256':sha(source/'CHECKPOINT_STATUS.json'),
       'interface_probe_report_sha256':sha(HERE/'interface_probe/report.json'),
       'adapter':'Only add devclrn=devpor=1 for normal device operation. Existing actual is_wysiwyg, power_up, and all original ten pins including SCLR/SLOAD/ASDATA preserved. No external RTL input/reset/clock fixed or modified.',
       'compiled_local_dffeas':False,'runner_sha256':sha(__file__),'vendor_library':str(LIB),
       'vendor_metadata':'QuartusII11.0Build157SJ; Model Technology; original _info OV;L;6.6d;45',
       'library_before':before,'toolchain':{n:{'path':str(BIN/n),'sha256':sha(BIN/n)} for n in ('vlib.exe','vlog.exe','vsim.exe')},
       'base_ini_sha256':ini_before,'cases':[],'complete':False,'total_checked':0}
    save(out/'report.json',r)
    cases=sorted(original['cases'],key=lambda c:0 if c['id']=='test3' else 1)
    try:
        for c in cases:
            d=out/c['id']; d.mkdir(); item={'id':c['id'],'status':'RUNNING','commands':[]};r['cases'].append(item)
            instances={}
            for arm in ('reference','candidate'):
                raw=(source/c['id']/(arm+'.v')).read_bytes()
                assert hashlib.sha256(raw).hexdigest()==c['artifacts'][arm+'.v']['sha256']
                shutil.copy2(source/c['id']/(arm+'.v'),d/('frozen_'+arm+'.v'))
                shutil.copy2(source/c['id']/(arm+'.post_abc9.json'),d/(arm+'.post_abc9.json'))
                m=read(d/(arm+'.post_abc9.json'))['modules'][c['top']]
                adapted,instances[arm]=adapt(raw,m); (d/(arm+'.v')).write_bytes(adapted)
            save(d/'ADAPTER_AUDIT.json',{'scope':r['adapter'],'instances':instances,'only_documented_parameter_and_global_pin_additions':True})
            for f in ('testbench.sv','stimulus.hex','run.do','stimulus_manifest.json'):
                assert sha(source/c['id']/f)==c['artifacts'][f]['sha256'];shutil.copy2(source/c['id']/f,d/f)
            assert not any(re.search(r'\bmodule\s+dffeas\b',(d/f).read_text()) for f in ('reference.v','candidate.v','testbench.sv'))
            (d/'modelsim.ini').write_text('[Library]\nwork = '+(d/'work').as_posix()+'\naltera = '+copied.as_posix()+'\nothers = '+BASE_INI.as_posix()+'\n',encoding='utf-8')
            env=os.environ.copy();env['MODELSIM']=(d/'modelsim.ini').as_posix();env['PATH']=str(BIN)+os.pathsep+env.get('PATH','');temp=out/'child_temp';temp.mkdir(exist_ok=True);env['TEMP']=str(temp);env['TMP']=str(temp)
            commands=[['vlib.exe','work'],['vlog.exe','-modelsimini','modelsim.ini','-sv','-work','work','reference.v','candidate.v','testbench.sv'],
                      ['vsim.exe','-modelsimini','modelsim.ini','-c','-novopt','-t','1ps','-L','altera','-wlf','simulation.wlf','work.zero_'+c['id']+'_tb','-do','run.do']]
            for a in commands:
                argv=[str(BIN/a[0]),*a[1:]]; start=time.monotonic()
                with (d/(a[0]+'.log')).open('wb') as log:
                    p=subprocess.run(argv,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
                item['commands'].append({'argv':argv,'returncode':p.returncode,'wall_seconds_diagnostic_only':time.monotonic()-start,'log_sha256':sha(d/(a[0]+'.log'))})
                assert p.returncode==0,('ModelSim command failed',c['id'],a[0],p.returncode)
            log=(d/'vsim.exe.log').read_text(errors='replace')
            item['loaded_vendor_units']=sorted(set(re.findall(r'Loading\s+altera\.([\w]+)',log)))
            item['local_dffeas_loaded']=bool(re.search(r'Loading\s+work\.dffeas\b',log))
            ffcount=sum(map(len,instances.values())); item['ff_instances']=ffcount
            assert not item['local_dffeas_loaded']; assert ffcount==0 or 'dffeas' in item['loaded_vendor_units']
            mat=re.search(r'TCL_FINAL failed=(\d+) finished=(\d+) checked=(\d+) contract_failed=(\d+)',log);assert mat
            item['tcl_final']=dict(zip(('failed','finished','checked','contract_failed'),map(int,mat.groups())))
            assert item['tcl_final']=={'failed':0,'finished':1,'checked':c['expected_checks'],'contract_failed':0}
            with (d/'samples.csv').open() as f: rows=list(csv.DictReader(f))
            item['checked']=len(rows); item['failed_samples']=sum(int(v['mismatch']) for v in rows)
            item['unknown_samples']=sum(int(v['unknown_output']) for v in rows)
            item['contract_failed_samples']=sum(int(v['contract_failed']) for v in rows)
            item['csv_sha256']=sha(d/'samples.csv'); item['identical_frozen_sample_trace']=item['csv_sha256']==c['artifacts']['samples.csv']['sha256']
            assert item['checked']==c['expected_checks'] and item['identical_frozen_sample_trace']
            assert item['failed_samples']==item['unknown_samples']==item['contract_failed_samples']==0
            top='zero_'+c['id']+'_tb'
            actual=initial_q_values(d/'simulation.vcd',top,instances)
            expected=initial_q_values(source/c['id']/'simulation.vcd',top,instances)
            assert actual==expected and all(v in ('0','1') for v in actual.values())
            save(d/'INITIAL_Q_AUDIT.json',{'scope':'Final VCD values at timestamp zero, all exported physical FF Q pins individually compared with frozen r30; not only external outputs. Asynchronous controls can affect settled time-zero state.','passed':True,'ff_q_values_compared':len(actual),'vendor_values':actual,'frozen_values':expected})
            item['initial_q_values_compared']=len(actual); item['all_initial_q_match']=True
            cache=audit_cache(before,copied);assert cache['passed'] and cache['original_ir_unchanged']
            assert inventory(LIB)==before
            item['status']='PASS';r['total_checked']+=item['checked']; save(out/'report.json',r)
            print(c['id'],'PASS',item['checked'],'FF_initial',len(actual),flush=True)
        r['complete']=True;r['status']='PASS';r['all_nine_pass']=True;assert r['total_checked']==40684
    except Exception as exc:
        r['status']='ERROR';r['error']=repr(exc)
        if r['cases'] and r['cases'][-1]['status']=='RUNNING':r['cases'][-1]['status']='ERROR'
    finally:
        r['original_library_unchanged']=inventory(LIB)==before
        r['base_ini_unchanged']=sha(BASE_INI)==ini_before
        r['cache_audit']=audit_cache(before,copied)
        r['frozen_checkpoint_unchanged']=all(sha(source/row['path'])==row['sha256'] for row in manifest['files'])
        if not all([r['original_library_unchanged'],r['base_ini_unchanged'],r['cache_audit']['passed'],r['cache_audit']['original_ir_unchanged'],r['frozen_checkpoint_unchanged']]):
            r['status']='ERROR';r['integrity_error']='An immutable input or original vendor IR changed'
        r['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'report.json',r)
    print(r['status'],r['total_checked'],r.get('error',''),flush=True)
    return 0 if r['status']=='PASS' else 1

if __name__=='__main__': raise SystemExit(main())
