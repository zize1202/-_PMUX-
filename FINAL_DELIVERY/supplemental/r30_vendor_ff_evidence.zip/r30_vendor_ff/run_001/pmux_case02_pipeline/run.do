onerror {quit -code 2 -f}
log -r /*
vcd file simulation.vcd
vcd add -r /*
run -all
set nfailed [examine -radix unsigned /zero_pmux_case02_pipeline_tb/failed]
set nfinished [examine -radix unsigned /zero_pmux_case02_pipeline_tb/finished]
set nchecked [examine -radix unsigned /zero_pmux_case02_pipeline_tb/checked]
set ncontract_failed [examine -radix unsigned /zero_pmux_case02_pipeline_tb/contract_failed]
puts "TCL_FINAL failed=$nfailed finished=$nfinished checked=$nchecked contract_failed=$ncontract_failed"
vcd flush
if {$nfailed != 0 || $nfinished != 1 || $nchecked != 4730 || $ncontract_failed != 0} {quit -code 3 -f}
quit -code 0 -f
