"""Bind the target-specific SCLR implementation and its separately checked model."""
from pathlib import Path
import json

def bind(directory, verification, candidate_root, proof_root, binary_sha, sources, sha):
    directory=Path(directory);verification=Path(verification);root=Path(candidate_root);proof=Path(proof_root)
    positive=[];fallback=[];input_errors=[];identical=[]
    for name in ['target_init_guard_report.json','target_init_extra_report.json']:
        path=directory/name;d=json.loads(path.read_text(encoding='utf-8'));sources['sclr_'+name[:-5]]=path
        assert d['status']=='complete' and d['all_checks_passed'] and d['exe_sha256']==binary_sha
        for label,c in d['cases'].items():
            if c.get('classification'):
                assert c['exit_code']==1 and c['hardware_vector_rewrites']==0 and c['pass_'];input_errors.append(label);continue
            assert c['pass'] and c['exit_code']==0
            if c['hardware_vector_rewrites']:
                for k in ['exact_per_bit_power_up','CLK_D_Q_SRST_preserved','all_fixed_pins_checked','shared_EN_OR_SRST_checked','converted_Q_init_cleared']:assert c[k]
                positive.append(label)
            else:
                assert c['generic_r28_restating_fallback'] and c['all_original_initial_attributes_retained'];fallback.append(label)
            if c.get('full_JSON_byte_identical_to_r28'):identical.append(label)
    assert (len(positive),len(fallback),len(input_errors),len(identical))==(5,7,1,4)
    pp=directory/'pipeline_report.json';p=json.loads(pp.read_text(encoding='utf-8'));sources['sclr_pipeline_development']=pp
    assert p['exit_code']==0 and p['exe_sha256']==binary_sha and p['counts']['logic_units']<p['r28_production_logic_units']
    inventory={}
    for folder in sorted(x for x in root.iterdir() if x.is_dir() and (x/'post_abc9.json').exists()):
        d=json.loads((folder/'post_abc9.json').read_text(encoding='utf-8'));ffs=[c for m in d['modules'].values() for c in m.get('cells',{}).values() if c['type']=='dffeas']
        new=[c for c in ffs if c['connections']['sclr']!=['0']]
        for c in new:
            assert c['connections']['clrn']==c['connections']['prn']==['1']
            assert all(c['connections'][k]==['0'] for k in ['aload','asdata','sload'])
            assert c['parameters']['power_up'] in ['low','high'] and c['parameters']['is_wysiwyg']=='TRUE'
        inventory[folder.name]={'new_sclr_bits':len(new),'legacy_sclr_zero_bits':len(ffs)-len(new)}
    assert len(inventory)==9 and sum(x['new_sclr_bits'] for x in inventory.values())==58
    assert inventory['pmux_case02_pipeline']['new_sclr_bits']==p['counts']['dff']==24
    for name in ['pmux_cycloneiv_sclr.h','pmux_sdffe_boundary.h','opt_pmux.cc','synth_intel.cc']:
        assert sha(root/'source'/name)==sha(directory/'source_candidate/intel'/name)
        sources['sclr_source_'+name.replace('.','_')]=root/'source'/name
    sources['sclr_design']=directory/'DESIGN.md'
    mp=verification/'checks_002/report.json';m=json.loads(mp.read_text(encoding='utf-8'));sources['sclr_model_checks']=mp
    assert m['status']=='SMALL_MODEL_CHECKS_PASS' and len(m['validator_checks'])==25 and all(x['pass'] for x in m['validator_checks'])
    for name,digest in m['sources'].items():assert sha(verification/name)==digest
    assert len(m['SAT_checks'])==2
    for check in m['SAT_checks']:
        assert check['status']=='PASS' and check['returncode']==0 and check['input_assumptions']==[]
        assert sha(mp.parent/(check['name']+'.ys'))==check['script_sha256']
        assert sha(mp.parent/(check['name']+'.log'))==check['log_sha256']
    for folder in inventory:
        assert sha(proof/folder/'dffeas_formal.v')==m['sources']['dffeas_formal.v']
    for name in ['dffeas_formal.v','dffeas_sclr_sim.v','endpoint_sclr_runner.py','legacy_dffeas_formal.v','legacy_endpoint_runner.py']:
        sources['sclr_verification_'+name.replace('.','_')]=verification/name
    sources['sclr_first_launch_failure']=verification/'checks_001/report.json'
    return {'version':'r29','native_mapping_checks':len(positive),'native_fallback_checks':len(fallback),'native_exact_r28_fallbacks':len(identical),
            'native_input_errors':input_errors,'native_guard_checks_are_semantic_proof':False,'model_validator_checks':25,'model_sat_and_induction_checks':2,
            'formal_model_sha256':m['sources']['dffeas_formal.v'],'simulator_model_sha256':m['sources']['dffeas_sclr_sim.v'],
            'validator_sha256':m['sources']['endpoint_sclr_runner.py'],'model_checks_sha256':sha(mp),'actual_ff_domains':inventory,
            'prior_pipeline_logic':p['r28_production_logic_units'],'native_pipeline_logic':p['counts']['logic_units'],
            'native_pipeline_ff':p['counts']['dff'],'native_vector_rewrites':len(p['hardware_sclr_log']),
            'candidate_binary_sha256':binary_sha,'included_in_official_nine':False}
