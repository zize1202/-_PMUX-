from book_settings import require_render, OUTPUT
require_render()
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
from PIL import Image
import hashlib,json,re,sys,os,importlib
_content=importlib.import_module(os.environ.get('PMUX_BOOK_CONTENT','content'))
blocks,limits=_content.blocks,_content.limits
_brief=os.environ.get('PMUX_BOOK_CONTENT')=='brief_content'
sys.path.insert(0,'C:/Users/xinxi/.codex/skills/math-modeling-skill-main/tools/docx/scripts')
from equations import latex2omml
from equation_bridge import normalize_for_docx

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
OUT=OUTPUT
OUT.mkdir(parents=True,exist_ok=True)
FIG=HERE/'figures';FIG.mkdir(exist_ok=True)

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M='http://schemas.openxmlformats.org/officeDocument/2006/math'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
ns={'w':W,'m':M,'r':R}
def el(tag,**attrs):
 pre,local=tag.split(':'); e=E.Element('{'+{'w':W,'m':M,'r':R}[pre]+'}'+local)
 for k,v in attrs.items():e.set('{'+{'w':W,'m':M,'r':R}[pre]+'}'+k,str(v))
 return e
def change(parent,tag,**attrs):
 old=parent.find(tag,ns)
 if old is not None:parent.remove(old)
 z=el(tag,**attrs);parent.append(z);return z
def clear(parent,tag):
 for z in parent.findall(tag,ns):parent.remove(z)
def xml(x):return E.tostring(x,encoding='UTF-8',xml_declaration=True,standalone=True)

zin=ZipFile(HERE/'template.docx');parts={n:zin.read(n) for n in zin.namelist()};doc=E.fromstring(parts['word/document.xml'])
body=doc.find('w:body',ns); ps=body.findall('w:p',ns);sect=deepcopy(body.find('w:sectPr',ns))
rels=E.fromstring(parts['word/_rels/document.xml.rels'])
styles=E.fromstring(parts['word/styles.xml'])
for sid,name,outline in [('Title','Title',None),('ProjectHeading3','Heading 3',2)]:
 st=el('w:style',type='paragraph',styleId=sid);st.append(el('w:name',val=name));st.append(el('w:basedOn',val='1'));st.append(el('w:qFormat'))
 if outline is not None:
  sp=el('w:pPr');sp.append(el('w:outlineLvl',val=outline));st.append(sp)
 styles.append(st)
parts['word/styles.xml']=xml(styles)
prefix={6:'1.1',9:'1.2',12:'1.3',15:'1.4',18:'1.5',21:'1.6',27:'2.1',30:'2.2',35:'2.3',41:'3.1',43:'3.2',48:'3.3',53:'4.1',55:'4.2'}
def run(text,size=24,bold=False,font='Times New Roman'):
 r=el('w:r');rp=el('w:rPr');r.append(rp)
 rp.append(el('w:rFonts',ascii=font,hAnsi=font,eastAsia='宋体',cs=font))
 rp.append(el('w:color',val='000000'));rp.append(el('w:sz',val=size));rp.append(el('w:szCs',val=size))
 if bold:rp.append(el('w:b'))
 for i,line in enumerate(text.split('\n')):
  if i:r.append(el('w:br'))
  t=el('w:t');t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=line;r.append(t)
 return r
def para(text,source=25,size=24,bold=False,indent=True,center=False,keep=False,before=0,after=0,spacing=360):
 p=el('w:p');pr=deepcopy(ps[source].find('w:pPr',ns))
 for tag in ['w:rPr','w:numPr','w:tabs','w:keepNext','w:keepLines','w:pageBreakBefore']:clear(pr,tag)
 if source!=0:clear(pr,'w:pStyle')
 else:change(pr,'w:pStyle',val='Title')
 change(pr,'w:spacing',line=spacing,lineRule='auto',before=before,after=after)
 change(pr,'w:ind',firstLine=480 if indent else 0,left=0,right=0)
 change(pr,'w:jc',val='center' if center else 'both')
 change(pr,'w:widowControl',val=1)
 if keep:pr.append(el('w:keepNext'))
 p.append(pr);p.append(run(text,size,bold));return p
def heading(b):
 s=b['source']; txt=(prefix[s]+'  ' if s in prefix else '')+b['text']
 major=s not in prefix
 p=para(txt,s,size=28 if major else 24,bold=major,indent=False,keep=True,before=140 if s!=2 else 60,after=60)
 change(p.find('w:pPr',ns),'w:pStyle',val='2' if major else '3')
 # Explicit prefixes retain the template's visible numbering independently
 # of its empty list-advancing paragraphs.
 # Keep continuous flow as in the reference; no artificial half-empty pages.
 return p

def table(b):
 widths=[round(x*567) for x in b['widths']];tbl=el('w:tbl');pr=el('w:tblPr')
 pr.append(el('w:tblW',w=sum(widths),type='dxa'));pr.append(el('w:tblLayout',type='fixed'))
 pr.append(el('w:jc',val='center'))
 borders=el('w:tblBorders')
 for edge in ['top','left','bottom','right','insideH','insideV']:borders.append(el('w:'+edge,val='single' if edge in ['top','bottom'] else 'nil',sz=12 if edge in ['top','bottom'] else 0,color='000000'))
 pr.append(borders);marg=el('w:tblCellMar')
 for edge,val in [('top',45),('bottom',45),('left',90),('right',90)]:marg.append(el('w:'+edge,w=val,type='dxa'))
 pr.append(marg);tbl.append(pr);grid=el('w:tblGrid')
 for w in widths:grid.append(el('w:gridCol',w=w))
 tbl.append(grid)
 for ri,row in enumerate([b['headers']]+b['rows']):
  tr=el('w:tr');trpr=el('w:trPr');trpr.append(el('w:cantSplit'))
  if ri==0:trpr.append(el('w:tblHeader'))
  tr.append(trpr)
  for ci,(text,w) in enumerate(zip(row,widths)):
   tc=el('w:tc');tcp=el('w:tcPr');tcp.append(el('w:tcW',w=w,type='dxa'));tcp.append(el('w:vAlign',val='center'))
   if ri==0:
    cb=el('w:tcBorders');cb.append(el('w:top',val='single',sz=12,color='000000'));cb.append(el('w:bottom',val='single',sz=6,color='000000'));tcp.append(cb)
   tc.append(tcp)
   short=ri==0 or (len(text)<22 and ci>0)
   cp=para(text,size=21,bold=ri==0,indent=False,center=short,spacing=252)
   change(cp.find('w:pPr',ns),'w:jc',val='center' if short else 'left')
   cp.find('w:pPr',ns).append(el('w:keepLines'))
   # Keep at least two data rows together at both ends; small tables stay whole.
   if ri<len(b['rows']):
    cp.find('w:pPr',ns).append(el('w:keepNext'))
   tc.append(cp);tr.append(tc)
  tbl.append(tr)
 return tbl

imageid=100
def picture(b):
 global imageid
 imageid+=1;path=FIG/b['file'];im=Image.open(path)
 cx=int(b.get('width',14.4)*360000);cy=int(cx*im.height/im.width)
 rid='rIdProjectImage'+str(imageid); target='media/project_'+b['file'];parts['word/'+target]=path.read_bytes()
 relem=E.SubElement(rels,'{'+P+'}Relationship');relem.set('Id',rid);relem.set('Type',R+'/image');relem.set('Target',target)
 # Drawing is inline, within the existing text column.
 dr=E.fromstring(f'''<w:drawing xmlns:w="{W}" xmlns:r="{R}" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
 <wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="{imageid}" name="项目书图{imageid-100}" descr="{b['text']}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="{imageid}" name="{b['file']}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>''')
 p=para('',size=22,indent=False,center=True,keep=True,before=0,after=40,spacing=240)
 r=p.find('w:r',ns);r.append(dr);return p

def mathrun(text):
 r=el('m:r');rp=el('w:rPr');rp.append(el('w:rFonts',ascii='Cambria Math',hAnsi='Cambria Math'));rp.append(el('w:sz',val=24));r.append(rp)
 t=el('m:t');t.text=text;r.append(t);return r
def subscript(text,sub):
 s=el('m:sSub');e=el('m:e');e.append(mathrun(text));su=el('m:sub');su.append(mathrun(sub));s.extend([e,su]);return s
def eqn(b):
 p=para('',indent=False,center=True,before=80,after=80,spacing=360);p.remove(p.find('w:r',ns));om=el('m:oMath')
 if b.get('mode')=='plain':
  om=E.fromstring(latex2omml(normalize_for_docx(b['tex'])))
 elif b.get('mode')=='reduction':
  om.append(subscript('R','i'));om.append(mathrun(' = '));f=el('m:f');num=el('m:num');num.append(mathrun('B − F'));den=el('m:den');den.append(mathrun('B'));f.extend([num,den]);om.append(f);om.append(mathrun(' × 100% ,   B > 0'))
 elif b.get('mode')=='aggregate':
  om.append(subscript('R','w'));om.append(mathrun(' = (1 − '));f=el('m:f');num=el('m:num');num.append(mathrun('Σ'));num.append(subscript('F','i'));den=el('m:den');den.append(mathrun('Σ'));den.append(subscript('B','i'));f.extend([num,den]);om.append(f);om.append(mathrun(') × 100%,   '));om.append(subscript('R','m'));om.append(mathrun(' = Σ'));om.append(subscript('R','i'));om.append(mathrun(' / 184'))
 elif b['text'].startswith('kb'):
  for i,(name,x) in enumerate([('b','r'),('c','c')]):
   if i:om.append(mathrun(',    '))
   om.append(subscript('k',name));om.append(mathrun(' = ⌈'));om.append(subscript('log','2'));om.append(mathrun('('+x+'+1)⌉'))
 else:
  om.append(mathrun('f = '));om.append(subscript('f','0'));om.append(mathrun(' ⊕ [x ∧ ('));om.append(subscript('f','0'));om.append(mathrun(' ⊕ '));om.append(subscript('f','1'));om.append(mathrun(')]'))
 p.append(om);return p

for x in list(body):body.remove(x)
for bi,b in enumerate(blocks):
 k=b['kind']
 if k=='title':body.append(para(b['text'],0,size=36,indent=False,center=True,keep=True,after=100))
 elif k=='h':body.append(heading(b))
 elif k=='sub':
  p=para(b['text'],31,bold=True,indent=False,keep=True,before=120,after=40);change(p.find('w:pPr',ns),'w:pStyle',val='ProjectHeading3');body.append(p)
 elif k=='p':body.append(para(b['text'],size=22 if _brief else 24,spacing=300 if _brief else 360))
 elif k=='reference':
  text=b['text'];match=re.search(r'https://\S+?(?=\.$|$)',text)
  p=para(text if match is None else text[:match.start()],indent=False,size=21,spacing=280,after=60);p.find('w:pPr',ns).append(el('w:keepLines'))
  if match:
   rid='rIdVerifiedReference'+str(len(rels)+1)
   rel=E.SubElement(rels,'{'+P+'}Relationship');rel.set('Id',rid);rel.set('Type',R+'/hyperlink');rel.set('Target',match.group());rel.set('TargetMode','External')
   link=el('w:hyperlink');link.set('{'+R+'}id',rid);link.append(run(match.group(),size=21));p.append(link)
   if match.end()<len(text):p.append(run(text[match.end():],size=21))
  change(p.find('w:pPr',ns),'w:jc',val='left')
  if b['text'].startswith(('[1]','[2]')):p.find('w:pPr',ns).append(el('w:keepNext'))
  body.append(p)
 elif k=='code':
  p=para(b['text'],indent=False,size=21,spacing=288,before=80,after=80);p.find('w:pPr',ns).append(el('w:keepLines'));body.append(p)
 elif k=='table':
  body.append(para(b['text'],size=22,indent=False,center=True,keep=True,before=80,after=60,spacing=276));body.append(table(b))
  body.append(para('',indent=False,size=6,spacing=80,after=20))
 elif k=='figure':
  spacer=para('',size=2,indent=False,keep=True,spacing=240)
  change(spacer.find('w:pPr',ns),'w:spacing',line=240,lineRule='exact',before=0,after=0)
  body.append(spacer)
  body.append(picture(b));body.append(para(b['text'],size=22,indent=False,center=True,after=100,spacing=276))
 elif k=='equation':
  p=eqn(b)
  if bi+1<len(blocks) and blocks[bi+1]['kind']=='equation':p.find('w:pPr',ns).append(el('w:keepNext'))
  body.append(p)
 elif k=='pagebreak':
  p=para('',size=2,indent=False,spacing=20)
  p.find('w:r',ns).append(el('w:br',type='page'))
  body.append(p)
 else:raise ValueError(k)
body.append(sect)
parts['word/document.xml']=xml(doc);parts['word/_rels/document.xml.rels']=xml(rels)
core=E.fromstring(parts['docProps/core.xml'])
for x in list(core):
 if E.QName(x).localname in ['creator','lastModifiedBy','title','subject','keywords','description']:x.text=''
parts['docProps/core.xml']=xml(core)
app=E.fromstring(parts['docProps/app.xml'])
for x in app:
 if E.QName(x).localname in ['Company','Manager']:x.text=''
parts['docProps/app.xml']=xml(app)
custom=E.fromstring(parts['docProps/custom.xml'])
for x in list(custom):custom.remove(x)
parts['docProps/custom.xml']=xml(custom)
settings=E.fromstring(parts['word/settings.xml']);change(settings,'w:updateFields',val='true');parts['word/settings.xml']=xml(settings)
docx=OUT/(os.environ.get('PMUX_BOOK_FILENAME','PMUX结构优化与等价验证系统_项目书')+'.docx')
with ZipFile(docx,'w',ZIP_DEFLATED) as z:
 for n,data in parts.items():z.writestr(n,data)
allowed={'word/document.xml','word/_rels/document.xml.rels','docProps/core.xml','docProps/app.xml','docProps/custom.xml','word/settings.xml','word/styles.xml'}
unchanged=[n for n in zin.namelist() if n not in allowed]
assert all(parts[n]==zin.read(n) for n in unchanged)
assert all(len(t)<=cap for t,cap in limits.values())
forbidden=['wxid_','C:/Users','xinxi','待填写','800字内','400字内']
alltext=''.join(doc.itertext())
assert not any(s in alltext for s in forbidden)
report={'output':str(docx),'sha256':hashlib.sha256(docx.read_bytes()).hexdigest(),'preserved_parts':unchanged,'changed_allowed_parts':sorted(allowed),'word_limits':{k:{'count_with_punctuation':len(v[0]),'limit':v[1]} for k,v in limits.items()},'content_blocks':len(blocks),'tables':sum(b['kind']=='table' for b in blocks),'figures':sum(b['kind']=='figure' for b in blocks),'native_equations':sum(b['kind']=='equation' for b in blocks)}
(HERE/(os.environ.get('PMUX_BOOK_AUDIT_PREFIX','')+'docx_build_audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(HERE/(os.environ.get('PMUX_BOOK_AUDIT_PREFIX','')+'content.json')).write_text(json.dumps(blocks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
