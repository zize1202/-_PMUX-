"""Select one evidence bundle; this only writes configuration and never renders."""
import argparse,json
from pathlib import Path
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
for name in ['candidate','binding','proof','performance','candidate-root','runtime-root','modelsim','modelsim-checkpoint','supplemental-scale','output-name','main-package-name']:
 p.add_argument('--'+name)
p.add_argument('--features',help='Comma separated source features; must be reviewed against final source.')
p.add_argument('--proof-origin',choices=['fresh_run','exact_endpoint_reuse'])
p.add_argument('--proof-origin-version')
p.add_argument('--use-checkpoint-wave-assets',action=argparse.BooleanOptionalAction,default=None)
p.add_argument('--freeze',action='store_true',help='Only after measurements end and final candidate/current ModelSim are selected.')
a=p.parse_args();file=R/'release_config.json';d=json.loads(file.read_text(encoding='utf-8'))
for key in ['candidate','binding','proof','performance','candidate_root','runtime_root','modelsim','modelsim_checkpoint','supplemental_scale','output_name','main_package_name']:
 if getattr(a,key) is not None:d[key]=getattr(a,key)
if a.features:d['features']=[x.strip() for x in a.features.split(',') if x.strip()]
if a.use_checkpoint_wave_assets is not None:d['use_checkpoint_wave_assets']=a.use_checkpoint_wave_assets
if a.proof_origin:
 d['proof_origin']={'mode':a.proof_origin,'version':a.proof_origin_version or d['candidate'],'directory':str(Path(d['proof']).parent)}
d['phase']='frozen' if a.freeze else 'draft_unfrozen'
if a.freeze:
 assert d.get('modelsim'),'Current matching ModelSim evidence is required.'
 assert '待' not in d['output_name'] and '待' not in d['main_package_name']
 assert d.get('proof_origin',{}).get('mode') in ['fresh_run','exact_endpoint_reuse']
file.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
print('Configuration saved. Next run prepare_evidence.py; this command did not compile or render.')
