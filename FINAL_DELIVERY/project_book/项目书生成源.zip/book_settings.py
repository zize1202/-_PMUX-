"""Central output routing. Importing this module never creates a release directory."""
from pathlib import Path
import json, os, hashlib
ROOT=Path(__file__).resolve().parent
WORKSPACE=Path("C:/Users/xinxi/Documents/Codex/2026-09-27/new-chat-3")
CONFIG_PATH=Path(os.environ.get('PMUX_ZERO_CONFIG',ROOT/'release_config.json'))
CONFIG=json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
name=CONFIG['output_name']
assert name and Path(name).name==name and name!='PMUX项目书_官方九例验证版_20261101'
OUTPUT=Path(CONFIG.get('output_root',WORKSPACE/'outputs'))/name

def resolve(value):
    p=Path(value)
    return p if p.is_absolute() else WORKSPACE/p

def require_render():
    if os.environ.get('PMUX_ZERO_RENDER')!='1':
        raise SystemExit('PREPARATION ONLY: no document compilation or figure rendering. Set PMUX_ZERO_RENDER=1 only after the final candidate is frozen and timing has ended.')
    data=json.loads((ROOT/'evidence_snapshot.json').read_text(encoding='utf-8'))
    if CONFIG.get('phase')!='frozen' or not data.get('release_ready'):
        raise SystemExit('Final matching proof, performance and ModelSim evidence have not been frozen.')
    if data.get('configuration_sha256')!=hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest():
        raise SystemExit('Configuration changed after evidence preparation; run prepare_evidence.py again.')
    return data
