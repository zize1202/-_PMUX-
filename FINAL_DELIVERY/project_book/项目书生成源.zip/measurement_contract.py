"""Read measurement scope without pooling export-inclusive v2 and C145-scope v3."""
from collections import Counter
from pathlib import Path
import hashlib
import json


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scope_for_report(report):
    schema = report['schema']
    assert schema in (2, 3), 'Unreviewed measurement schema.'
    if schema == 3:
        assert report['measurement_scope'] == 'C145_read_verilog_then_synth_intel_process_lifetime_no_added_stat_or_export'
        return {'schema': 3, 'code': 'c145_two_command_lifetime',
                'title': 'v3 两命令生命周期', 'short': 'v3 两命令',
                'area_basis': 'independent_untimed_capture_inventory_bound',
                'summary': '计时脚本仅含read_verilog与synth_intel；面积在全部计时结束后独立导出，并逐类型核对每次内置统计。',
                'qualification': '这是C145展示命令范围的实现；C92未明确禁止导出，不能据此否定旧v2记录。'}
    return {'schema': 2, 'code': 'export_inclusive_lifetime',
            'title': 'v2 含统计与导出生命周期', 'short': 'v2 含导出',
            'area_basis': 'timed_process_export',
            'summary': '本表沿用v2范围，计时进程包含附加stat与JSON导出；这些历史效率结果尚不能替代v3两命令范围的正式测量。',
            'qualification': 'v2与v3范围分别保留，不能混算或把范围变化解释为算法加速。'}


def timed_runs(case):
    yield from case['initial']
    for pair in case['rechecks']:
        yield from pair


def validate_v3_report(report, supplemental=False):
    """Verify phase separation; this is also usable for the single-case tool smoke."""
    if supplemental:
        assert report['measurement_scope']=='SUPPLEMENTAL_default_flatten_read_verilog_then_synth_intel_process_lifetime_no_export'
    else:scope_for_report(report)
    assert report['schema'] == 3 and report['complete']
    assert report['all_timing_valid'] and report['all_area_valid'] and report['all_measurements_valid']
    assert report['timed_batch_finished']
    events = report['events']
    boundary = [e['sequence'] for e in events if e['phase'] == 'timed_batch_finished']
    timed = [e['sequence'] for e in events if e['phase'] in ('timed_start', 'timed_end')]
    capture = [e['sequence'] for e in events if e['phase'] in ('untimed_capture_start', 'untimed_capture_end')]
    assert len(boundary) == 1 and timed and capture
    assert max(timed) < boundary[0] < min(capture), 'Area capture overlapped timed batch.'


def validate_v3_case(report, case):
    """Validate explicit capture paths and all associated timed inventories, including warmup."""
    assert case['area_state'] == 'CAPTURED_AND_INVENTORY_MATCHED'
    assert case['aggregate']['area_valid'] and case['timing_aggregate']['valid']
    captures = case['untimed_area_captures']
    result = []
    for arm in ('baseline', 'optimized'):
        cap = captures[arm]
        assert cap['valid'] and cap['included_in_efficiency'] is False
        assert cap['execution_scope'] == 'untimed_area_reexecution'
        assert cap['cells'] == case['aggregate'][arm + '_cells']
        assert cap['cells']['classification_complete']
        assert digest(cap['netlist']) == cap['cells']['netlist_sha256']
        data = json.loads(Path(cap['netlist']).read_text(encoding='utf-8'))
        top = cap['capture_stat_inventory']['top']
        direct = dict(sorted(Counter(c['type'] for c in data['modules'][top].get('cells', {}).values()).items()))
        assert direct == cap['cells']['cell_types']
        chosen = [r for r in timed_runs(case) if r['arm'] == arm]
        chosen += [r for r in report['warmup'] if r['case_id'] == case['id'] and r['arm'] == arm]
        validation = cap['timed_inventory_validation']
        assert validation['valid'] and validation['matched_inventory'] == direct
        assert validation['matched_timed_runs_including_warmup'] == len(chosen) and chosen
        for record in [cap] + chosen:
            assert record['valid']
            for key in ('binary_sha256', 'source_sha256', 'abc_sha256', 'techlib_sha256', 'timed_script_sha256'):
                assert record[key] == cap[key], 'Timed/capture provenance mismatch: ' + key
            assert record['binary_sha256'] == report['binaries'][arm]['sha256']
            assert record['abc_sha256'] == report['abc']['sha256']
            commands = record['actual_abc_invocations']
            assert commands and all(x['matches_requested_binary_bytes'] and x['sha256'] == report['abc']['sha256'] for x in commands)
            inventory = record.get('timed_stat_inventory', record.get('capture_stat_inventory'))
            assert inventory['cell_types'] == direct and inventory['total_direct_cells'] == sum(direct.values())
            if record is not cap:
                assert record['measurement_valid'] and record['execution_scope'] == 'two_command_synthesis_lifetime'
                assert 'cells' not in record and 'netlist' not in record, 'Timed v3 run cannot claim an exported netlist.'
                assert record['script_sha256'] == cap['timed_script_sha256']
        result.append({'id': case['id'], 'arm': arm, 'netlist': cap['netlist'],
                       'netlist_sha256': cap['cells']['netlist_sha256'],
                       'matched_timed_runs_including_warmup': len(chosen),
                       'inventory_agreement_is_not_netlist_identity': True})
    return result
