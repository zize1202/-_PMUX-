"""Compact numbered serpentine flow; keep every title and arrow inside its panel."""
def draw_candidate_flow(Scene, steps, blue, teal):
    rows=(len(steps)+1)//2
    scene=Scene('candidate_flow',rows*20+6)
    positions=[]
    for i,(title,subtitle) in enumerate(steps):
        row=i//2;column=(i%2) if row%2==0 else 1-(i%2)
        x=4 if column==0 else 77;y=3+20*row
        scene.node(x,y,63,16,f'{i+1}  {title}',subtitle,teal if i==len(steps)-1 else blue,size=8.6)
        positions.append((x,y))
    for (x0,y0),(x1,y1) in zip(positions,positions[1:]):
        if y0==y1:
            start=x0+63 if x1>x0 else x0;end=x1 if x1>x0 else x1+63
            scene.line([(start,y0+8),(end,y1+8)],arrow=True)
        else:scene.line([(x0+31.5,y0+16),(x1+31.5,y1)],arrow=True)
    return scene
