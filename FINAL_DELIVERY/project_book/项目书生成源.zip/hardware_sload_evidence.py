"""Bind R30 native leaf extraction, actual domains and independent model evidence."""
from pathlib import Path
import json

def bind(directory, verification, candidate_root, proof_root, binary_sha, sources, sha):
    directory=Path(directory); verification=Path(verification); root=Path(candidate_root); proof=Path(proof_root)
    def read(path,key):
        sources[key]=path
        return json.loads(path.read_text(encoding='utf-8'))
    native=read(directory/'manifest.json','sload_native_manifest')
    guards=read(directory/'sload_guard_report_v2.json','sload_native_guards')
    assert guards['all_checks_passed'] and guards['exe_sha256']==native['yosys_sha256']==binary_sha
    assert sha(directory/'sload_guard_report_v2.json')==native['sload_guard_report_sha256']
    positive=[x for x in guards['cases'].values() if x['sload_root_rewrites']]
    negative=[x for x in guards['cases'].values() if not x['sload_root_rewrites']]
    sat=[x['arbitrary_state_next_cycle_SAT'] for x in positive if 'arbitrary_state_next_cycle_SAT' in x]
    assert (len(guards['cases']),len(positive),len(negative),len(sat))==(26,7,19,6)
    assert all(x['pass'] for x in guards['cases'].values())
    assert all(x['complete_output_JSON_identical_to_r29'] for x in negative)
    assert all(x['status']=='PASS' and x['assumptions']==[] for x in sat)
    pipeline=read(directory/'pipeline_report.json','sload_pipeline_development')
    assert pipeline['exe_sha256']==binary_sha and pipeline['counts']['logic_units']==305 and pipeline['counts']['dff']==24
    assert pipeline['r29_production_logic_units']==323 and len(pipeline['hardware_sload_log'])==8
    assert sha(directory/'pipeline_report.json')==native['native_pipeline_report_sha256']
    for name in ['pmux_cycloneiv_sload.h','pmux_cycloneiv_sclr.h','pmux_sdffe_boundary.h','opt_pmux.cc']:
        assert sha(root/'source'/name)==native['source_after'][name]==sha(directory/'source_candidate/intel'/name)
        sources['sload_source_'+name.replace('.','_')]=root/'source'/name
    sources['sload_design']=directory/'README.md'
    sources['sload_initial_harness_failure']=directory/'sload_guard_report_initial.json'
    model=read(verification/'checks_002/report.json','sload_model_checks')
    assert model['status']=='SMALL_MODEL_CHECKS_PASS' and len(model['validator_checks'])==53
    assert all(x['pass'] for x in model['validator_checks'])
    for name,digest in model['sources'].items():assert sha(verification/name)==digest
    assert len(model['SAT_checks'])==2
    for check in model['SAT_checks']:
        assert check['status']=='PASS' and check['returncode']==0 and check['input_assumptions']==[]
        for suffix in ['ys','log']:
            assert sha(verification/'checks_002'/(check['name']+'.'+suffix))==check['script_sha256' if suffix=='ys' else 'log_sha256']
    vendor=model['vendor_sample_connection']
    assert vendor['original_probe_status']=='ERROR' and vendor['original_error_preserved']
    assert vendor['observed_behavior_comparisons']==642 and vendor['complete_binary_previous_state_control_tuples']==64 and vendor['mismatches']==[]
    base=verification.parents[1]/'research/vendor_dffeas_probe/run_002'
    for name,digest in vendor['files'].items():
        assert sha(base/name)==digest
        sources['vendor_probe_'+name.replace('.','_')]=base/name
    inventory={}
    for folder in sorted(x for x in root.iterdir() if x.is_dir() and (x/'post_abc9.json').exists()):
        mapped=json.loads((folder/'post_abc9.json').read_text(encoding='utf-8'))
        ffs=[c for m in mapped['modules'].values() for c in m.get('cells',{}).values() if c['type']=='dffeas']
        extended=[c for c in ffs if any(c['connections'][k]!=['0'] for k in ['sclr','sload','asdata'])]
        for c in extended:
            assert c['connections']['clrn']==c['connections']['prn']==['1'] and c['connections']['aload']==['0']
            assert c['parameters']['power_up'] in ['low','high'] and c['parameters']['is_wysiwyg']=='TRUE'
        inventory[folder.name]={'extended_domain_bits':len(extended),'legacy_domain_bits':len(ffs)-len(extended),'nonconstant_sload_bits':sum(c['connections']['sload'] not in [['0'],['1']] for c in ffs)}
        assert sha(proof/folder.name/'dffeas_formal.v')==model['sources']['dffeas_formal.v']
    assert len(inventory)==9 and inventory['pmux_case02_pipeline']['nonconstant_sload_bits']==24
    for name in ['dffeas_formal.v','dffeas_sload_sim.v','endpoint_sload_runner.py','legacy_dffeas_formal.v','legacy_endpoint_runner.py']:
        sources['sload_verification_'+name.replace('.','_')]=verification/name
    sources['sload_initial_model_fixture_failure']=verification/'checks_001/report.json'
    return {'version':'r30','native_guard_checks':26,'native_positive_checks':7,'native_transition_sat_checks':6,
        'native_r29_byte_identical_rejections':19,'native_pipeline_prior_logic':323,'native_pipeline_logic':305,'native_pipeline_ff':24,
        'model_validator_checks':53,'model_sat_and_induction_checks':2,'actual_ff_domains':inventory,
        'formal_model_sha256':model['sources']['dffeas_formal.v'],'simulator_model_sha256':model['sources']['dffeas_sload_sim.v'],
        'validator_sha256':model['sources']['endpoint_sload_runner.py'],'model_checks_sha256':sha(verification/'checks_002/report.json'),
        'vendor_observed_samples':642,'vendor_binary_tuples':64,'vendor_original_report_status':'ERROR','candidate_binary_sha256':binary_sha,
        'local_checks_are_official_nine':False}
