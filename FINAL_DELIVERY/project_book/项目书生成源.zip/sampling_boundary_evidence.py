"""Read-only binding of native boundary guards and current mechanism figures."""
from pathlib import Path
import json

def bind_development(directory, candidate_root, binary_sha, sources, sha):
    directory=Path(directory);root=Path(candidate_root)
    positive=[];negative=[];invalid=[]
    for name in ['sampling_guard_report.json','sampling_guard_extra_report.json']:
        path=directory/name;d=json.loads(path.read_text(encoding='utf-8'));sources[name[:-5]]=path
        assert d['status']=='complete' and d['all_checks_passed'] and d['exe_sha256']==binary_sha
        for label,c in d['cases'].items():
            assert c['pass']
            if c['rewrite_count']:
                assert c['exit_code']==0
                sat=c['next_state_sat'];assert sat['status']=='PASS' and sat['assumptions']==[] and sat['arbitrary_previous_Q']
                assert c['same_FF_objects_non_EN_ports_params_attrs_and_init_preserved']
                positive.append(label)
            else:
                if c.get('rejected_before_legal_design_claim'):
                    assert c['exit_code']!=0;invalid.append({'case':label,'exit_code':c['exit_code']})
                else:
                    assert c['exit_code']==0 and c['full_output_JSON_identical_to_r23'];negative.append(label)
    assert len(positive)==4 and len(negative)==31 and len(invalid)==1
    pp=directory/'pipeline_report.json';pipeline=json.loads(pp.read_text(encoding='utf-8'));sources['sampling_pipeline_development']=pp
    assert pipeline['exe_sha256']==binary_sha and pipeline['exit_code']==0
    current=json.loads((root/'pmux_case02_pipeline/mapped.netlist.json').read_text(encoding='utf-8'))
    cells=current['modules']['pmux_case02_pipeline']['cells'];ffs=[c for c in cells.values() if c['type']=='dffeas']
    assert len(ffs)==pipeline['counts']['dff']==24
    ena={tuple(c['connections']['ena']) for c in ffs};assert len(ena)==1 and isinstance(next(iter(ena))[0],int)
    assert all(c['connections']['sclr']==['0'] for c in ffs)
    header=root/'source/pmux_sdffe_boundary.h';original=directory/'source_candidate/intel/pmux_sdffe_boundary.h'
    assert sha(header)==sha(original);sources['sampling_boundary_header']=header;sources['sampling_boundary_design']=directory/'DESIGN.md'
    return {'version':'r28','positive_next_state_sat':len(positive),'negative_unchanged':len(negative),'invalid_parameter_nonzero_exit':invalid,
            'actual_ff_count':len(ffs),'all_ff_ena_shared':True,'all_ff_sclr_zero':True,
            'native_rewritten_ff_objects':len(pipeline['sampling_boundary_log']),
            'prior_pipeline_logic':pipeline['r23_production_logic_units'],'native_pipeline_logic':pipeline['counts']['logic_units'],
            'candidate_binary_sha256':binary_sha,'not_a_new_run':True,'included_in_official_nine':False}

def bind_mechanisms(source,sim,candidate,runtime,sources,sha):
    source=Path(source);cases={c['id']:c for c in sim['cases']}
    checkpoint=json.loads((source/'CHECKPOINT_STATUS.json').read_text(encoding='utf-8'))
    assert checkpoint['checkpoint']==candidate and checkpoint['all_nine_pass'] and (checkpoint.get('six_actual_vcd_figures') or checkpoint.get('seven_actual_vcd_figures'))
    assert checkpoint['report_sha256']==sha(source/'simulation_report.json')
    index=json.loads((source/'FILE_MANIFEST.json').read_text(encoding='utf-8'))
    for item in index['files']:assert sha(source/item['path'])==item['sha256']
    sources['checkpoint_manifest']=source/'FILE_MANIFEST.json';sources['checkpoint_status']=source/'CHECKPOINT_STATUS.json'
    model=json.loads((source/'MODEL_SCOPE_AUDIT.json').read_text(encoding='utf-8'))
    assert model['candidate']==candidate and model['passed']
    assert model['model_sha256']==sha(source/'dffeas_simulation.v')
    hardware_sload='runtime_file_sha256' in model and 'endpoint_sload_runner.py' in model['runtime_file_sha256']
    hardware_sclr='formal_model_sha256' in model or hardware_sload
    if hardware_sload:
        algorithm=json.loads((source/'ALGORITHM_SOURCE_BINDING.json').read_text(encoding='utf-8'))
        assert algorithm['all_match'] and algorithm['candidate_label']==candidate
        mapping_hash=next(x['sha256'] for x in algorithm['source_files_verified'] if x['path']=='common/ff_map.v')
        base=source/'provenance/sload_model_verification'
        for item in model['model_provenance_files']:assert sha(base/item['path'])==item['sha256']
        for name,digest in model['runtime_file_sha256'].items():assert sha(base/name)==sha(source/name)==digest
        assert sha(base/'checks_002/report.json')==model['small_model_report_sha256']
        model['formal_model_sha256']=model['runtime_file_sha256']['dffeas_formal.v']
        model['validator_sha256']=model['runtime_file_sha256']['endpoint_sload_runner.py']
        model['independent_model_checks_report_sha256']=model['small_model_report_sha256']
    else:
        mapping_hash=model['unchanged_legacy_ff_map_sha256'] if hardware_sclr else model['unchanged_ff_map_sha256']
    assert mapping_hash==sha(Path(runtime)/'share/yosys/intel/common/ff_map.v')
    if hardware_sclr and not hardware_sload:
        base=source/'provenance/sclr_model_verification'
        for item in model['model_provenance_files']:assert sha(base/item['path'])==item['sha256']
        assert model['formal_model_sha256']==sha(base/'dffeas_formal.v')
        assert model['validator_sha256']==sha(base/'endpoint_sclr_runner.py')
        assert model['independent_model_checks_report_sha256']==sha(base/'checks_002/report.json')
    assert len(model['cases'])==18
    for case in model['cases']:
        meta=cases[case['case']][case['arm']];assert case['json_sha256']==meta['source_sha256']
        assert case['counts']['ff']==case['counts']['high']+case['counts']['low']
    sources['modelsim_scope_audit']=source/'MODEL_SCOPE_AUDIT.json'
    results={}
    for key,folder,identifier in [('observable','test3_observable_figure','test3'),('sampling','pipeline_boundary_figure','pmux_case02_pipeline')]:
        ap=source/folder/'FIGURE_AUDIT.json';a=json.loads(ap.read_text(encoding='utf-8'));c=cases[identifier]
        assert a['candidate_label']==candidate and a['source_run_report_sha256']==sha(source/'simulation_report.json')
        assert a['source_vcd_sha256']==sha(source/identifier/'simulation.vcd') and a['source_csv_sha256']==sha(source/identifier/'samples.csv')
        assert a['candidate_json_sha256']==c['candidate']['source_sha256'] and a['reference_json_sha256']==c['reference']['source_sha256']
        assert a['signal_match_sha256']==sha(ap.parent/'SIGNAL_MATCH.json') and a['visual_review']['passed']
        if key=='observable':assert a['all_timestamp_q_and_enable_values_match'] and a['all_recorded_rising_edge_state_transitions_pass']
        else:
            assert a['all_recorded_state_transition_checks_pass'] and a['all_timestamp_q_and_enable_relation_checks_pass'] and a['actual_enable_lut_truth_table_pass']
            match=json.loads((ap.parent/'SIGNAL_MATCH.json').read_text(encoding='utf-8'))
            assert match['reference_ff_count']==match['candidate_ff_count']==24 and match['all_reference_ena_constant_one']
            assert all(row['actual_lut_output']==(row['en']|row['rst']) for row in match['actual_candidate_ena_gate']['truth_table'])
        for suffix,name in [('figure_audit','FIGURE_AUDIT.json'),('signal_match','SIGNAL_MATCH.json'),('caption','caption_zh.txt')]:sources[key+'_'+suffix]=ap.parent/name
        results[key]={'profile':a['profile'],'window_ns':a.get('window_ns',a.get('windows_ns')),'finite_record_only':True}
        if key=='observable':results[key].update(first_enable_ns=a['first_enable_ns'],first_q_one_ns=a['first_q_one_ns'])
    sload=None
    if hardware_sload:
        ap=source/'sload_selection_figure/FIGURE_AUDIT.json';a=json.loads(ap.read_text(encoding='utf-8'))
        match=json.loads((ap.parent/'SIGNAL_MATCH.json').read_text(encoding='utf-8'));case=cases['pmux_case02_pipeline']
        assert a['candidate_label']==candidate and a['source_run_report_sha256']==sha(source/'simulation_report.json')
        assert a['source_vcd_sha256']==sha(source/'pmux_case02_pipeline/simulation.vcd') and a['source_csv_sha256']==sha(source/'pmux_case02_pipeline/samples.csv')
        assert a['model_sha256']==model['model_sha256'] and a['signal_match_sha256']==sha(ap.parent/'SIGNAL_MATCH.json')
        assert a['actual_sload_state_transition_checks_pass'] and a['actual_asdata_driver_direct_ff_q_verified'] and a['visual_review']['passed']
        assert match['candidate_target']['source_json_sha256']==case['candidate']['source_sha256']
        assert match['asdata_actual_driver']['no_inversion_or_added_logic'] and match['candidate_target']['no_inversion_between_q_and_output']
        assert a['source_full_figure_audit_sha256']==sha(source/'pipeline_boundary_figure/FIGURE_AUDIT.json')
        assert [x['time_ps'] for x in a['selected_edges']]==[90000,140000]
        assert all(x['pass'] and x['post_candidate_q']==x['post_reference_q'] for x in a['selected_edges'])
        for suffix,name in [('figure_audit','FIGURE_AUDIT.json'),('signal_match','SIGNAL_MATCH.json'),('caption','caption_zh.txt')]:sources['sload_'+suffix]=ap.parent/name
        sload={'profile':a['profile'],'selected_edges':a['selected_edges'],'finite_record_only':True,'enabled_nonclear_edges_with_data_difference':a['enabled_nonclear_edges_with_data_difference']}
    return results['observable'],results['sampling'],{'contract':model['contract'],'limits':model['limits'],'cases':model['cases'],'validated_mapping_sha256':mapping_hash,
        'hardware_sclr':hardware_sclr,'formal_model_sha256':model.get('formal_model_sha256'),'simulator_model_sha256':model['model_sha256'],
        'validator_sha256':model.get('validator_sha256'),'model_checks_sha256':model.get('independent_model_checks_report_sha256'),'hardware_sload':hardware_sload,'sload_waveform':sload}
