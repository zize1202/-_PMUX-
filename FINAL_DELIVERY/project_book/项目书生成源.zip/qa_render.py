from book_settings import require_render, OUTPUT
require_render()
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import re,json,hashlib,shutil,sys
sys.stdout.reconfigure(encoding='utf-8')
import pypdfium2 as pdfium
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
from content import blocks,limits
R=Path(__file__).resolve().parent;O=OUTPUT
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(t):return re.sub(r'\s+','',t).replace('−','-').replace('\ufffe','-').replace('’',"'").replace('\u00ad','').translate(str.maketrans('₀₁₂₃₄₅₆₇₈₉','0123456789'))
expected=[]
for b in blocks:
 if b['kind']=='equation':continue
 expected.append(b['text'])
 if b['kind']=='table':expected.extend(b['headers']+[v for row in b['rows'] for v in row])
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
report={'tables':sum(b['kind']=='table' for b in blocks),'figures':sum(b['kind']=='figure' for b in blocks),'equations':sum(b['kind']=='equation' for b in blocks),'references':sum(b['kind']=='reference' for b in blocks),'word_limits':{k:{'count':len(v[0]),'limit':v[1]} for k,v in limits.items()},'pdfs':[]}
docx=O/'PMUX结构优化与等价验证系统_项目书.docx'
with ZipFile(docx) as z:
 for n in z.namelist():
  if n.endswith(('.xml','.rels')):E.fromstring(z.read(n))
 d=E.fromstring(z.read('word/document.xml'));txt=norm(''.join(d.xpath('//w:t/text()',namespaces=ns)))
 missing=[s for s in expected if norm(s) not in txt];assert not missing,missing
 ts=d.xpath('//w:tbl',namespaces=ns);assert len(ts)==report['tables']
 for t in ts:
  borders={E.QName(e).localname:e.get('{'+ns['w']+'}val') for e in t.find('w:tblPr/w:tblBorders',ns)}
  assert all(borders[k] in ('nil','none') for k in ('left','right','insideH','insideV'))
  assert borders['top']==borders['bottom']=='single'
  for c in t.xpath('./w:tr[1]/w:tc',namespaces=ns):assert c.find('w:tcPr/w:tcBorders/w:bottom',ns).get('{'+ns['w']+'}val')=='single'
 report['all_tables_three_line']=True;assert len(d.xpath('//m:oMath',namespaces=ns))==report['equations']
 embedded={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/') and not n.endswith('/')}
 assert all(sha(R/'figures'/b['file']) in embedded for b in blocks if b['kind']=='figure')
 report['docx_sha256']=sha(docx)
for kind,p in [('word',O/'PMUX结构优化与等价验证系统_项目书.pdf'),('latex',R/'compiler_qa/main.pdf')]:
 doc=pdfium.PdfDocument(str(p));out=R/('render_'+kind+'_final');out.mkdir(exist_ok=True);texts=[];page_index=[]
 for i,pg in enumerate(doc):
  t=pg.get_textpage().get_text_range();t=re.sub(r'^'+str(i+1)+r'\r?\n','',t);t=re.sub(r'\r?\n'+str(i+1)+r'\s*$','',t);texts.append(t);pg.render(scale=1.3).to_pil().save(out/f'page-{i+1:02}.png')
  page_index.append({'page':i+1,'start':t[:140],'text_chars':len(t)})
 missing=[s for s in expected if norm(s) not in norm('\n'.join(texts))]
 fonts={}
 for pg in PdfReader(str(p)).pages:
  for v in pg.get('/Resources',{}).get('/Font',{}).values():
   f=v.get_object();ds=f.get('/DescendantFonts');f2=ds[0].get_object() if ds else f;fd=f2.get('/FontDescriptor');fd=fd.get_object() if fd else {}
   fonts[str(f.get('/BaseFont'))]=any(k in fd for k in ['/FontFile','/FontFile2','/FontFile3'])
 report['pdfs'].append({'kind':kind,'pages':len(doc),'missing_text':missing,'fonts':fonts,'sha256':sha(p)})
 (out/'page_index.json').write_text(json.dumps(page_index,ensure_ascii=False,indent=2),encoding='utf-8')
 # Contact sheets provide an all-page pagination view; full resolution pages remain available.
 for start in range(0,len(doc),6):
  sheet=Image.new('RGB',(1200,1740),'#dddddd');dr=ImageDraw.Draw(sheet)
  for j in range(start,min(start+6,len(doc))):
   im=Image.open(out/f'page-{j+1:02}.png');im.thumbnail((580,810));x=(j-start)%2*600+(600-im.width)//2;y=(j-start)//2*580
   # Three columns / two rows allows legible page overview.
  sheet=Image.new('RGB',(1800,1700),'#dddddd');dr=ImageDraw.Draw(sheet)
  for j in range(start,min(start+6,len(doc))):
   im=Image.open(out/f'page-{j+1:02}.png');im.thumbnail((580,810));x=(j-start)%3*600+(600-im.width)//2;y=(j-start)//3*850+25
   sheet.paste(im,(x,y));dr.text((x,y-20),f'{kind} page {j+1}',fill='black')
  sheet.save(out/f'contact-{start+1:02}.jpg',quality=90)
log=(R/'compiler_qa/main.log').read_text(encoding='utf-8',errors='replace')
report['latex_warnings']=[l for l in log.splitlines() if re.search('Overfull|Underfull|Warning|Missing character|undefined',l)]
report['unexpected_controls']=[hex(ord(ch)) for ch in set(''.join(expected)) if (ord(ch)<32 and ch not in '\n\t\r') or ord(ch) in [0x200b,0x200c,0x200d,0x2060,0xfeff]]
report['status']='PASS' if not report['latex_warnings'] and not report['unexpected_controls'] and all(not p['missing_text'] and all(p['fonts'].values()) for p in report['pdfs']) else 'REVIEW'
(R/'FINAL_STRUCTURAL_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
