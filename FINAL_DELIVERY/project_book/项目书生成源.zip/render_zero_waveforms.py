"""Deferred real-VCD renderer. No run is permitted before candidate freeze."""
from book_settings import require_render, ROOT
D=require_render()
from pathlib import Path
import csv,json,re,bisect,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont('C:/Windows/Fonts/msyh.ttc')
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False})
BLUE='#245C83';TEAL='#137A72';GRAY='#697885';INK='#243746'
SIM=D['modelsim'];S=Path(D['sources']['modelsim']['path']).parent;OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
CASES={c['id']:c for c in SIM['cases']};qa=[]

from vcd_evidence import VCDReader
def VCD(identifier):return VCDReader(identifier,CASES,S,qa,sample_scope='prelude' if identifier=='test4' else 'all')

def canvas(title,labels,lo,hi,height):
 fig,ax=plt.subplots(figsize=(144/25.4,height/25.4));fig.subplots_adjust(left=.29,right=.97,top=.87,bottom=.15)
 ax.set(xlim=(lo,hi),ylim=(-.7,len(labels)-.3));ax.invert_yaxis();ax.set_yticks(range(len(labels)),labels)
 ax.tick_params(axis='y',length=0,labelsize=7.2,pad=4);ax.tick_params(axis='x',labelsize=7)
 ax.set_xlabel('仿真时间 / ns',fontsize=8);ax.grid(axis='x',color='#e1e6ea',lw=.5)
 for side in ['left','top','right']:ax.spines[side].set_visible(False)
 for i in range(len(labels)):ax.axhline(i+.45,color='#e1e6ea',lw=.5)
 fig.text(.03,.965,title,fontsize=10,color=INK,weight='bold',va='top')
 fig.text(.03,.91,'本次ModelSim真实VCD重绘 · 非GUI截图',fontsize=7.4,color=GRAY)
 fig.text(.03,.025,'参考为同逻辑零初态模型，非原默认面积基线；判错以CSV采样为准。',fontsize=6.3,color=GRAY)
 return fig,ax
def bit(ax,wave,name,row,lo,hi,color=GRAY):
 for a,b,v in wave.segments(name,lo,hi):
  if v is None:ax.fill_between([a,b],row-.25,row+.25,color='#f2d5cf');continue
  assert v in (0,1);y=row+(.25 if v==0 else -.25);ax.plot([a,b],[y,y],color=color,lw=.9)
 for t,v in wave.traces[name]:
  if lo<t<hi:ax.plot([t,t],[row-.25,row+.25],color=color,lw=.65)
 if name not in {'clk','rst','reset_n','en','ena'}:ax.text(hi-(hi-lo)*.015,row-.05,str(wave.at(name,hi)),ha='right',va='center',fontsize=7,color=color)
def bus(ax,wave,name,row,lo,hi,color=BLUE,digits=3,decimal=False):
 for a,b,v in wave.segments(name,lo,hi):
  tip=min((hi-lo)*.004,(b-a)*.15)
  for sign in [-1,1]:ax.plot([a,a+tip,b-tip,b],[row,row+sign*.23,row+sign*.23,row],color=color,lw=.8)
  label='X/Z' if v is None else str(v) if decimal else f'{v:0{digits}X}'
  if (b-a)/(hi-lo)>.014*len(label):ax.text((a+b)/2,row,label,ha='center',va='center',fontsize=6.8,color=color)
def save(fig,name):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=400)
 plt.close(fig)

t=VCD('test4');lo=0;hi=t.meta['vector_schedule_start_ns'];assert hi<t.meta['first_clock_edge_ns']
labels=['clk','reset_n','reference only_5b','candidate only_5b','reference outputs','candidate outputs','mismatch','unknown_output','contract_failed']
fig,ax=canvas('test4：无边沿初态与异步复位观察',labels,lo,hi,122)
for i,name in [(0,'clk'),(1,'reset_n'),(2,'reference_only_5b'),(3,'candidate_only_5b'),(6,'mismatch'),(7,'unknown_output'),(8,'contract_failed')]:bit(ax,t,name,i,lo,hi,BLUE if i==2 else TEAL if i>2 else GRAY)
bus(ax,t,'reference_outputs',4,lo,hi,BLUE);bus(ax,t,'candidate_outputs',5,lo,hi,TEAL)
points=[int(x['time_ps'])/1000 for x in t.meta['prelude_samples']]
for p in points:ax.axvline(p,color='#bdc7ce',ls=':',lw=.6)
ax.set_xticks(sorted(set([0]+points)));save(fig,'modelsim_zero_init')
sample_text='；'.join(f"{int(x['time_ps'])/1000:g}ns：reset_n={x['reset_n']}、only_5b={x['candidate_only_5b']}" for x in t.meta['prelude_samples'])
b=VCD('pmux_case01_balanced');b.low12();start=b.meta['vector_schedule_start_ns']
rst_fall=next(x for x,v in b.traces['rst'] if x>start and v==0);lo=max(0,rst_fall-1);hi=lo+160
labels=['clk','rst','en','ctrl_in [15:0]','data_in [11:0]','reference [11:0]','candidate [11:0]','mismatch','unknown_output']
fig,ax=canvas('balanced：撤销复位后的局部输出一致性',labels,lo,hi,122)
for i,name in [(0,'clk'),(1,'rst'),(2,'en'),(7,'mismatch'),(8,'unknown_output')]:bit(ax,b,name,i,lo,hi,GRAY if i<3 else TEAL)
for i,name,digits,color in [(3,'ctrl_in',4,GRAY),(4,'data_low12',3,GRAY),(5,'reference_outputs',3,BLUE),(6,'candidate_outputs',3,TEAL)]:bus(ax,b,name,i,lo,hi,color,digits)
save(fig,'modelsim_zero_detail');observed=[]
for row in b.rows:
 time=int(row['time_ps'])/1000
 if lo<=time<=hi and (not observed or observed[-1]!=row['candidate_hex']):observed.append(row['candidate_hex'])
finish=b.meta['finish_time_ns'];stop=b.meta['stop_time_ns'];lo=finish-81;hi=stop
labels=['clk','reference [11:0]','candidate [11:0]','checked','failed','finished','mismatch','unknown_output']
fig,ax=canvas('balanced：完成状态与累计比较计数',labels,lo,hi,110)
for i,name in [(0,'clk'),(4,'failed'),(5,'finished'),(6,'mismatch'),(7,'unknown_output')]:bit(ax,b,name,i,lo,hi,GRAY if i==0 else TEAL)
bus(ax,b,'reference_outputs',1,lo,hi,BLUE);bus(ax,b,'candidate_outputs',2,lo,hi,TEAL);bus(ax,b,'checked',3,lo,hi,GRAY,decimal=True)
ax.axvline(finish,color=GRAY,ls='--',lw=.8);ax.set_xticks([lo,lo+20,lo+40,lo+60,finish,stop]);save(fig,'modelsim_zero_finish')
notes={'candidate':D['candidate'],'paragraphs':[
 '图8检查test4在没有时钟边沿时的初始与复位行为。有效采样为：'+sample_text+f'。首个时钟边沿为{t.meta["first_clock_edge_ns"]}ns，正常向量从{t.meta["vector_schedule_start_ns"]}ns开始；不能把复位后的1误读为逻辑零初态输出。',
 f'图9中balanced于{rst_fall:g}ns撤销rst，两版采样输出依次为'+ '、'.join(observed[:6])+'等。蓝色为逻辑零参考，绿色为当前候选；data_in只展示低12位，完整激励保存在VCD。',
 f'图10显示balanced共{b.meta["cycles"]}周期、{b.meta["checked"]}次比较，seed={b.meta["seed"]}，在{finish}ns达到finished=1、failed=0；两版末值均为{b.at("candidate_outputs",finish):03X}。',
 f'三图对应{D["candidate"]}当前绑定仿真。test4图示6个隔离采样点与balanced全部CSV输出采样已和VCD逐项核对；图外test4同时间戳可能先采样后更新异步复位，判错以CSV为准。参考侧不是原默认面积基线。'
 ],'brief_figure':'modelsim_zero_init.png','brief_caption':'图1  当前test4真实VCD初态窗口（非GUI截图）','brief_reading':f'复位未激活且无时钟边沿时，两侧only_5b均为0；随后仅施加异步复位变为1。首个时钟边沿为{t.meta["first_clock_edge_ns"]}ns。参考侧声明同一逻辑零初态，不能称为原默认面积基线。'}
(ROOT/'current_wave_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'CURRENT_WAVEFORM_QA.json').write_text(json.dumps({'candidate':D['candidate'],'source':'real ModelSim VCD, not GUI screenshot','status':'PASS','cases':qa,'same_timestamp_policy':'last VCD record at timestamp; pass/fail at CSV samples'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'candidate':D['candidate'],'figures':3,'verified_samples':sum(x['csv_samples_verified'] for x in qa)},ensure_ascii=False))
