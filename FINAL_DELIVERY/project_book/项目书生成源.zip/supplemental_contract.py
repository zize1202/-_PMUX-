"""Bind a supplemental scale witness without adding it to the official cases."""
from pathlib import Path
import json, re
from measurement_contract import digest, validate_v3_report, validate_v3_case

def validate_scale(path, status, binary_sha, abc_sha):
    root=path.parent
    assert status['included_in_official_nine'] is False and status['official_mean_area_contribution'] is None
    assert status['status']=='PASS_SUPPLEMENTAL_SCALE_AND_WHOLE_WRAPPER_EQY'
    assert status['candidate_exe_sha256']==binary_sha and status['abc_sha256']==abc_sha
    paths={'performance':root/'performance_v3_multisource/report.json','endpoint':root/'endpoint_capture/report.json','formal':root/'formal_no_candidate_zinit/report.json'}
    data={}
    for key,p in paths.items():
        assert digest(p)==status['report_sha256'][key]
        data[key]=json.loads(p.read_text(encoding='utf-8'))
    perf=data['performance'];validate_v3_report(perf,supplemental=True)
    assert len(perf['cases'])==1
    case=perf['cases'][0];validate_v3_case(perf,case)
    for arm,prefix in [('baseline','baseline'),('optimized','optimized')]:
        c=case['aggregate'][arm+'_cells']
        assert c['logic_units']==status[prefix+'_logic_units'] and c['dff']==status[prefix+'_dff']
        assert sum(c['cell_types'].values())==status[prefix+'_actual_nodes']
        assert case['aggregate'][arm+'_mean_wall_seconds']==status[prefix+'_wall_seconds']
        assert case['aggregate'][arm+'_mean_peak_ws_bytes']==status[prefix+'_peak_ws_bytes']
    assert perf['binaries']['optimized']['sha256']==binary_sha
    assert digest(root/'pmux_supplemental_scale.v')==status['wrapper_sha256']
    endpoint=data['endpoint'];assert endpoint['valid'] and endpoint['full_json_byte_identical']
    assert digest(endpoint['postabc_path'])==status['postabc_sha256']==endpoint['postabc_sha256']
    assert digest(endpoint['full_capture_path'])==status['mapped_json_sha256']
    proof=data['formal'];assert proof['complete'] and len(proof['cases'])==1
    pc=proof['cases'][0];assert pc['status']=='PASS'
    assert pc['baseline']['source_sha256']==status['postabc_sha256']
    assert (paths['formal'].parent/pc['id']/'rb/PASS').is_file()
    script=(paths['formal'].parent/pc['id']/'baseline.normalize.ys').read_text(encoding='utf-8')
    assert not re.search(r'^\s*(zinit|setundef)\b',script,re.M)
    check=pc['checks'][0]
    assert check['eqy_raw_status']=='PASS' and check['partition_count']==1
    assert check['only_original_inputs_used_as_partition_inputs']
    assert check['proven_output_bit_counts']==check['expected_output_bit_counts']
    assert sum(check['additional_jointly_proved_state_relations'].values())==status['formal_joint_state_relation_bits']
    audit=json.loads((root/'formal_support/formal_result_audit.json').read_text(encoding='utf-8'))
    assert audit['status']=='PASS' and audit['public_output_bits_proven']==status['output_bits']
    assert audit['original_input_port_bits']==status['free_input_bits']
    assert audit['candidate_normalization_has_no_zinit_or_setundef'] and audit['induction_success']
    initial=audit['candidate_dffeas_explicit_power_up']
    assert set(initial)<=set(['low','high']) and sum(initial.values())==status['optimized_dff']
    return audit
