"""Explicit target mapping, distinct from the generic r28 state rewrite."""
def add_section(p,sub,eq,table,cases,development):
    sub('2.3.7  Cyclone IV限定的硬件同步清零与初态编码')
    p('前一阶段恢复硬件使能后，复位选择仍可能占用数据通路LUT。r29进一步在明确的Cyclone IV目标下连接寄存器SCLR端口。厂商控制优先级规定ENA先于同步清零[10]；因此保留新使能E′=E∨R，并将原复位R直接接入SCLR，得到：')
    eq('ENA=E OR R，SCLR=R；Q′=ENA?(SCLR?0:D):Q',r'\mathrm{ENA}=E\lor R,\quad \mathrm{SCLR}=R,\quad Q^{\prime}=\mathrm{ENA}\ ?\ (\mathrm{SCLR}\ ?\ 0:D):Q')
    p('R=1时ENA必为1，清零不会被外部E=0屏蔽；R=0时则恢复原使能采样或保持。此等式只给出二值控制域的状态转移依据，原生映射后的整设计正确性仍由实际端点完整EQY验证。')
    p('目标准入由synth_intel的family=cycloneiv显式传入opt_pmux -cycloneiv-sclr；其他器件族、不带此标志的命令及-init-zero模式不走这一映射。目标库还须提供端口方向、十个标量端口及两项参数均符合预期的dffeas黑盒声明。缺少目标声明或契约不合时保留通用$sdffce路径，不因同名模块而启用。')
    p('映射继续使用私有完整PMUX—D边界、正极性和全0同步复位等守卫。提交前用FfInitVals读取实际逻辑Q初值：只接收每一位均已知0/1的完整FF字，冲突的已定义别名按输入错误处理；未知初值回退，不虚构0。每位初值分别编码为power_up的low/high。只有已编码的Q位从线网init属性中清除，未改写位及其他Z位保留。')
    p('此目标映射将向量FF拆成等位数的标量dffeas，保留各位原CLK、D、Q与复位连接；它不再保留前一阶段的向量FF对象身份。先完成全部只读计划，再复用已生成的E∨R、提交器件单元和初值属性修改，之后重建索引。没有增加后ABC重写步骤，也未修改标准映射pass或ABC。')
    table('表3c  r29阶段独立模型的两个受限控制域',['域','控制前提','上升沿行为'],[
        ['沿用域','SCLR=0；PRN=1；ASDATA/ALOAD/SLOAD=0；CLRN可为真实异步清零','保留原受限FF映射语义'],
        ['新增域','CLRN=PRN=1；ASDATA/ALOAD/SLOAD=0；SCLR、ENA为二值控制','ENA=0保持；否则SCLR=1清零；否则取D']],[2.2,7.7,4.75])
    p(f"两域均要求正沿时钟、真实时钟/Q连接和明确power_up。新模型经过{development['model_validator_checks']}项准入检查，以及任意前态、8个自由布尔输入的单步SAT和真实模型实现的时序归纳；后者包含两种显式初值，并核对旧域退化和形式/仿真模型一致性。r29资格批次的九例候选有58位处于新增SCLR域，其他位使用旧域；候选归一化不补zinit或setundef。模型不是通用厂商库，不证明未知控制的任意四态调度、异步与同步清零任意混合或器件延迟。首次小模型检查因缺运行库以0xC0000135启动失败，修正启动PATH后新批次通过；失败记录保留。")
    p(f"原生目标与初态检查另有{development['native_mapping_checks']}个映射正例、{development['native_fallback_checks']}个正常回退记录，其中{development['native_exact_r28_fallbacks']}项与r28输出JSON逐字相同；1项冲突init按输入错误退出1。这些检查验证端口、初值和回退，不冒充独立语义证明。r29生产pipeline由原基线450降至{development['native_pipeline_logic']}个LUT+NOT；r28为{development['prior_pipeline_logic']}，两者均24个FF。该单例差额和不同批次耗时不能直接推广为普遍收益或因果加速。")
    p('Cyclone IV手册说明每个LAB的同步清零是共享控制资源[11]。本项目核验逻辑资源数量与受限功能模型，没有完成布局布线、LAB控制共享可行性或板级时序验证。FAQ C34不是对这一具体器件映射的点名确认；C149.1的解释边界不因当前结果而消失。')
