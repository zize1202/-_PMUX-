"""Small JSON/CSV preparation only. Does not run synthesis, simulation or rendering."""
from pathlib import Path
import argparse, csv, hashlib, json, math, re
from book_settings import ROOT, WORKSPACE, CONFIG, CONFIG_PATH, resolve
from measurement_contract import scope_for_report, validate_v3_report, validate_v3_case

IDS=['test1','test2','test3','test4','pmux_case01_balanced','pmux_case02_pipeline','pmux_case03_crossbar','pmux_case04_feedback','pmux_case05_nested']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(key):
    path=resolve(CONFIG[key]);return path,json.loads(path.read_text(encoding='utf-8'))
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def assert_ids(items):
    assert [x['id'] for x in items]==IDS,'All nine official cases, in manifest order, are required.'
def all_runs(c):
    yield from c['initial']
    for pair in c['rechecks']:
        yield from pair if isinstance(pair,list) else pair.get('runs',pair.get('pair',[]))

def prepare():
    bp,b=read('binding');pp,p=read('proof');fp,f=read('performance')
    assert b['proof_report_sha256']==sha(pp)
    assert b['performance_report_sha256']==sha(fp)
    assert b['candidate_binary_sha256']==f['binaries']['optimized']['sha256']
    runtime=resolve(CONFIG['runtime_root'])/'bin/yosys.exe' if CONFIG.get('runtime_root') else Path(f['binaries']['optimized']['path'])
    assert sha(runtime)==b['candidate_binary_sha256']==sha(resolve(CONFIG['candidate_root'])/'yosys.exe')
    assert runtime.resolve()==Path(f['binaries']['optimized']['path']).resolve()
    assert p['complete'] and f['complete'] and f['all_measurements_valid']
    assert b['source_proof_endpoint_and_production_binding_passed']
    assert_ids(b['cases']);assert_ids(p['cases']);assert_ids(f['cases'])
    assert p['manifest_sha256']==f['manifest_sha256']
    scope=scope_for_report(f)
    if scope['schema']==3:validate_v3_report(f)
    rows=[];abc=[];candidate_zinit=[];init_inventory=[];capture_inventory=[]
    for bc,pc,fc in zip(b['cases'],p['cases'],f['cases']):
        # The original runner calls its supplied candidate arm "baseline".
        # Normalize the role by bound endpoint hash, never by that label alone.
        assert bc['source_logical_zero_to_candidate']=='PASS' and pc['status']=='PASS'
        assert bc['proof_endpoint_sha256']==pc['baseline']['source_sha256']
        assert bc['proof_endpoint_sha256']==sha(resolve(CONFIG['candidate_root'])/fc['id']/'post_abc9.il')
        assert bc['captured_and_full_production_json_identical']
        assert (pp.parent/fc['id']/'rb/PASS').is_file()
        normalization=(pp.parent/fc['id']/'baseline.normalize.ys').read_text(encoding='utf-8')
        if re.search(r'^\s*zinit\b',normalization,re.M):candidate_zinit.append(fc['id'])
        assert not re.search(r'^\s*setundef\s+.*-zero',normalization,re.M)
        raw=json.loads((resolve(CONFIG['candidate_root'])/fc['id']/'post_abc9.json').read_text(encoding='utf-8'))
        mapped=[cell for module in raw['modules'].values() for cell in module.get('cells',{}).values() if cell['type']=='dffeas']
        assert all(cell['parameters'].get('power_up') in ['low','high'] for cell in mapped)
        normalized=json.loads((pp.parent/fc['id']/'baseline.normalized.json').read_text(encoding='utf-8'))
        state_bits=zero_bits=one_bits=0
        for module in normalized['modules'].values():
            init={}
            for net in module.get('netnames',{}).values():
                value=net.get('attributes',{}).get('init')
                if value is None:continue
                assert len(value)==len(net['bits'])
                for bit,value in zip(net['bits'],reversed(value)):
                    # Multiple aliased names may carry X alongside the defined init.
                    # Only conflicting defined values are contradictory.
                    if value in ['0','1']:
                        if init.get(bit) in ['0','1']:assert init[bit]==value
                        init[bit]=value
                    elif bit not in init:init[bit]=value
            for cell in module.get('cells',{}).values():
                if 'Q' not in cell.get('connections',{}):continue
                assert cell['type'] in ['$ff','$dff','$dffe','$adff','$adffe','$sdff','$sdffe','$sdffce','$dffsr','$dffsre']
                for bit in cell['connections']['Q']:
                    value=bit if isinstance(bit,str) else init.get(bit)
                    assert value in ['0','1'],'Candidate state must already have explicit init after inverse mapping.'
                    state_bits+=1;zero_bits+=value=='0';one_bits+=value=='1'
        assert state_bits==len(mapped)
        init_inventory.append({'id':fc['id'],'mapped_explicit_power_up':len(mapped),'missing_power_up':0,'normalized_state_bits':state_bits,'explicit_0':zero_bits,'explicit_1':one_bits,'unknown':0})
        checks=pc['checks'];assert checks and all(x['status']=='PASS' and x['eqy_raw_status']=='PASS' for x in checks)
        assert all(x['only_original_inputs_used_as_partition_inputs'] and x['partition_count']==1 for x in checks)
        assert all(x['proven_output_bit_counts']==x['expected_output_bit_counts'] for x in checks)
        a=fc['aggregate'];assert a['valid']
        if scope['schema']==3:
            capture_inventory.extend(validate_v3_case(f,fc))
            captured=Path(fc['untimed_area_captures']['optimized']['netlist'])
            actual=resolve(CONFIG['candidate_root'])/fc['id']/'mapped.netlist.json'
            assert json.loads(captured.read_text(encoding='utf-8'))==json.loads(actual.read_text(encoding='utf-8'))
            for capture in fc['untimed_area_captures'].values():abc.extend(capture['actual_abc_invocations'])
            for warmup in f['warmup']:
                if warmup['case_id']==fc['id']:abc.extend(warmup['actual_abc_invocations'])
        assert a['baseline_cells']['logic_units']==bc['frozen_baseline_logic']
        assert a['optimized_cells']['logic_units']==bc['candidate_logic']
        reduction=1-bc['candidate_logic']/bc['frozen_baseline_logic']
        assert math.isclose(reduction,a['area_reduction'],abs_tol=1e-12)
        assert a['pairs_in_aggregate']==(5 if fc['recheck_triggered'] else 1)
        if fc['recheck_triggered']:assert len(fc['rechecks'])==5
        runs=list(all_runs(fc));assert len(runs)==2+2*len(fc['rechecks'])
        for run in runs:
            assert run['valid'] and run['measurement_valid']
            commands=run['actual_abc_invocations'];assert commands
            assert all(x['matches_requested_binary_bytes'] and x['sha256']==f['abc']['sha256'] for x in commands)
            abc.extend(commands)
        rows.append(dict(id=fc['id'],**a,recheck_triggered=fc['recheck_triggered'],proof='PASS',proof_role='source_logical_zero_to_actual_candidate',proof_endpoint_sha256=bc['proof_endpoint_sha256']))
    mean=sum(x['area_reduction'] for x in rows)/9
    assert math.isclose(mean,b['mean_area_reduction'],abs_tol=1e-12)
    assert math.isclose(mean,f['mean_area_reduction'],abs_tol=1e-12)
    total_b=sum(x['baseline_cells']['logic_units'] for x in rows);total_o=sum(x['optimized_cells']['logic_units'] for x in rows)
    metrics={'mean_area_percent':100*mean,'baseline_sum':total_b,'optimized_sum':total_o,'weighted_percent':100*(1-total_o/total_b),
      'all_nonincrease':all(x['optimized_cells']['logic_units']<=x['baseline_cells']['logic_units'] for x in rows),
      'individual_at_least_20_count':sum(x['area_reduction']>=.2 for x in rows),
      'max_time_ratio':max(x['time_ratio'] for x in rows),'max_memory_ratio':max(x['memory_ratio'] for x in rows),
      'max_optimized_wall_seconds':max(x['optimized_mean_wall_seconds'] for x in rows),'max_optimized_peak_ws_bytes':max(x['optimized_mean_peak_ws_bytes'] for x in rows),
      'all_time_memory_within_5_percent':all(x['time_ratio']<=1.05 and x['memory_ratio']<=1.05 for x in rows),
      'strict_source_zero_proven_count':9,'rechecked_ids':[x['id'] for x in rows if x['recheck_triggered']]}
    current_sim=None;wave_ready=False;observable_waveform=None;sampling_waveform=None;simulation_model_scope=None;sources={'binding':bp,'proof':pp,'performance':fp}
    if CONFIG.get('modelsim'):
        sp,sim=read('modelsim');sources['modelsim']=sp
        assert sim['candidate_label']==CONFIG['candidate'],'Do not relabel older ModelSim evidence.'
        assert sim['complete'] and sim['all_nine_pass'];assert_ids(sim['cases'])
        candidate=resolve(CONFIG['candidate_root'])
        for c in sim['cases']:
            assert c['status']=='PASS' and c['mismatch_samples']==c['unknown_samples']==c['contract_failed']==0
            assert c['candidate']['source_sha256']==sha(candidate/c['id']/'post_abc9.json')
            for key in ['simulation.vcd','simulation.wlf','samples.csv']:
                q=sp.parent/c['id']/key;assert q.is_file() and c['artifacts'][key]['sha256']==sha(q)
        assert sim['total_checked']==sum(c['checked'] for c in sim['cases'])
        current_sim=sim;wave_ready=True
        if CONFIG.get('modelsim_checkpoint'):
            cp,checkpoint=read('modelsim_checkpoint');sources['modelsim_checkpoint']=cp
            assert checkpoint['checkpoint']==CONFIG['candidate'] and checkpoint['report_sha256']==sha(sp)
            assert checkpoint['all_nine_pass'] and checkpoint['total_checked']==sim['total_checked']
            replay=checkpoint['independent_test4_replay']
            assert replay['pass'] and replay['identical_csv'] and replay['primary_csv_sha256']==replay['replay_csv_sha256']
            assert replay['primary_csv_sha256']==sha(sp.parent/'test4/samples.csv')
        if CONFIG.get('modelsim_revision'):
            rp,revision=read('modelsim_revision');sources['modelsim_revision']=rp
            assert revision['candidate_label']==CONFIG['candidate']
            assert revision['simulation_rerun'] is False
            original=Path(revision['original_run_directory'])
            if revision.get('new_figure_group'):
                assert revision['original_four_figure_groups_rerendered'] is False and revision['changed_inherited_files']==[]
                assert revision['candidate_binary_sha256']==b['candidate_binary_sha256']
                assert revision['binding_v3_sha256']==sha(bp)
                original_index=json.loads((original/'FILE_MANIFEST.json').read_text(encoding='utf-8'))
                for item in original_index['files']:
                    assert sha(original/item['path'])==sha(rp.parent/item['path'])==item['sha256']
                ap=rp.parent/revision['new_figure_group']/'FIGURE_AUDIT.json'
                audit=json.loads(ap.read_text(encoding='utf-8'));test3=next(c for c in sim['cases'] if c['id']=='test3')
                assert sha(ap)==revision['figure_audit_sha256'] and audit['candidate_label']==CONFIG['candidate']
                assert audit['source_run_report_sha256']==sha(sp)
                assert audit['source_vcd_sha256']==sha(sp.parent/'test3/simulation.vcd')
                assert audit['source_csv_sha256']==sha(sp.parent/'test3/samples.csv')
                assert audit['candidate_json_sha256']==test3['candidate']['source_sha256']
                assert audit['all_timestamp_q_and_enable_values_match'] and audit['all_recorded_rising_edge_state_transitions_pass'] and audit['visual_review']['passed']
                assert audit['signal_match_sha256']==sha(ap.parent/'SIGNAL_MATCH.json')
                sources['observable_figure_audit']=ap
                sources['observable_signal_match']=ap.parent/'SIGNAL_MATCH.json'
                sources['observable_caption']=ap.parent/'caption_zh.txt'
                observable_waveform={'profile':audit['profile'],'first_enable_ns':audit['first_enable_ns'],'first_q_one_ns':audit['first_q_one_ns'],'window_ns':audit['window_ns'],'finite_record_only':True}
            else:
                assert revision['figures_rerendered'] is False
                for item in revision['unchanged_original_files']:
                    assert sha(original/item['path'])==sha(rp.parent/item['path'])==item['revision_sha256']==item['original_sha256']
                for item in revision['changed_original_files']:
                    assert sha(original/item['path'])==item['original_sha256']
                    assert sha(rp.parent/item['path'])==item['revision_sha256']
            manifest_path=rp.parent/'FILE_MANIFEST.json';sources['modelsim_revision_manifest']=manifest_path
            revision_index=json.loads(manifest_path.read_text(encoding='utf-8'))
            for item in revision_index['files']:assert sha(rp.parent/item['path'])==item['sha256']
    if CONFIG.get('native_checkpoint_mechanisms') and current_sim:
        from sampling_boundary_evidence import bind_mechanisms
        observable_waveform,sampling_waveform,simulation_model_scope=bind_mechanisms(sp.parent,current_sim,CONFIG['candidate'],runtime.parent.parent,sources,sha)
    scale=None
    if CONFIG.get('supplemental_scale'):
        from supplemental_contract import validate_scale
        scp,scale=read('supplemental_scale');sources['supplemental_scale']=scp
        scale['formal_audit']=validate_scale(scp,scale,b['candidate_binary_sha256'],f['abc']['sha256'])
    migration=None;migration_candidate=CONFIG.get('migration_evidence_candidate',CONFIG['candidate'])
    migration_bound=b
    if migration_candidate!=CONFIG['candidate']:
        mbp,migration_bound=read('migration_binding');sources['historical_migration_binding']=mbp
    if CONFIG.get('migration_qa'):
        mqp,migration=read('migration_qa');sources['migration_qa']=mqp
        assert migration['candidate_binary_sha256']==migration_bound['candidate_binary_sha256']
        assert migration['strict_audit']['all_selected_pass'] and not migration['official_nine_run']
        for artifact in migration['files']:assert sha(Path(artifact['path']))==artifact['sha256']
    migration_all=None
    if CONFIG.get('migration_all_qa'):
        mapath,migration_all=read('migration_all_qa');sources['migration_all_qa']=mapath
        assert migration_all['package_snapshot_identity']['candidate_sha256']==migration_bound['candidate_binary_sha256']
        assert migration_all['process_returncode_observed']==0 and migration_all['all_entrypoint_success']
        assert migration_all['all_local_objective_checks_pass'] and migration_all['formal_proof_all_nine_pass']
        assert migration_all['formal_pass_count']==9 and migration_all['measurement_and_capture_binding_pass']
        run=Path(migration_all['run'])
        for relative,digest in migration_all['report_hashes'].items():assert sha(run/relative)==digest
        archive=json.loads((run/'strict.archive.json').read_text(encoding='utf-8'))
        assert archive['all_file_hashes_verified'] and archive['raw_report_paths_rewritten'] is False
        assert archive['file_count']==len(archive['files'])==migration_all['proof_archive_validation']['file_count']
        unavailable_live_files=[]
        for item in archive['files']:
            assert sha(Path(archive['archive_directory'])/item['relative_path'])==item['sha256']
            live=Path(archive['execution_directory'])/item['relative_path']
            if live.is_file():assert sha(live)==item['sha256']
            else:unavailable_live_files.append(item['relative_path'])
        migration_all['preparation_archive_recheck']={'all_archived_files_match_recorded_sha256':True,
            'temporary_execution_files_unavailable_now':unavailable_live_files,
            'note':'Original execution/archive/index equality was audited at run completion. Durable archived bytes remain verified; temporary workspace availability is not a release dependency.'}
        failpath,failed=read('migration_failed_qa');sources['migration_failed_qa']=failpath
        assert failed['formal_pass_count']==5 and not failed['formal_proof_all_nine_pass']
        for relative,digest in failed['report_hashes'].items():assert sha(Path(failed['run'])/relative)==digest
    current_migration=None
    if CONFIG.get('current_migration_all_qa'):
        cmp,current_migration=read('current_migration_all_qa');sources['current_migration_all_qa']=cmp
        assert sha(cmp)==CONFIG['current_migration_all_qa_sha256']
        identity=current_migration['package_snapshot_identity']
        assert identity['candidate']==CONFIG['candidate']
        assert identity['candidate_sha256']==b['candidate_binary_sha256']
        assert identity['baseline_sha256']==f['binaries']['baseline']['sha256'] and identity['abc_sha256']==f['abc']['sha256']
        assert identity['current_official_binding_sha256']==sha(bp)
        assert current_migration['process_returncode_observed']==0 and current_migration['all_entrypoint_success']
        assert current_migration['all_local_objective_checks_pass'] and current_migration['formal_proof_all_nine_pass']
        assert current_migration['formal_pass_count']==9 and current_migration['formal_endpoint_binding_all_nine_pass']
        assert current_migration['measurement_and_capture_binding_pass'] and current_migration['actual_single_all_results_directory_count']==1
        run=Path(current_migration['run'])
        for relative,digest in current_migration['report_hashes'].items():assert sha(run/relative)==digest
        cr=json.loads((run/'report.json').read_text(encoding='utf-8'))
        assert cr['candidate']==CONFIG['candidate'] and cr['mode']=='All' and cr['complete'] and cr['success']
        assert cr['all_local_objective_checks_pass'] and cr['exit_code']==0
        cm=json.loads((run/'measure/report.json').read_text(encoding='utf-8'));validate_v3_report(cm);assert_ids(cm['cases'])
        assert cm['binaries']['optimized']['sha256']==b['candidate_binary_sha256']
        assert cm['binaries']['baseline']['sha256']==f['binaries']['baseline']['sha256'] and cm['abc']['sha256']==f['abc']['sha256']
        assert cm['manifest_sha256']==f['manifest_sha256'] and cm['all_time_and_memory_within_5_percent']
        assert cm['all_logic_not_increased'] and math.isclose(cm['mean_area_reduction'],f['mean_area_reduction'],abs_tol=1e-14)
        for current,main in zip(cm['cases'],f['cases']):
            validate_v3_case(cm,current)
            for arm in ['baseline','optimized']:
                assert current['aggregate'][arm+'_cells']['logic_units']==main['aggregate'][arm+'_cells']['logic_units']
        archive=json.loads((run/'strict.archive.json').read_text(encoding='utf-8'))
        assert archive['all_file_hashes_verified'] and archive['raw_report_paths_rewritten'] is False
        assert archive['file_count']==len(archive['files'])==current_migration['proof_archive_file_count']
        durable=Path(archive['archive_directory']);expected={x['relative_path'] for x in archive['files']}
        assert {x.relative_to(durable).as_posix() for x in durable.rglob('*') if x.is_file()}==expected
        unavailable=[]
        for item in archive['files']:
            assert sha(durable/item['relative_path'])==item['sha256']
            live=Path(archive['execution_directory'])/item['relative_path']
            if live.is_file():assert sha(live)==item['sha256']
            else:unavailable.append(item['relative_path'])
        ep,execution=read('current_migration_execution');sources['current_migration_execution']=ep
        assert sha(ep)==current_migration['actual_pwsh7_execution_record_sha256']
        assert execution['finished'] and execution['returncode']==0 and Path(execution['command'][0]).name.lower()=='pwsh.exe'
        for key in ['preparation_error_preserved','prior_windows_powershell_launch_error_preserved','historical_r23_preparation_error_preserved','historical_r23_windows_powershell_launch_error_preserved']:
            if key in current_migration:
                artifact=Path(current_migration[key]);assert artifact.is_file();sources['current_migration_'+key]=artifact
        if CONFIG.get('current_migration_storage_history'):
            storage=resolve(CONFIG['current_migration_storage_history']);assert sha(storage)==current_migration['storage_failure_history_sha256']
            sources['current_migration_storage_history']=storage
        if current_migration.get('restricted_model_runtime_sha256'):
            sload_model=bool(CONFIG.get('hardware_sload_verification'))
            modeldir=resolve(CONFIG['hardware_sload_verification'] if sload_model else CONFIG['hardware_sclr_verification'])
            modelmap={'endpoint_nozinit_runner.py':'endpoint_sload_runner.py' if sload_model else 'endpoint_sclr_runner.py','dffeas_formal.v':'dffeas_formal.v','legacy_endpoint_runner.py':'legacy_endpoint_runner.py','legacy_dffeas_formal.v':'legacy_dffeas_formal.v'}
            simname='dffeas_sload_sim.v' if sload_model else 'dffeas_sclr_sim.v';modelmap[simname]=simname
            assert current_migration['all_copied_models_and_sidecars_bound']
            assert current_migration['restricted_model_runtime_sha256']==identity['restricted_model_runtime_sha256']
            for target,original in modelmap.items():assert sha(modeldir/original)==current_migration['restricted_model_runtime_sha256'][target]
            for case in cm['cases']:assert sha(durable/case['id']/'dffeas_formal.v')==current_migration['restricted_model_runtime_sha256']['dffeas_formal.v']
        current_migration['preparation_archive_recheck']={'all_archived_files_match_recorded_sha256':True,
            'temporary_execution_files_unavailable_now':unavailable,'not_a_new_measurement_or_proof_run':True}
        current_migration['prepared_metrics']={'max_time_ratio':max(x['aggregate']['time_ratio'] for x in cm['cases']),
            'max_memory_ratio':max(x['aggregate']['memory_ratio'] for x in cm['cases']),
            'recheck_count':sum(bool(x['rechecks']) for x in cm['cases']),
            'rechecked_ids':[x['id'] for x in cm['cases'] if x['rechecks']]}
    native_build=None
    if CONFIG.get('native_build_manifest'):
        nbp,nb=read('native_build_manifest');sources['native_build_manifest']=nbp
        assert nb['yosys_sha256']==b['candidate_binary_sha256']
        commands={x['label']:x for x in nb['commands']}
        assert all(commands[x]['exit_code']==0 for x in ['build','install','version','help'])
        logs={}
        for label in ['build','install','version','help']:
            log=nbp.parent/(label+'.log');assert log.is_file();sources['native_'+label+'_log']=log
            logs[label]={'path':str(log),'sha256':sha(log),'exit_code':commands[label]['exit_code']}
        native_build={'candidate_binary_sha256':nb['yosys_sha256'],'commands_succeeded':True,'logs':logs}
        source_files=[]
        for q in sorted((resolve(CONFIG['candidate_root'])/'source').iterdir()):
            if q.is_file():
                assert sha(q)==nb['source_after'][q.name]
                source_files.append({'path':str(q),'sha256':sha(q)})
        dump(ROOT/'SOURCE_BINDING.json',{'candidate':CONFIG['candidate'],'runtime_root':str(runtime.parent.parent),
             'runtime_sha256':sha(runtime),'shared_build_used':False,'source_files':source_files})
    sampling_development=None
    if CONFIG.get('sampling_boundary_development'):
        from sampling_boundary_evidence import bind_development
        if CONFIG.get('sampling_development_reference'):
            ref=CONFIG['sampling_development_reference'];refpath=resolve(ref['binding']);refbinding=json.loads(refpath.read_text(encoding='utf-8'))
            sources['prior_sampling_boundary_binding']=refpath
            sampling_development=bind_development(resolve(CONFIG['sampling_boundary_development']),resolve(ref['candidate_root']),refbinding['candidate_binary_sha256'],sources,sha)
            sampling_development['historical_development_not_current_rerun']=True
        else:
            sampling_development=bind_development(resolve(CONFIG['sampling_boundary_development']),resolve(CONFIG['candidate_root']),b['candidate_binary_sha256'],sources,sha)
    hardware_development=None
    if CONFIG.get('hardware_sclr_development'):
        from hardware_sclr_evidence import bind as bind_hardware
        ref=CONFIG.get('hardware_sclr_development_reference')
        if ref:
            refpath=resolve(ref['binding']);refbinding=json.loads(refpath.read_text(encoding='utf-8'));sources['prior_sclr_binding']=refpath
            hardware_development=bind_hardware(resolve(CONFIG['hardware_sclr_development']),resolve(CONFIG['hardware_sclr_verification']),resolve(ref['candidate_root']),resolve(ref['proof']).parent,refbinding['candidate_binary_sha256'],sources,sha)
            hardware_development['historical_development_not_current_rerun']=True
        else:
            hardware_development=bind_hardware(resolve(CONFIG['hardware_sclr_development']),resolve(CONFIG['hardware_sclr_verification']),resolve(CONFIG['candidate_root']),pp.parent,b['candidate_binary_sha256'],sources,sha)
            if simulation_model_scope:
                for key in ['formal_model_sha256','simulator_model_sha256','validator_sha256','model_checks_sha256']:assert hardware_development[key]==simulation_model_scope[key]
    sload_development=None
    if CONFIG.get('hardware_sload_development'):
        from hardware_sload_evidence import bind as bind_sload
        sload_development=bind_sload(resolve(CONFIG['hardware_sload_development']),resolve(CONFIG['hardware_sload_verification']),resolve(CONFIG['candidate_root']),pp.parent,b['candidate_binary_sha256'],sources,sha)
        if simulation_model_scope:
            for key in ['formal_model_sha256','simulator_model_sha256','validator_sha256','model_checks_sha256']:assert sload_development[key]==simulation_model_scope[key]
    environment_note=None
    if CONFIG.get('performance_environment_note'):
        ep,environment_note=read('performance_environment_note');sources['performance_environment_note']=ep
        assert environment_note['global_environment_changed'] is False
        assert Path(f['binaries']['baseline']['path']).drive[0]==environment_note['baseline_install_volume']
        assert Path(f['binaries']['optimized']['path']).drive[0]==environment_note['optimized_install_volume']
    vendor_ff=None
    if CONFIG.get('vendor_ff_report'):
        vp,vr=read('vendor_ff_report');ap=vp.parent.parent/'INDEPENDENT_AUDIT.json';va=json.loads(ap.read_text(encoding='utf-8'))
        package=vp.parent.parent/'PACKAGE_AUDIT.json';vpkg=json.loads(package.read_text(encoding='utf-8'))
        assert vr['status']=='PASS' and vr['complete'] and vr['all_nine_pass'] and vr['candidate_label']==CONFIG['candidate']
        assert vr['source_report_sha256']==sha(sp) and not vr['compiled_local_dffeas']
        assert vr['original_library_unchanged'] and vr['base_ini_unchanged'] and vr['frozen_checkpoint_unchanged']
        assert va['passed'] and vpkg['passed'] and va['run_report_sha256']==vpkg['report_sha256']==sha(vp)
        assert va['total_checked']==vr['total_checked']==40684 and va['total_initial_ff_q_verified']==643
        assert vpkg['audit_sha256']==sha(ap) and vpkg['no_vendor_binary_libraries_in_zip']
        assert {x['id'] for x in vr['cases']}==set(IDS)
        current={x['id']:x for x in current_sim['cases']}
        for row in vr['cases']:
            assert row['status']=='PASS' and row['failed_samples']==row['unknown_samples']==row['contract_failed_samples']==0
            assert row['identical_frozen_sample_trace'] and row['all_initial_q_match'] and not row['local_dffeas_loaded']
            assert (not row['ff_instances'] or 'dffeas' in row['loaded_vendor_units']) and all(x['returncode']==0 for x in row['commands'])
            assert sha(vp.parent/row['id']/'samples.csv')==row['csv_sha256']==current[row['id']]['artifacts']['samples.csv']['sha256']
        assert sum(x['initial_q_values_compared'] for x in vr['cases'])==643
        sources.update(vendor_ff_report=vp,vendor_ff_independent_audit=ap,vendor_ff_package_audit=package)
        vendor_ff={'status':'PASS','total_samples':40684,'initial_ff_instances_both_arms':643,'actual_vendor_ff_only':True,
            'seven_book_figures_from_restricted_model_not_vendor_run':True,'old_probe_error_preserved':True,
            'report_sha256':sha(vp),'archive_sha256':vpkg['zip_sha256']}
    prior_r23_migration=None
    if CONFIG.get('prior_r23_migration_reference'):
        info=CONFIG['prior_r23_migration_reference'];q=resolve(info['current_migration_all_qa']);prior_r23_migration=json.loads(q.read_text(encoding='utf-8'))
        assert sha(q)==info['current_migration_all_qa_sha256'] and prior_r23_migration['formal_pass_count']==9
        assert prior_r23_migration['all_local_objective_checks_pass'] and prior_r23_migration['package_snapshot_identity']['candidate']!=CONFIG['candidate']
        sources['prior_r23_migration_qa']=q
    observable_development=None
    if CONFIG.get('observable_development_report'):
        odp,od=read('observable_development_report');onp,on=read('observable_development_manifest')
        sources.update(observable_development_report=odp,observable_development_manifest=onp)
        assert od['all_cases_pass'] and od['exe_sha256']==on['yosys_sha256']
        assert sha(resolve(CONFIG['candidate_root'])/'source/pmux_observable_decode.h')==on['source_after']['pmux_observable_decode.h']
        positive=[v for v in od['cases'].values() if v['expected_rewrites']==1]
        negative=[v for v in od['cases'].values() if v['expected_rewrites']==0]
        assert all(v['guard_pass'] and v['transition_sat']['status']=='PASS' and v['transition_sat']['assumptions']==[] for v in positive)
        assert all(v['guard_pass'] and v['entire_json_unchanged'] for v in negative)
        assert od['four_state_factor']['status']=='PASS'
        observable_development={'version':'r23','positive_transition_sat_cases':len(positive),'rejected_unchanged_cases':len(negative),'four_state_factor_equations':od['four_state_factor']['equations'],'same_observable_header_bytes':True,'execution_is_current_binary':od['exe_sha256']==b['candidate_binary_sha256'],'included_in_official_nine':False}
    observable_isolation=None
    if CONFIG.get('observable_isolation_reports'):
        arms={}
        for label,relative in CONFIG['observable_isolation_reports'].items():
            ip=resolve(relative);record=json.loads(ip.read_text(encoding='utf-8'));sources['observable_isolation_'+label]=ip
            pair={}
            for arm in ['control','candidate']:
                mapped=record['mapped'][arm]
                endpoint=ip.parent/arm/'test3/post_abc9.il'
                assert sha(endpoint)==mapped['post_abc9_sha256']
                pair[arm]=mapped.get('logic_units',mapped.get('LUT_plus_NOT'))
                pair[arm+'_endpoint_sha256']=mapped['post_abc9_sha256']
            arms[label]=pair
        observable_isolation={'arms':arms,'factor_and_combined_control_bytes_identical':arms['factor']['control_endpoint_sha256']==arms['combined']['control_endpoint_sha256'],'care_and_factor_control_bytes_identical':arms['care']['control_endpoint_sha256']==arms['factor']['control_endpoint_sha256'],'same_native_ablation_batch':False}
    same_control_ablation=None
    if CONFIG.get('same_control_ablation'):
        acp,ac=read('same_control_ablation');sources['same_control_ablation']=acp
        assert ac['status']=='COMPLETE_SAME_CONTROL_ABLATION'
        assert ac['same_control_input_IR_bytes'] and ac['same_control_post_ABC_bytes'] and ac['same_frozen_Yosys_and_ABC'] and ac['same_normal_mapping_script_except_input_path']
        for original,digest in ac['frozen_hashes'].items():assert sha(Path(original))==digest
        comparison=ac['same_control_four_group_comparison']
        for label in ['care_only','H_only','care_plus_H']:
            row=comparison[label];proof_path=Path(row['strict_report']);proof_record=json.loads(proof_path.read_text(encoding='utf-8'))
            sources['same_control_'+label+'_proof']=proof_path
            case=next(v for v in proof_record['cases'] if v['id']=='test3')
            assert case['status']=='PASS' and case['baseline']['source_sha256']==row['candidate_post_abc9_sha256']
            assert (proof_path.parent/'test3/rb/PASS').is_file()
            script=(proof_path.parent/'test3/baseline.normalize.ys').read_text(encoding='utf-8')
            assert not re.search(r'^\s*(zinit|setundef)\b',script,re.M)
        assert comparison['control']['control_only_proof_repeated'] is False
        same_control_ablation={'comparison':comparison,'control_bytes_verified':True,'same_frozen_flow':True,'interaction_difference':ac['interaction_difference_in_logic_units'],'all_four_proofs_newly_executed':False,'included_in_official_nine':False}
    signed_coverage=None
    if CONFIG.get('signed_coverage_report'):
        srp,signed=read('signed_coverage_report');spp,signed_proof=read('signed_coverage_proof')
        sources.update(signed_coverage_report=srp,signed_coverage_proof=spp)
        assert signed_proof['status']=='PASS' and signed_proof['free_input_bits']==17 and signed_proof['assumptions']==[]
        assert signed['exe_sha256']==signed_proof['exe_sha256']
        assert signed['r21_counts']['netlist_sha256']==signed_proof['measured_final_json_sha256']
        assert signed['source_sha256']==signed_proof['source_sha256']
        current_logic=None
        if CONFIG.get('current_signed_capture'):
            scp,signed_current=read('current_signed_capture');sources['current_signed_capture']=scp
            assert signed_current['exe_sha256']==b['candidate_binary_sha256'] and signed_current['exit_code']==0
            assert signed['source_sha256']==signed_current['source_sha256']
            current_logic=signed_current[CONFIG['candidate'].split('_')[0]+'_counts']['logic_units']
        signed_coverage={'proof_version':'r21','reference_logic':signed['r20_counts']['logic_units'],'r21_logic':signed['r21_counts']['logic_units'],
                         'current_logic':current_logic,'current_version':CONFIG['candidate'] if current_logic is not None else None,
                         'free_input_bits':17,'r21_source_to_measured_mapped_sat':'PASS','included_in_official_nine':False}
    micro_path,micro=read('microregression');sources['microregression']=micro_path
    assert micro['all_ten_init_microregressions_have_checked_pass_evidence'] and micro['idempotence_cases_passed']==3
    history=[];versions={}
    for q in sorted(set((WORKSPACE/'work/20261101_pessimistic_optimization').glob('r*_binding*.json'))|{bp}):
        version=q.stem.split('_')[0]
        x=json.loads(q.read_text(encoding='utf-8'))
        schema=3 if x.get('schema')==3 else 2
        versions[(version,schema)]=(q,x)
    def version_key(pair):
        match=re.fullmatch(r'r(\d+)([a-z]*)',pair[0][0]);assert match
        return int(match[1]),match[2],pair[0][1]
    for (version,schema),(q,x) in sorted(versions.items(),key=version_key):
        if int(re.match(r'r(\d+)',version)[1])>int(re.match(r'r(\d+)',CONFIG['candidate'])[1]):continue
        history.append({'version':version,'measurement_schema':schema,'measurement_scope':'v3 两命令' if schema==3 else 'v2 含导出','binding_sha256':sha(q),'mean_area_percent':x['mean_area_reduction']*100,'strict_proof':x['all_nine_source_logical_zero_proven'],'efficiency':x['all_time_and_memory_within_5_percent']})
    snap={'schema':1,'phase':CONFIG['phase'],'candidate':CONFIG['candidate'],'release_ready':CONFIG['phase']=='frozen' and wave_ready and not candidate_zinit,
      'configuration_sha256':sha(CONFIG_PATH),
      'candidate_side_normalization_has_zinit':bool(candidate_zinit),'candidate_zinit_case_ids':candidate_zinit,
      'proof_origin':CONFIG.get('proof_origin',{'mode':'unspecified','version':None}),
      'candidate_initialization_inventory':init_inventory,
      'measurement_scope':scope,'untimed_capture_inventory_binding':capture_inventory,
      'runtime_root':str(runtime.parent.parent),'supplemental_scale':scale,
      'migration_qa':migration,'migration_all_qa':migration_all,'current_migration_all_qa':current_migration,'native_build':native_build,
      'historical_migration_evidence_candidate':migration_candidate,
      'migration_evidence_candidate':CONFIG['candidate'] if current_migration else migration_candidate,
      'migration_evidence_is_current':bool(current_migration) or migration_candidate==CONFIG['candidate'],'signed_coverage':signed_coverage,
      'features':CONFIG['features'],'cases':rows,'metrics':metrics,'modelsim':current_sim,'current_wave_ready':wave_ready,
      'modelsim_evidence_revision':CONFIG.get('modelsim_revision'),
      'observable_waveform':observable_waveform,
      'sampling_waveform':sampling_waveform,'sampling_boundary_development':sampling_development,'simulation_model_scope':simulation_model_scope,'hardware_sclr_development':hardware_development,'hardware_sload_development':sload_development,'performance_environment_note':environment_note,
      'prior_r23_migration_all_qa':prior_r23_migration,'vendor_ff':vendor_ff,
      'observable_development':observable_development,
      'observable_isolation':observable_isolation,
      'same_control_ablation':same_control_ablation,
      'microregression':{'version':'r11_native_storage_zero','passed_cases':len(micro['cases']),'idempotence_passed':3,'scope':micro['scope']},
      'history':history,'measurement_policy':f['policy'],'abc':{'sha256':f['abc']['sha256'],'all_actual_invocations_match':True,'invocations_checked':len(abc)},
      'binary_sha256':b['candidate_binary_sha256'],'manifest_sha256':f['manifest_sha256'],'manifest_cases':f['manifest']['cases'],
      'sources':{k:{'path':str(v),'sha256':sha(v)} for k,v in sources.items()},'contest_score':None,
      'initialization_contract':{'source':'unspecified clocked FF bits=0; explicit0/1 preserved','candidate':'actual default-script endpoint; no proof-side repair','area_baseline':'original default-script baseline, unchanged','simulation_reference':'original compiler with preoptimization logical-zero contract; not area baseline','arbitrary_initial_state_equivalence':False,'old_test4_strict_counterexample_retained':True}}
    dump(ROOT/'evidence_snapshot.json',snap)
    fields=['id','measurement_scope','baseline_logic','optimized_logic','reduction_percent','time_ratio','memory_ratio','pairs','recheck','strict_proof']
    with (ROOT/'current_results.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        out=csv.DictWriter(stream,fieldnames=fields);out.writeheader()
        for c in rows:out.writerow(dict(id=c['id'],measurement_scope=scope['code'],baseline_logic=c['baseline_cells']['logic_units'],optimized_logic=c['optimized_cells']['logic_units'],reduction_percent=100*c['area_reduction'],time_ratio=c['time_ratio'],memory_ratio=c['memory_ratio'],pairs=c['pairs_in_aggregate'],recheck=c['recheck_triggered'],strict_proof=c['proof']))
    print(json.dumps({'candidate':snap['candidate'],'release_ready':snap['release_ready'],'metrics':metrics,'sources_verified':len(sources),'abc_invocations_verified':len(abc)},ensure_ascii=False))

if __name__=='__main__':prepare()
