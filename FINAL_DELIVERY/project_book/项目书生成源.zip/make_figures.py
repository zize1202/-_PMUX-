from book_settings import require_render, OUTPUT
require_render()
from pathlib import Path
R=Path(__file__).resolve().parent
source=(R/'diagram_primitives.py').read_text(encoding='utf-8')
exec(compile(source,'shared_diagram_primitives','exec'))
from content import cases,short,D,FEATURES,SCOPE
OUT.mkdir(exist_ok=True)
qa=[]
s=Scene('architecture',132)
for y,title,subtitle,color in [(3,'原始RTL → proc','同一外部脚本；源文件与默认参数保持',BLUE),(25,'opt_pmux -init-zero','未指定时钟状态声明为0；显式0/1保持',TEAL),(47,'原生顺序优化 → coarse','wreduce → peepopt → opt_clean',INK),(69,'opt_pmux 词级结构优化','共享控制、运算、选择与小ROM',BLUE),(91,'cmp2lut → 后续综合 → ABC9','统一后端；两臂实际ABC哈希一致',INK)]:
 s.node(12,y,120,16,title,subtitle,color,size=9)
 if y<91:s.line([(72,y+16),(72,y+22)],arrow=True)
s.line([(72,107),(72,112),(36,112),(36,116)],arrow=True);s.line([(72,112),(109,112),(109,116)],arrow=True)
s.node(3,116,66,13,'资源与效率分别绑定',color=TEAL,size=9)
s.node(78,116,63,13,'ABC9后实际证明端点',color=BLUE,size=9)
qa.append(s.save())
s=Scene('control_recovery',90)
s.text(36,5,'精确译码回收',10,BLUE,True);s.text(108,5,'优先MUX链',10,TEAL,True)
for x,col,lines in [(4,BLUE,[('≤6个控制位','最多64种赋值'),('逐项求值选择函数','默认或唯一有效分支'),('建立共享数据树','显式X/Z叶保持')]),(77,TEAL,[('原优先级链','保持分支先后关系'),('构造剩余有效掩码','此前均未命中'),('共享掩码与输出组合','保留默认分支')])]:
 for i,(a,b) in enumerate(lines):
  y=14+i*24;s.node(x,y,63,17,a,b,col,size=9)
  if i<2:s.line([(x+31.5,y+17),(x+31.5,y+24)],color=col,arrow=True)
s.text(72,86,'无法确认语义或超出结构预算 → 保留原结构',8.3,GRAY)
qa.append(s.save())
s=Scene('word_factor',88)
s.text(34,5,'变换前：分支分别计算',9.5,BLUE,True);s.text(109,5,'变换后：共享一次运算',9.5,TEAL,True)
s.node(4,15,27,15,'X + V0',color=BLUE,size=10);s.node(38,15,27,15,'X + V1',color=BLUE,size=10)
s.node(14,47,43,15,'MUX(s)',color=BLUE,size=10)
s.line([(17.5,30),(17.5,39),(27,39),(27,47)],arrow=True);s.line([(51.5,30),(51.5,39),(44,39),(44,47)],arrow=True)
s.line([(35.5,62),(35.5,72)],arrow=True);s.text(35.5,76,'Y',11,BLUE)
s.node(84,15,49,15,'MUX(s, V0, V1)',color=TEAL,size=9)
s.node(87,47,43,15,'X + 所选V',color=TEAL,size=10)
s.line([(108.5,30),(108.5,47)],arrow=True);s.line([(108.5,62),(108.5,72)],arrow=True);s.text(108.5,76,'Y',11,TEAL)
s.text(72,85,'条件：默认分支、位宽、符号与消费者关系均保持',8,GRAY)
qa.append(s.save())
steps=[('通用结构扫描与预算','无用例名特判；不适用时保守退出')]
if 'small_rom' in FEATURES:steps.append(('有界小ROM精确共享','余因子 / 残差修正；32地址校验' if 'exact_rom_residual' in FEATURES else '完整32字、5位地址、2—16位输出'))
if 'width3_mixed_carry' in FEATURES:steps.append(('三位XOR / ADD / SUB共享传递链','匹配签名；互斥且可达；原状态保持' if 'signed_carry3' in FEATURES else '互斥且可达；原默认分支与状态保持'))
steps += [('多层数据通路与双输出bank','逐项检查共享条件，保留不适用结构'),('全字资源共享 → 闭合DAG','消费者与保护属性检查')]
if 'postdag_private_arithmetic' in FEATURES:steps.append(('后DAG互斥复核与私有算术共享','最多256项；不沿用未经重证的互斥'))
steps.append(('四分支分组 / 优先掩码 → 控制恢复','完整四层零默认链精确分组；统一映射') if 'priority_group4' in FEATURES else ('优先MUX掩码 → 精确控制恢复','保留默认分支；随后统一映射'))
if 'priority_net_skip' in FEATURES:steps[-1]=('优先链处理 → PMUX控制恢复','MUX不足3时跳过前者Net；后者仍执行')
if 'branch_constant_propagation' in FEATURES:steps[-1]=('分支常量传播 → 控制处理','随后优先链处理与PMUX控制恢复')
if 'sampling_boundary' in FEATURES:
 steps[-1]=('分支常量传播 → 采样边界重述','保持复位优先：新EN = EN OR SRST')
 if 'hardware_sclr' in FEATURES:steps.append(('Cyclone IV硬件同步清零','已知初态逐位编码；ENA优先于SCLR'))
 if 'hardware_sload' in FEATURES:steps.append(('互斥叶分支 → SLOAD / ASDATA','全消费者合格；使能、清零优先级保持'))
 steps.append(('优先链处理 → PMUX控制恢复','完整条件与默认分支保持'))
if 'observable_decode_joint' in FEATURES:steps.append(('采样域数据简化与公共译码共享','先证使能与完整消费者；两计划同提交'))
from candidate_flow_layout import draw_candidate_flow
s=draw_candidate_flow(Scene,steps,BLUE,TEAL)
qa.append(s.save())
s=Scene('proof_chain',119)
s.node(10,3,124,17,'原始RTL + 明确逻辑零初态契约','显式0/1保持；clock / reset / enable输入自由',BLUE,size=9)
s.line([(72,20),(72,25),(35,25),(35,31)],arrow=True)
s.line([(72,25),(109,25),(109,31)],arrow=True)
s.node(2,31,66,24,'源侧形式参考','逻辑0约束；完整状态语义',BLUE,size=9)
s.node(77,31,65,24,'实际候选端点','默认综合；无证明侧补初值',TEAL,size=9)
s.line([(35,55),(35,62),(72,62),(72,68)],arrow=True)
s.line([(109,55),(109,62),(72,62)],arrow=False)
s.node(10,68,124,20,'完整EQY：全部输出与状态关系共同证明','实际端点哈希 = 捕获端点；生产资源绑定',BLUE,size=8.8)
s.text(72,97,'9例源逻辑零初态 → 当前候选 PASS',9,TEAL,True)
s.text(72,108,'面积与效率另用原默认基线；不声称旧物理全0端点等价',8,GRAY)
qa.append(s.save())

def finish(fig,name):
 fig.savefig(OUT/(name+'.png'),dpi=400);fig.savefig(OUT/(name+'.pdf'));fig.savefig(OUT/(name+'.svg'));plt.close(fig)
fig,ax=plt.subplots(figsize=(144/25.4,97/25.4));fig.subplots_adjust(left=.20,right=.96,top=.95,bottom=.14)
labels=[short(c['id']) for c in cases];values=[100*c['area_reduction'] for c in cases]
ax.barh(labels,values,color=BLUE,height=.55);ax.invert_yaxis();ax.set_xlim(0,max(50,max(values)+6));ax.set_xlabel('LUT+NOT缩减率 / %',fontsize=9)
ax.axvline(20,color=GRAY,ls='--',lw=.9);ax.text(20.5,7.75,'20%参考线',fontsize=8,color=GRAY)
for i,v in enumerate(values):ax.text(v+.7,i,f'{v:.2f}%',va='center',fontsize=8)
ax.spines[['top','right']].set_visible(False);ax.tick_params(labelsize=8);finish(fig,'area_results')
fig,ax=plt.subplots(figsize=(144/25.4,97/25.4));fig.subplots_adjust(left=.20,right=.96,top=.90,bottom=.16)
for i,c in enumerate(cases):
 ax.plot(c['time_ratio'],i-.12,'o',color=BLUE,ms=4,label='墙钟比' if i==0 else None)
 ax.plot(c['memory_ratio'],i+.12,'s',color=TEAL,ms=4,label='峰值工作集比' if i==0 else None)
ax.set_yticks(range(9),labels);ax.invert_yaxis();ax.set_xlim(min(.7,min(min(c['time_ratio'],c['memory_ratio']) for c in cases)-.03),max(1.08,max(max(c['time_ratio'],c['memory_ratio']) for c in cases)+.03));ax.axvline(1.05,color=GRAY,ls='--',lw=1);ax.axvline(1,color='#cccccc',lw=.7)
ax.set_xlabel('优化版 / 基线（'+SCOPE['short']+'）',fontsize=9);ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),ncol=2,frameon=False,fontsize=8)
ax.spines[['top','right']].set_visible(False);ax.tick_params(labelsize=8);finish(fig,'performance_results')
(R/'DIAGRAM_GEOMETRY_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'FIGURE_DATA.json').write_text(json.dumps({'n':9,'missing':0,'measurement_scope':SCOPE,'replicates_per_arm':{c['id']:c['pairs_in_aggregate'] for c in cases},'statistics':'initial pair or exactly five recheck pairs under frozen policy; no error bars','fig6':'all nine area reductions shown with 20% reference, not a per-case requirement','fig7':'all nine wall and peak-WS ratios shown with 1.05 ceiling','cases':cases},ensure_ascii=False,indent=2),encoding='utf-8')
print('Created 5 vector diagrams and 2 data figures')
