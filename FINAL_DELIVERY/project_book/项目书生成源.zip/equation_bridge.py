"""Translate supported logical symbols for the native Word equation parser."""
def normalize_for_docx(tex):
    for old,new in [(r'\land','∧'),(r'\lor','∨'),(r'\bigwedge','⋀'),(r'\neg','¬'),
                    (r'\Longrightarrow','⇒'),(r'\Rightarrow','⇒'),(r'\bigvee','⋁'),
                    (r'\oplus','⊕'),(r'\in ','∈ '),(r'\prime','′')]:
        tex=tex.replace(old,new)
    return tex
