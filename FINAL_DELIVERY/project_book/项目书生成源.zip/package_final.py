"""Assemble final reader materials around the byte-frozen, reproduced core."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED
import hashlib, json, shutil, datetime, sys
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parent
F=R.parent; B=F/'PMUX_R30_ProjectBook'
C=Path('D:/PMUX_20261102_delivery/stage_r30')
E=Path('D:/PMUX_20261102_delivery/experiments/delivery_r30')
RUN=Path('D:/PMUX_20261102_delivery/relocation r30 all/results/r20261102_072425_992b5bb8')
RESEARCH=Path('D:/PMUX_20261102_delivery/research')
Z=F/'PMUX_R30_Official9_Final_20261102.zip'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def dumpzip(path,items):
 if path.exists():raise FileExistsError(path)
 with ZipFile(path,'w',ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
  for src,name in items:
   z.write(src,name,compress_type=ZIP_STORED if src.suffix.lower() in ('.zip','.png','.jpg','.pdf','.docx') else ZIP_DEFLATED)

from content import blocks
figs=sorted({b['file'].rsplit('.',1)[0] for b in blocks if b['kind']=='figure'})
assert len(figs)==14
shutil.copy2(B/'latex/main.pdf',B/'PMUX项目书_LaTeX版.pdf')
used=[]
for stem in figs:
 for ext in ('.png','.svg','.pdf'):
  p=R/'figures'/(stem+ext)
  if p.is_file():used.append((p,'figures/'+p.name))
dumpzip(B/'图表源文件.zip',used)
latex=[(p,p.relative_to(B/'latex').as_posix()) for p in sorted((B/'latex').rglob('*')) if p.is_file() and p.suffix not in ('.log','.aux')]
dumpzip(B/'LaTeX源文件.zip',latex)

source_names={'template.docx','content.json','evidence_snapshot.json','release_config.json','references.json','case_descriptions.json','current_results.csv','current_wave_notes.json'}
sources=[(p,p.name) for p in sorted(R.iterdir()) if p.is_file() and (p.suffix=='.py' or p.name in source_names)]
for folder in ('word','prepared_text'):
 sources.extend((p,p.relative_to(R).as_posix()) for p in sorted((R/folder).rglob('*')) if p.is_file())
sources.extend(used)
note=R/'SOURCE_README.txt'
note.write_text('''R30 项目书生成源存档

正文、配置、证据快照、原生公式转换入口与实际使用的14张图均保存。
正文以content.py与evidence_snapshot.json为共同输入；Word、TeX由各自生成器排版。
书面材料的源绑定保留制作时绝对路径，没有改写为不存在的相对地址。
这是生成源审查存档；图表/文稿再生成需要相应Python库、Word或TeX环境。
equation_bridge.py引用制作环境中的DOCX技能公式转换器；本源包不把该外部依赖声称为已随包提供。
可直接编辑正式DOCX，或使用另附的独立LaTeX源文件.zip编译；后者含main.tex和全部所需图片。
修改源或配置后应重新绑定、生成并检查排版，不继承当前PDF的验证结论。
原始算法源和实际已验证入口位于总包verified_core；不要把本书生成器误作综合入口。
''',encoding='utf-8')
sources.append((note,note.name));dumpzip(B/'项目书生成源.zip',sources)

readme=B/'请先阅读.txt'
readme.write_text('''PMUX R30 最终项目书与操作文档

项目书：PMUX结构优化与等价验证系统_项目书.docx / .pdf（43页）。
LaTeX版：PMUX项目书_LaTeX版.pdf（39页）；LaTeX源文件.zip包含可独立编译的main.tex及图片。
原题要求与当前结果对照：3页Word/PDF，便于快速逐条核对。
软件使用手册：4页Word/PDF，含PowerShell 7复现和ModelSim WLF查看、计数与重放步骤。
图表源文件.zip只包含本书实际使用的14张图；其中7张波形来自R30真实ModelSim VCD重绘，非GUI截图。
厂家DFFEAS九例复测是独立附加证据，未将原七图改称厂家库波形。

正式九例LUT+NOT：2427→1482；九个缩减率等权算术平均36.25224711365656%，不是加权缩减率。
逐例面积、效率及源逻辑零初态到实际候选的严格证明全部通过；每例单独也达到20%。
证明端不补候选初值；原默认基线的旧test4反例、历史工具错误和FAQ C149.1歧义均保留。
主测量r30_run01与同D盘迁移All分别报告；没有混样或以搬迁数据替换主表。
主观文档/答辩评分及最终评审认定不由客观测量自动推出。

总包根START_HERE_先读我.md、FINAL_RELEASE.json表示最终发布状态。
verified_core内5157个已完成All的索引文件及原索引保持字节不变。
原核心准备README/pending书籍字段是当时快照，已由FINAL_DELIVERY补齐，不表示本交付缺少文书。
''',encoding='utf-8')

# Independently reviewed text remains byte-identical; all final visual checks must exist.
qa_names=['FINAL_STRUCTURAL_QA.json','BRIEF_STRUCTURAL_QA.json','MANUAL_STRUCTURAL_QA.json','FINAL_WORD_BRIEF_MANUAL_VISUAL_QA.json','RELEASE_LANGUAGE_QA.json','CURRENT_WAVEFORM_QA.json','DIAGRAM_GEOMETRY_QA.json','R30_WAVE_VISUAL_QA.json','VENDOR_REFERENCE_AUDIT.json']
qa=[(R/n,'FINAL_DELIVERY/qa/'+n) for n in qa_names]
for n in ['BOOK_TEXT_REVIEW.json','BOOK_LATEX_VISUAL_QA.json','BOOK_LATEX_VISUAL_QA_FINAL.json']:
 qa.append((E/n,'FINAL_DELIVERY/qa/'+n))
for p in qa:
 assert p[0].is_file(),p[0]
assert json.loads((E/'BOOK_LATEX_VISUAL_QA_FINAL.json').read_text(encoding='utf-8'))['status']=='PASS'

core_index=json.loads((C/'PACKAGE_FILES.json').read_text(encoding='utf-8'))
core=core_index['files'];assert len(core)==5157
actual={p.relative_to(C).as_posix() for p in C.rglob('*') if p.is_file()}
assert actual=={x['path'] for x in core}|{'PACKAGE_FILES.json'}
for x in core:assert sha(C/x['path'])==x['sha256'],x['path']
print('Frozen core: 5157 indexed files verified unchanged',flush=True)

add=[]
def addfile(p,target):
 assert p.is_file(),p
 add.append((p,target))
for p in sorted(B.rglob('*')):
 if p.is_file() and p.suffix not in ('.log','.aux'):addfile(p,'FINAL_DELIVERY/project_book/'+p.relative_to(B).as_posix())
add.extend(qa)
for p in sorted(E.iterdir()):
 if p.is_file() and not p.name.startswith('BOOK_'):addfile(p,'FINAL_DELIVERY/reproduction_support/'+p.name)
for p in sorted(RUN.rglob('*')):
 if p.is_file():addfile(p,'FINAL_DELIVERY/current_reproduction/'+p.relative_to(RUN).as_posix())
for p in sorted((F/'qa/modelsim_view_help').iterdir()):
 if p.is_file() and p.name in ('result.json','view.log'):addfile(p,'FINAL_DELIVERY/qa/modelsim_view_help/'+p.name)
addfile(RESEARCH/'r30_vendor_ff_evidence.zip','FINAL_DELIVERY/supplemental/r30_vendor_ff_evidence.zip')
for rel in ['run_001/report.json','INDEPENDENT_AUDIT.json','PACKAGE_AUDIT.json','FILE_MANIFEST.json']:
 addfile(RESEARCH/'r30_vendor_ff'/rel,'FINAL_DELIVERY/supplemental/vendor_ff/'+rel)
for n in ['main.pdf','main.tex','generate_latex.py','FINAL_STRUCTURAL_QA.json']:
 addfile(R/'qa_before_pagination'/n,'FINAL_DELIVERY/qa/layout_history/'+n)
assert len({name for _,name in add})==len(add)

manifest={'schema':1,'scope':'Only final additions; core remains separately indexed in verified_core/PACKAGE_FILES.json','files':[{'path':name,'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in add]}
write(F/'FINAL_ADDITIONS.json',manifest)
release={'schema':1,'status':'FINAL_RELEASE','candidate':'r30_native_sload','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'optimization_stopped_at_remaining_percent':24,'core':{'prefix':'verified_core/','indexed_files':5157,'index':'verified_core/PACKAGE_FILES.json','index_sha256':sha(C/'PACKAGE_FILES.json'),'unchanged_from_reproduced_all':True,'historical_pending_fields':'Preserved snapshot metadata; final documents are complete under FINAL_DELIVERY.'},'documents':{'word_pages':43,'latex_pages':39,'requirements_comparison_pages':3,'manual_pages':4,'location':'FINAL_DELIVERY/project_book/'},'objective_results':{'mean_area_reduction_percent':36.25224711365656,'total_area':[2427,1482],'all_individual_at_least_20_percent':True,'official9_strict_source_zero_no_candidate_zinit':'PASS','main_measurement':'r30_run01','current_relocation_all':'r20261102_072425_992b5bb8','batches_not_combined':True},'reproduction_audit_sha256':sha(E/'RELOCATION_R30_ALL_AUDIT.json'),'vendor_ff_supplement':{'effective_samples':40684,'initial_ff_instances_both_sides':643,'seven_figures_source':'Earlier frozen restricted-model actual ModelSim VCD; not relabelled vendor figures','zip_sha256':sha(RESEARCH/'r30_vendor_ff_evidence.zip')},'additions_index':'FINAL_ADDITIONS.json','additions_index_sha256':sha(F/'FINAL_ADDITIONS.json'),'limits':['Source logical-zero contract with explicit initial values retained; not arbitrary-initial-state universal equivalence.','Original default-baseline test4 strict-zero counterexample and historical errors preserved.','Finite ModelSim/vendor-FF checks do not establish SDF timing or full vendor gate-level simulation.','Official undisclosed dirty patch and C149.1 interpretation remain explicit limitations.','Subjective document/defense scoring remains with judges.']}
write(F/'FINAL_RELEASE.json',release)
start=F/'START_HERE_先读我.md'
start.write_text('''# PMUX R30 最终交付

本包的当前状态以根目录 `FINAL_RELEASE.json` 为准：正式文书与复现证据已补齐。

1. 先看 `FINAL_DELIVERY/project_book/原题要求与当前结果对照.pdf`（3页）。
2. 阅读 `软件使用手册.pdf`（4页），按 PowerShell 7 和真实工具路径运行。
3. 完整项目书提供 Word、Word 导出的 PDF、LaTeX PDF 与独立 LaTeX 源包；实际图源单独归档。

解压到短路径，例如 `D:\\PMUX_R30`。在现有 PowerShell 7 终端执行：

```powershell
Set-Location D:\\PMUX_R30\\verified_core
.\\Run-OfficialTests.ps1 -Mode Check
```

完整 All 需要已安装的 OSS CAD Suite、Python 和 POSIX 工具，参数示例见手册。
不调用 Windows PowerShell 5.1，不修改执行策略；没有新增或替换已经实跑的核心入口。
ModelSim 用于查看/重放映射网表波形，C++ pass 源码不是 Verilog Design Sources。

`verified_core/` 整体保留已完成迁移 All 的5157个索引文件和原索引字节。
其中原 `READ_ME.txt` 的“准备包”和 release 的书籍 pending 是历史快照状态；正式书籍现位于 `FINAL_DELIVERY/`。
不要只读旧准备状态就判断本包未完成。核心与新增材料分别校验，原始报告路径不被改写。

九例算术平均缩减36.252247%，各例面积均不增加且分别达到20%；完整严格证明与逐例效率门槛通过。
主测量与同D盘迁移All分别保留，不混样、不取较优批次。初态、模型和官方评分的边界见项目书。
七张波形是冻结R30实际ModelSim VCD重绘（非GUI截图）；厂家DFFEAS九例复核是独立补充，未更改七图来源。

`FINAL_ADDITIONS.json` 记录新增材料的包内位置、原来源及SHA256；
`verified_core/PACKAGE_FILES.json` 是不变的核心清单。总ZIP自己的SHA256见旁置审计报告。
''',encoding='utf-8')
roots=[(start,start.name),(F/'FINAL_RELEASE.json','FINAL_RELEASE.json'),(F/'FINAL_ADDITIONS.json','FINAL_ADDITIONS.json')]
items=roots+[(C/x['path'],'verified_core/'+x['path']) for x in core]+[(C/'PACKAGE_FILES.json','verified_core/PACKAGE_FILES.json')]+add
dumpzip(Z,items)
print('Final ZIP written; auditing every entry',flush=True)
with ZipFile(Z) as z:
 names=z.namelist();assert len(names)==len(set(names))==len(items)
 bad=z.testzip();assert bad is None,bad
 for p,name in items:
  h=hashlib.sha256()
  with z.open(name) as f:
   for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
  assert h.hexdigest()==sha(p),name
 # Compare core independently against the original, not merely the on-disk copy.
 for x in core:assert hashlib.sha256(z.read('verified_core/'+x['path'])).hexdigest()==x['sha256'],x['path']
audit={'status':'PASS','zip':str(Z),'bytes':Z.stat().st_size,'sha256':sha(Z),'zip_entries':len(items),'core_indexed_files':len(core),'all_original_core_sha256_unchanged':True,'core_index_sha256_unchanged':sha(C/'PACKAGE_FILES.json'),'new_entries_indexed':len(add),'zip_crc_test':'PASS','all_entries_sha256_checked':True,'reproduced_algorithm_not_rerun_for_packaging':True,'documentation_complete':True,'final_release_sha256':sha(F/'FINAL_RELEASE.json'),'additions_index_sha256':sha(F/'FINAL_ADDITIONS.json')}
write(F/'FINAL_PACKAGE_AUDIT.json',audit)
(F/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in [Z,F/'FINAL_RELEASE.json',F/'FINAL_ADDITIONS.json',F/'FINAL_PACKAGE_AUDIT.json'])+'\n',encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False))
