"""Compatibility entry point; protected by the frozen-evidence rendering gate."""
import render_zero_waveforms
