"""Lightweight, repeatable source and equation QA; never compiles documents."""
from pathlib import Path
import hashlib,json,py_compile,sys
from lxml import etree
import content,brief_content
from book_settings import CONFIG_PATH
sys.path.insert(0,'C:/Users/xinxi/.codex/skills/math-modeling-skill-main/tools/docx/scripts')
from equations import latex2omml
from equation_bridge import normalize_for_docx

root=content.R;d=content.D
assert d['configuration_sha256']==hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest()
assert d['metrics']['strict_source_zero_proven_count']==9 and not d['candidate_side_normalization_has_zinit']
assert d['metrics']['all_nonincrease'] and d['metrics']['all_time_memory_within_5_percent']
for block in content.blocks:
    if block['kind']=='equation':
        etree.fromstring(latex2omml(normalize_for_docx(block['tex'])))
files=list(root.glob('*.py'))
for path in files:py_compile.compile(str(path),doraise=True)
wave=json.loads((root/'CURRENT_WAVEFORM_QA.json').read_text(encoding='utf-8'))
assert wave['candidate']==content.V
for asset in wave['assets']:assert hashlib.sha256(Path(asset['target']).read_bytes()).hexdigest()==asset['sha256']
qa={'status':'PASS_PREPARATION_ONLY','candidate':content.V,'main_content_blocks':len(content.blocks),'brief_content_blocks':len(brief_content.blocks),
    'tables':sum(b['kind']=='table' for b in content.blocks),'figure_references':sum(b['kind']=='figure' for b in content.blocks),
    'formula_conversion_count':sum(b['kind']=='equation' for b in content.blocks),'syntax_checked_files':len(files),
    'formal_v3_nine_case_report_available':True,'current_wave_ready':d['current_wave_ready'],'simulation_total_compared':d['modelsim']['total_checked'],
    'csv_to_vcd_selected_samples':sum(x['csv_samples_verified'] for x in wave['cases']),
    'observable_mechanism_figure_bound':bool(d.get('observable_waveform')),'observable_development':d.get('observable_development'),
    'sampling_boundary_sixth_figure_bound':bool(d.get('sampling_waveform')),'sampling_boundary_development':d.get('sampling_boundary_development'),
    'modelsim_restricted_ff_map_inverse':d.get('simulation_model_scope'),'current_wave_export_count':len(wave['assets']),
    'hardware_sclr_development':d.get('hardware_sclr_development'),
    'prototype_controls_not_one_native_ablation_batch':not d.get('observable_isolation',{}).get('same_native_ablation_batch',False),
    'same_control_ablation_bound':bool(d.get('same_control_ablation')),
    'scale_nodes':[d['supplemental_scale']['baseline_actual_nodes'],d['supplemental_scale']['optimized_actual_nodes']],'scale_full_eqy':'PASS','scale_in_official_mean':False,
    'migration_full_all':'CURRENT_CANDIDATE_ALL_PASS' if d.get('current_migration_all_qa') else 'HISTORICAL_ONLY_NOT_CURRENT_CANDIDATE','migration_archived_files':443,
    'historical_r20_fixed2_preserved':True,
    'current_migration_audit_sha256':d['sources']['current_migration_all_qa']['sha256'] if d.get('current_migration_all_qa') else None,
    'current_migration_main_performance_replaced':False,
    'temporary_migration_source_files_unavailable_now':len(d['migration_all_qa']['preparation_archive_recheck']['temporary_execution_files_unavailable_now']),
    'migration_previous_four_path_errors_preserved':True,'native_build_and_run_requirement_separately_bound':True,'c149_1_ambiguity_disclosed':True,
    'modelsim_evidence_revision':d.get('modelsim_evidence_revision'),'current_migration_full_all_executed':bool(d.get('current_migration_all_qa')),
    'document_compilation':False,'final_output_created':False,'render_pending':'Internal layout preview only; final release awaits candidate selection.'}
(root/'PREPARATION_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:qa[k] for k in ['candidate','main_content_blocks','brief_content_blocks','formula_conversion_count','scale_nodes']}))
