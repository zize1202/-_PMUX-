"""Rewritten logical-zero manuscript, with metrics bound to one selected candidate."""
from pathlib import Path
import json
from book_settings import ROOT, CONFIG
from requirements import requirement_rows
R=ROOT
D=json.loads((R/'evidence_snapshot.json').read_text(encoding='utf-8'))
cases=D['cases'];M=D['metrics'];V=D['candidate'];FEATURES=set(D['features']);SIM=D['modelsim']
SCOPE=D['measurement_scope'];V3=SCOPE['schema']==3
SCALE=D.get('supplemental_scale')
PROOF_SECTION='2.3.10' if 'hardware_sload' in FEATURES else '2.3.9' if 'hardware_sclr' in FEATURES else ('2.3.8' if 'sampling_boundary' in FEATURES else ('2.3.7' if 'observable_decode_joint' in FEATURES else '2.3.6'))
if D['release_ready']:
 assert SIM and D['current_wave_ready'], 'A released manuscript requires the bound current waveform evidence.'
 assert not D['candidate_side_normalization_has_zinit'], 'A released manuscript must not describe an unresolved candidate-side initialization repair.'
 assert D.get('native_build'), 'A released manuscript requires native build and execution evidence.'
short=lambda s:s.split('_',2)[-1] if s.startswith('pmux_case') else s
blocks=[];limits={}
def add(k,t,**kw):blocks.append(dict(kind=k,text=t,**kw))
def p(t):add('p',t)
def h(t,s):add('h',t,source=s)
def sub(t):add('sub',t)
def table(t,headers,rows,widths):add('table',t,headers=headers,rows=[[str(v) for v in row] for row in rows],widths=widths)
def fig(f,t,w=14.4):add('figure',t,file=f,width=w)
def eq(t,tex):add('equation',t,tex=tex,mode='plain')
mean=f"{M['mean_area_percent']:.4f}%";weighted=f"{M['weighted_percent']:.4f}%"
rechecked='、'.join(short(x) for x in M['rechecked_ids'])
eff='逐例均不超过1.05' if M['all_time_memory_within_5_percent'] else '仍有用例超过1.05，不能称效率约束全部通过'
add('title','PMUX结构优化与逻辑零初态验证系统')
if not D['release_ready']:p('工作稿：候选与指标用于生成器核对，最终版本尚未冻结；本稿不得作为最终交付。'+('当前候选真实波形已绑定，后续更换候选须同步更新。' if SIM else '当前候选波形尚待绑定。'))
h('摘要',2)
abstract=(f'针对PMUX与算术、状态控制交织时共享结构难以保留的问题，本作品在Yosys中实现内置C++优化pass，并在原synth_intel流程中完成初始化声明与词级重构。初始化阶段紧接proc，在顺序优化及状态重编码前把未指定时钟触发器初值声明为逻辑0，保留显式0/1；受支持可写RAM仅补充未定义存储位，纯ROM内容不改。重构阶段结合精确控制恢复、多层数据通路、bank、全字算术、闭合选择DAG及有界小ROM共享，随后沿用统一Cyclone IV与ABC9后端。{V}保持原4例及新增5例的源文件、默认参数和外部脚本不变；LUT+NOT逐例不增，缩减率算术平均{mean}，总量{M["baseline_sum"]}→{M["optimized_sum"]}。在{SCOPE["short"]}范围内，综合时间比与主进程峰值工作集比{eff}。完整EQY从原RTL的明确逻辑零初态出发，证明到候选实际默认综合端点，九例通过；候选、端点、证明与效率记录由哈希绑定。旧默认基线在test4的严格初态反例保留，功能参考与面积基线分别定义。结论限于披露的初始化契约、器件模型与正式九例，不宣称任意初态等价或自动获得全部评分项。')
if 'observable_decode_joint' in FEATURES:
 abstract=abstract.replace('闭合选择DAG及有界小ROM共享，','闭合选择DAG及有界小ROM共享；进一步联合使能约束下的状态投影与公共译码因子，')
if 'sampling_boundary' in FEATURES:
 abstract=abstract.replace('随后沿用统一Cyclone IV与ABC9后端。','并重述PMUX采样边界的同步复位与使能优先级，保留原状态转移，随后沿用统一Cyclone IV与ABC9后端。')
if 'hardware_sclr' in FEATURES:
 abstract=abstract.replace('随后沿用统一Cyclone IV与ABC9后端。','在显式Cyclone IV目标下映射硬件同步清零并编码已知初值；后续标准流程与ABC9保持不变。')
if 'hardware_sload' in FEATURES:
 abstract=abstract.replace('后续标准流程与ABC9保持不变。','并将已证互斥的叶分支迁移到SLOAD/ASDATA；后续标准流程与ABC9保持不变。')
p(abstract);limits['摘要']=(abstract,800)
p('关键词：PMUX；逻辑综合；初始状态；资源共享；形式验证')
h('第一部分  作品概述',5)
h('功能与特性',6)
p('本作品面向原题选题二“多路选择器PMUX结构优化”[1]。正式入口仍为读取原始Verilog并执行synth_intel -family cycloneiv；基线和候选使用相同外部脚本，不添加按用例变化的Tcl调优步骤。优化逻辑编入Yosys主程序，在粗粒度选择和算术关系尚可识别时整理结构，最终按映射后的实际LUT与取反单元计量收益。')
p('本轮把初始化作为完整综合路径的一部分处理。仅在证明脚本末尾把寄存器写成0，无法恢复此前顺序优化已经删除或反相编码的源状态。新程序先声明源级初态，再进行原生优化、重编码和映射，使产物本身保留该契约；验证直接读取这个实际产物，不能以验证侧修补后的另一个设计冒充交付端点。')
h('应用领域',9)
p('PMUX常见于状态机输出、数据通路、交叉开关及分支算术。多个分支共用控制或运算时，可将重复表达整理为共享节点；收益还受位宽、扇出、消费者和后端映射影响。减少源码行数、中间MUX数或通用门数，均不能直接代替本题Cyclone IV LUT+NOT结果。')
p('正式证据只覆盖九个发布用例的默认参数。源逻辑初值为0也不意味着所有输出电平都为0：组合译码、常量和显式初始化仍可产生1。显式初值不能因“按0初始化”的简写而被覆盖；时钟、复位、使能仍是功能输入。选题二FAQ不要求eLinx或板卡[2]，本项目不以硬件展示代替综合软件证据。')
h('主要技术特点',12)
p('程序有两个职责不同的入口：-init-zero声明初态契约，普通opt_pmux负责面积优化。前者在proc之后、首个可能改变状态表示的顺序优化之前运行；后者位于coarse阶段的wreduce、peepopt、opt_clean之后、cmp2lut之前。外部脚本保持原样，调用由synth_intel内部固定组织。')
p('所有规则以单元类型、连线、位宽、完整真值关系和消费者约束识别机会，不依赖用例名、顶层名或预存结果。枚举规模和存储扫描设定预算；不支持的初始化结构明确报错，不能静默假定已覆盖。面积重构未满足结构条件时保留原结构，性能仍按整个综合进程计算。')
h('主要性能指标',15)
table('表1  当前绑定候选的主要结果',['指标','记录与适用范围'],[
['候选',V],['面积算术平均',mean+'；九例等权缩减率均值'],['逐例面积',f"九例LUT+NOT不增；{M['individual_at_least_20_count']}例单独达到20%"],['面积总量',f"{M['baseline_sum']}→{M['optimized_sum']}；加权缩减{weighted}仅作补充"],['综合效率',SCOPE['short']+'：时间比与主进程峰值工作集比'+eff],['完整功能证据','原RTL逻辑零初态→候选实际端点：9/9 PASS'],['边界','旧默认baseline与新候选不能同时被强制物理全0后声称等价']],[3.4,11.25])
h('主要创新点',18)
innovation='（1）把源级初态声明放到顺序变换之前，使实际综合产物承载逻辑零初态契约，并区分功能参考、面积基线与映射状态编码。（2）组合精确控制恢复、词级共享和有界小ROM余因子复用，让统一后端利用完整结构，同时将逐例面积、时间与内存限制纳入版本选择。（3）以候选二进制、实际端点、原始证明和测量哈希绑定结论，保留失败版本、反例及复测记录。上述贡献是面向本题的工程实现与证据组织，不将布尔分解、公共子表达式或形式证明原理宣称为首次提出。'
if 'observable_decode_joint' in FEATURES:
 innovation=innovation.replace('（2）组合精确控制恢复、词级共享和有界小ROM余因子复用，','（2）证明使能蕴含有效选择，再联合可观察状态投影与公共译码因子；配合精确控制恢复、词级共享和有界小ROM复用，')
if 'sampling_boundary' in FEATURES:
 innovation=innovation.replace('（3）以候选二进制','并在PMUX私有采样边界保持复位优先语义，将保持控制交给实际寄存器使能端。（3）以候选二进制')
if 'hardware_sclr' in FEATURES:
 innovation=innovation.replace('（3）','进一步在限定目标及二值模型下使用硬件同步清零，逐位保持已知初态。（3）')
if 'hardware_sload' in FEATURES:
 innovation=innovation.replace('逐位保持已知初态。','逐位保持已知初态，并在已证互斥的采样边界共享同步装载。')
p(innovation);limits['主要创新点']=(innovation,400)
h('设计背景',21)
p('标准来自原题印刷第4—6页及FAQ答复列C[1,2]。原题技术要求面积缩减10%以上，面积评分满档门槛为20%以上，二者用途不同。后续答疑规定九例等权算术平均、每例面积不增、同次采集墙钟和主进程峰值工作集。问题列中的假设、用户自定义验收材料及项目内部测试计划都不构成官方标准。')
p('本项目对初态采用保守且自洽的技术约束：未指定时钟状态在源逻辑层解释为0，显式初值保持，实际候选必须在这一约束下证明输出一致。该选择是本项目执行和验证的契约，不能改写为主办方已确认的唯一解释。C145所列dirty补丁尚未公开，公开提交构建也不能冒称与官方未知补丁逐字节相同；文档与答辩分数仍由评审认定。')
p('C149第一问同时涉及组合方案中自定义规则的独立消融和最低收益要求，答复“一、不允许”不能唯一指向其中哪项；本项目不据此宣称组合方案或消融已获确认，实际保持标准pass与统一ABC流程不变，按其他指向明确的规则实施和核验。')
core,other=requirement_rows(D)
table('表2a  原题技术要求、FAQ与当前结果',['原题条目','后续FAQ','实现与证据','边界'],core,[3.15,3.4,4.9,3.2])
table('表2b  用例、平台及评审事项',['原题条目','后续FAQ','当前交付','边界'],other,[3.15,3.4,4.9,3.2])
h('第二部分  系统组成及功能说明',24)
h('整体介绍',27)
sub('2.1.1  两个内置阶段与统一后端')
p('图1给出完整默认路径。前端proc将行为过程转换为可识别时钟单元，随即执行opt_pmux -init-zero；随后原生综合可在已经明确的初态约束下优化状态。到coarse阶段再执行普通opt_pmux，识别共享控制、运算和数据选择。两个阶段在同一个优化版二进制内执行，ABC9及后续器件映射仍沿用统一后端。')
fig('architecture.png','图1  源初态声明、PMUX重构及独立证据采集')
p('最终Cyclone IV网表用于面积计数，ABC9后的ILANG用于可建模的形式端点。捕获端点必须与完整生产综合相对应，不能为了证明而改参数、换脚本或重新选择另一个候选。软件效率在完整综合运行中采集；形式证明与补充仿真独立执行，不混入综合耗时。')
sub('2.1.2  目标与版本选择')
p('设第i例原默认基线的LUT+NOT数为Bi，候选为Oi，九例基线均为正。每例不得增长且九例缩减率算术平均达到20%，是同时检查的约束；总量加权结果只作补充。版本选择还须满足逐例效率与完整证明，不能仅凭更高面积均值替换已验证版本。')
eq('Ri=(Bi−Oi)/Bi×100%，i=1,…,9',r'R_i=\frac{B_i-O_i}{B_i}\times100\%,\quad i=1,\ldots,9')
eq('Oi≤Bi，Rmean=(R1+…+R9)/9≥20%',r'O_i\leq B_i,\qquad R_{\mathrm{mean}}=\frac{1}{9}\sum_{i=1}^{9}R_i\geq20\%')
p('结构准入与局部精确枚举不能构成最终LUT收益的全局最优性证明。保留零收益或小收益用例是约束下的实测选择，不表示该设计已达理论极限。性能门槛按每个用例分别判断，其他用例的加速不能抵消某例超过1.05的时间或内存比。')
sub('2.1.3  方法依据与职责边界')
p('Yosys提供词级优化和技术映射基础[3,4]，ABC为后端综合与验证提供实现[7]；决策图工作说明变量顺序和共享子图影响函数表示大小[8]。本项目用这些基础组织有界结构重写，再用实际映射与证明评价结果。文献中的节点数量或理论性质不能直接换算为本题得分。')
table('表3  各阶段的职责及不能推出的结论',['阶段','职责','限制'],[
['源初态声明','为未指定时钟状态明确逻辑0，显式0/1不变','不是任意未知初态下的无条件等价变换'],['词级重构','恢复控制关系并共享运算、选择与ROM余因子','局部结构改进不保证全部设计获益'],['器件映射','统一Cyclone IV/ABC9后端形成面积端点','综合软件耗时不是器件关键路径'],['完整EQY','证明源逻辑初态契约下候选全部输出','不扩展为任意内部初态全集等价'],['ModelSim','观察初始化、复位、数据变化与结束计数','有限采样不替代形式证明或物理时序验证']],[3.0,5.6,6.05])
h('硬件系统介绍',30)
p('作品为综合软件，不包含自制硬件。Cyclone IV是统一映射目标；软件进程工作集并非FPGA片上RAM，综合墙钟并非电路时延。本书不报告未经布局布线的最高频率、功耗或实物资源收益。正式九例之外的规模测试必须单独保留输入与运行证据，不能混入九例均值。')
p('工程在Windows原生环境运行。复现入口设置ABC与PATH，指向两臂共用的ABC二进制及所需运行库；本ABCEXTERNAL构建读取ABC环境变量。性能工具逐次解析实际ABC命令并校验文件哈希，确认比较中两臂确实使用同一后端。应通过提供的入口启动，不能把未配置依赖的裸EXE调用视为同一运行条件。')
h('软件系统介绍',35)
sub('2.3.1  初始化契约及其插入位置')
p('未指定初态、逻辑零初态和映射寄存器物理全零是三个不同概念。设逻辑状态q在映射中用反相信号r表示，q=¬r，则q(0)=0要求r(0)=1。将两端物理寄存器都强制为0，会把这种合法编码误当成状态不一致；若先让优化器消去未初始化的常量历史寄存器，再补初值，也可能已经丢失初始行为。')
eq('q=¬r，q(0)=0⇒r(0)=1',r'q=\neg r,\qquad q(0)=0\ \Longrightarrow\ r(0)=1')
p('实现因此在原synth_intel的proc之后立即声明时钟FF的未指定初值。显式0与1逐位保持；未定义位写入init=0，声明本身不反相显式1。时钟极性、复位值、复位优先级和使能行为不由本阶段改写。后续原生优化在这些属性已明确后进行，从而把初始化语义带到实际器件端点。')
p('初始化处理与一般逻辑化简严格区分：它选择一个源级初态契约，不声称对原本任意内部初态的设计保持全集行为。该约束不作用于自由输入，也不能把组合X、ROM无关项或不支持的锁存器都一律填成0。默认外部脚本不增加任何初始化命令，入口集成由候选二进制承担。')
sub('2.3.2  可写RAM、ROM与微例验证')
p('r11扩展在受支持的可写同步RAM上补充未知存储位，保留已有初始化数据、位掩码和地址偏移。有效写端口必须共享同一个信号时钟及极性；异步写、宽写、不同写时钟、已合并同步读端口等不支持结构明确报错。预算为每RAM最多16M位、设计累计存储及已有初始化扫描最多64M位、最多65536个新增初始化段。')
p('没有有效运行时写端口的ROM保持不变，其X可能描述组合无关项，不是待补的存储初态。锁存器尚不在已验证范围内，不能列为通过。微例测试覆盖显式1、混合初值、使能、异步复位、常量历史及不同RAM初始化情况；r11共10例具备已检查的PASS证据，另有3例幂等检查。部分输出单独归纳未证出的UNKNOWN原记录保留，后续联合状态关系作为同一分区的待证输出，不能把它们直接当假设。')
p('微例的候选侧只执行规定的存储展开与清理，不再追加zinit或setundef补零；这说明该初始化模块本身完成了声明。微例仅验证这一阶段，不自动证明后续完整默认综合流水。正式九例的完整证明、候选端点初始化审计和版本哈希另行记录，两类证据不能互相冒名。')
sub('2.3.3  精确控制恢复与词级共享')
p('选择器控制经常由少量输入译码而来。实现回溯至多6个控制位，对最多64种二态赋值逐项求值，要求每项为唯一有效分支或默认分支；多分支同时有效、函数不可识别或预算超限时保留原结构。输出位使用共享决策节点，常量直接连接，显式X/Z叶不被此规则任意补0或1。')
fig('control_recovery.png','图2  小支持集控制恢复与保持优先级的掩码')
p('优先MUX链按既有先后顺序生成剩余有效掩码。第j个分支只能在自己的选择有效且此前均未命中时生效；默认分支对应全部未命中。这样可以共享控制而不把优先选择错误解释为独立one-hot输入。枚举证明限定在支持的控制逻辑内，不代表整个后端面积全局最小。')
eq('mj=sj∧∧k<j¬sk，mdefault=∧k¬sk',r'm_j=s_j\land\bigwedge_{k<j}\neg s_k,\qquad m_{\mathrm{default}}=\bigwedge_k\neg s_k')
p('conev2跨多层选择整理控制和算术，banksv2共享双输出bank的行选择并保留例外分支，全字资源共享处理XOR、ADD、SUB。操作宽度、符号扩展和消费者必须保持；SUB左右操作数不能任意调换。公共运算提到选择之后会引入新的选择逻辑，因此仍需最终映射判断净收益。')
fig('word_factor.png','图3  保持位宽与截断语义的公共加法提取')
eq('mux(s,X+V0,X+V1)=X+mux(s,V0,V1)',r'\operatorname{mux}(s,X+V_0,X+V_1)=X+\operatorname{mux}(s,V_0,V_1)')
p('闭合选择DAG整理重用重复子图，闭合条件要求掌握所涉及节点的外部消费者，避免新结构生成后旧运算仍不得不保留。keep等保护属性、默认分支及外部使用关系都属于准入条件。词级共享和逐位布尔化简相互补充，不能把最终组合收益平均分配给每个模块而称为消融结果。')
sub('2.3.4  有界小ROM共享与候选顺序')
if 'small_rom' in FEATURES:
 p('小ROM规则接受完整的5地址位、32字常量表，对2—16位输出建立精确余因子表示，一次最多处理8个符合条件的ROM。不同输出若拥有相同或互补的子函数，可复用节点；仅依赖剩余地址位的函数按支持集约简。它改变组合实现而不补写ROM数据，不改时钟或状态，也不调用外部映射器挑选结果。')
 p('规则以地址宽度、完整常量内容、输出宽度与保护属性限定应用范围，不能以test4名字识别机会。小ROM共享与初始化声明分别解决组合重复和状态契约问题，两者不能混为“把X填0以换面积”。保留真实映射结果，即使局部逻辑更紧凑也不预先宣称达到理论最优。')
if 'exact_rom_residual' in FEATURES:
 p('精确ROM残差机制进一步利用各输出与简单函数之间的结构关系。对每个输出，从0、1、单个地址位及其反相中选取与完整真值表Hamming距离最小的基函数b；距离仅用于选择表达方式，不是允许的输出误差。随后对32个地址计算完整输出向量与基函数向量的逐位异或δ，把δ相同的地址划入集合Gδ。')
 eq('yj=bj XOR ORδj=1[x∈Gδ]',r'y_j=b_j\oplus\bigvee_{\delta_j=1}[x\in G_\delta]')
 p('每个输出由基函数与相应地址集合的指示函数异或恢复，全部32个地址都必须逐项验证。残差描述的是精确修正项，绝不以较小Hamming距离替代功能正确。候选与原结构采用相同AIG结构估价：预计至少减少4个节点且减少比例至少1/8才准入；它只是有界候选筛选，不能保证ABC最终LUT也按同样比例下降。原ROM保护条件、完整常量要求和32地址校验保持，未满足条件时使用原余因子实现回退。')
if 'postdag_private_arithmetic' in FEATURES:
 p('闭合DAG重构可能暴露原来分散的算术分支。后DAG阶段重新收集有界控制支持集，在最多256种赋值上证明互斥，才共享私有算术结果。前一阶段曾经观察到的互斥不能不经检查地沿用到重写后的图；对外仍有消费者的运算不能按私有结果删除。该规则是否属于当前候选由源码特征清单与版本绑定确认。')
if 'branch_constant_propagation' in FEATURES:
 p('已确认的选择分支还为局部表达提供常量条件。当前候选将这些条件用于受限的分支常量传播，减少残留重复选择；传播后仍需维持完整控制真值与默认分支关系。该过程属于候选内部结构重构，不允许把当前仿真输入或某例已观察到的状态当作全局常量。')
if 'width3_mixed_carry' in FEATURES:
 sub('三位混合运算的共享进位／借位链')
 p('该规则只接受WIDTH=3、S_WIDTH=3的PMUX，三个完整分支恰为XOR、ADD和SUB各一个；通过真实译码证明选择互斥且三臂可达。'+('每个算子的A_SIGNED与B_SIGNED必须同为合法0或1；不同算子可分别采用有符号或无符号解释，A/B/Y均严格为3位。' if 'signed_carry3' in FEATURES else '当前范围仅接受无符号算子。')+'以减法右操作数q为共同数，加法和异或可交换输入以对齐q。先根据选择信号选出另一操作数u，令s表示减法选择、a表示加法或减法选择，初始进位／借位c₀=0。三种结果共用下面的逐位关系：')
 eq('yi=ui XOR qi XOR ci',r'y_i=u_i\oplus q_i\oplus c_i')
 eq('gi=(ui XOR s) AND qi；pi=ui XOR s XOR qi',r'g_i=(u_i\oplus s)\land q_i,\qquad p_i=u_i\oplus s\oplus q_i')
 eq('ci+1=a AND (gi OR (pi AND ci))',r'c_{i+1}=a\land(g_i\lor(p_i\land c_i))')
 p('加法模式得到进位，减法模式得到借位，异或模式由a=0关闭传递。只生成第1、2位所需的传递项，末位输出之外的carry-out按原三位模8语义丢弃。实现保持原PMUX的A、S、Y和全部状态不变，将三个B分支接到同一共享结果；没有采用后来被拒绝的末级选择器折叠。')
 p('适用条件要求运算结果完整且私有，在根PMUX的A/B/S各端口中每位只使用一次；保护对象、冲突驱动、外部消费者、截片或扩宽均拒绝。签名参数不合法或同一算子的A/B签名不匹配时不应用该规则。最多检查64个候选根、改写16个，不外推到4位或任意位宽。结构重写的正确性仍由当前完整EQY和最终映射资源核验，不能用局部原型的更低门数替代原生程序结果。')
 if D.get('signed_coverage'):
  current_capture=(f"当前候选对同一源实测{D['signed_coverage']['current_logic']} LUT；" if D['signed_coverage']['current_logic'] is not None else '')
  p('r21把上述同宽模8关系扩展到合法匹配的signed参数。独立真实有符号源例在默认完整综合中由r20的18 LUT降为16 LUT，17位外部输入全部自由的原源到实测映射端点SAT证明通过，未使用符号范围或one-hot假设。'+current_capture+'这属于覆盖能力补充，未加入官方九例或均值，也不把r21的独立SAT记录改称当前候选新执行。')
if 'priority_group4' in FEATURES:
 sub('四分支零默认优先链的精确分组')
 p('当前规则还识别恰好四层、字宽2—256位的MUX优先链，最终默认输入必须全部为已知0。按从高到低的原优先级，将前两分支组合为H、后两分支组合为L：H由s₀选择d₀或按s₁屏蔽的d₁，L由s₂选择d₂或按s₃屏蔽的d₃。只有前两选择均不成立时才开放低组，输出关系为：')
 eq('Y=H OR ((NOT s0 AND NOT s1) AND L)',r'Y=H\lor((\neg s_0\land\neg s_1)\land L)')
 p('该分组完整保留多选同时成立时的先后关系，不要求one-hot假设，也不把优先链改成无优先级的并联选择。所有内部链输出只允许一个消费者，连接必须连续且由对应MUX唯一驱动；保护对象、受保护别名、bank局部标记、输入驱动冲突、回馈至自身链输出及未知常量均拒绝。普通别名和重复选择信号仍合法。四臂零默认候选未通过保护检查时跳过该根；非四臂或非零默认继续原路径。')
 p('规则复用已有连线与消费者索引，不为每条四分支链重复建立完整结构上下文。当前test2面积收益由默认原生综合、完整源逻辑零证明及v3实测共同确认，未修改原源文件的敏感列表或在运行时固定输入。')
if 'priority_net_skip' in FEATURES:
 p('r22引入的扫描跳过规则在当前候选中保留：全部前置helper之后统计模块内所有MUX，包含未被选择的内部单元；少于三个时不构造供priorities使用的只读Net，也不调用该步骤。原优先链规则至少需要三个不同MUX才能重写，因此这一条件下没有可触发根。后续PMUX控制恢复所用的第二个Net保留；这一步不改初始化、结构发射、标准pass或ABC。r22当时的官方九例面积与r20/r21相同；不同批次的墙钟差不能据此解释为该跳过条件带来的因果性能收益。')
if 'observable_decode_joint' in FEATURES:
 from method_observable_decode import add_section
 add_section(p,sub,eq,table,cases,D.get('observable_development'),D.get('observable_isolation'),D.get('same_control_ablation'))
if 'sampling_boundary' in FEATURES:
 from method_sampling_boundary import add_section as add_sampling_section
 add_sampling_section(p,sub,eq,table,cases,D['sampling_boundary_development'])
if 'hardware_sclr' in FEATURES:
 from method_hardware_sclr import add_section as add_sclr_section
 add_sclr_section(p,sub,eq,table,cases,D['hardware_sclr_development'])
if 'hardware_sload' in FEATURES:
 from method_hardware_sload import add_section as add_sload_section
 add_sload_section(p,sub,eq,table,D['hardware_sload_development'],D.get('vendor_ff'))
fig('candidate_flow.png','图4  当前候选的通用结构处理及保守退出')
sub(('2.3.9' if 'hardware_sload' in FEATURES else '2.3.8' if 'hardware_sclr' in FEATURES else ('2.3.7' if 'sampling_boundary' in FEATURES else ('2.3.6' if 'observable_decode_joint' in FEATURES else '2.3.5')))+'  源码及外部接口')
source_rows=[['opt_pmux.cc','两个模式的注册、结构过滤与统一调度'],['pmux_init_zero.h','时钟FF及受支持可写RAM的源初态声明'],['pmux_share_cone.h / pmux_share_banks_v2.h','多层数据通路、双输出bank及例外融合'],['pmux_resource_share.h / pmux_share_dag.h','全字运算共享、闭合选择DAG整理']]
if 'small_rom' in FEATURES:source_rows.append(['pmux_small_rom.h','有界5位地址常量ROM共享'+('及精确残差修正' if 'exact_rom_residual' in FEATURES else '')])
if 'exact_rom_residual' in FEATURES:source_rows.append(['pmux_rom_residual.h','基函数选择、残差地址组与全32地址精确校验'])
if 'width3_mixed_carry' in FEATURES:source_rows.append(['pmux_share_carry3.h','三位XOR/ADD/SUB共享传递链；'+('支持同一算子A/B匹配的合法signed参数' if 'signed_carry3' in FEATURES else '无符号范围')])
if 'priority_group4' in FEATURES:source_rows.append(['pmux_priority_grouping.h','四分支、零默认优先链精确分组；不要求one-hot'])
if 'observable_decode_joint' in FEATURES:source_rows.append(['pmux_observable_decode.h','使能约束下的状态投影与公共译码因子联合提交'])
if 'sampling_boundary' in FEATURES:source_rows.append(['pmux_sdffe_boundary.h','PMUX私有采样边界复位/使能重述；保持状态转移'])
if 'hardware_sload' in FEATURES:source_rows.append(['pmux_cycloneiv_sload.h','三臂互斥PMUX完整叶分支向SLOAD/ASDATA迁移'])
if 'hardware_sclr' in FEATURES:source_rows.append(['pmux_cycloneiv_sclr.h','显式Cyclone IV目标的SCLR映射及已知初态逐位编码'])
source_rows.append(['synth_intel.cc / CMakeLists.txt','proc后与coarse的固定调用；编译进主程序'])
add('code','read_verilog CASE.v\nsynth_intel -family cycloneiv -top TOP')
p('CASE.v与TOP来自固定九例清单；两臂使用相同脚本文件，差异仅在被调用的Yosys二进制。'+('计时脚本仅含上述两条命令；全部计时结束后另行运行同样两条命令并附write_json捕获资源网表，导出进程不进入效率统计。' if V3 else '本次绑定仍采用v2测量，计时进程另含stat和JSON导出；它与上述C145展示的两命令范围分别标注。')+'不修改WIDTH、LANES等默认参数。启动脚本设置同一ABC绝对路径并保留实际调用记录；脚本层面没有按用例选择某个内部算法的开关。')
table('表4  当前主要源码与职责',['文件','职责'],source_rows,[6.2,8.45])
sub(PROOF_SECTION+'  完整形式证明与旧反例的关系')
p('本轮主证明从原RTL的逻辑零初态契约直接到当前候选的实际默认综合端点。gold侧将未指定时钟FF初态明确为0并保持显式初值；gate侧读取捕获的实际ABC9后端点，再以受限dffeas模型解释映射power_up和控制。源RTL、参数、候选二进制、生产端点及证明副本均以哈希关联。')
fig('proof_chain.png','图5  源逻辑初态契约到实际候选的证明与证据绑定')
p('完整证明保留自由外部输入；clock、reset、enable不被固定成有利激励。clk2fflogic保留实际输入时钟边沿关系，全部顶层输出及所需状态关系置于同一分区共同证明基础情况和归纳步骤。内部匹配状态不作为未经证明的切点假设。工具报告内历史字段名baseline在此运行中指向送入runner的候选，必须按端点哈希解释角色，不能据名称误报为原默认基线。')
if D.get('candidate_side_normalization_has_zinit'):
 p('当前工作证据的候选归一化脚本仍含zinit -all。不能仅凭最终PASS宣称该步骤完全没有补齐未指定状态；冻结前须核查逆映射后每个FF位的显式初值，并优先以删除候选侧zinit的完整证明消除歧义。本工作稿不会把初始化微例的“候选侧无补零”推广为这份九例报告的配置事实。')
else:
 p('当前候选证明侧不追加zinit或setundef初始化修补；受限逆映射读取端点实际power_up属性，初始化结论由实际综合产物承担。源侧零初始化与候选侧归一化承担不同职责，完整脚本和初始化审计随证明记录保留。')
 inventory=D['candidate_initialization_inventory']
 p(f"端点初始化检查共覆盖{sum(c['normalized_state_bits'] for c in inventory)}个状态位，逆映射后的显式0为{sum(c['explicit_0'] for c in inventory)}位、显式1为{sum(c['explicit_1'] for c in inventory)}位，未知位为0；每个映射dffeas均实际携带power_up高或低参数，不借用模型默认值补齐。这里的init属性来源是当前候选的实际映射参数，不能说成用户原RTL本来就写有这些初始化声明。")
p('r09旧链保留原RTL的未指定初态，按EQY未知值语义证明定义行为精化，再比较同映射初态端点。它并未证明源逻辑全0时的初始输出。新方法对“逻辑零初态”这一具体要求给出更直接的保证：初始行为在实际综合前被约束，并从源直接证明到交付候选；这不等同于声称新证明在任意初态关系上都是旧证明的超集。')
p('旧默认基线的test4严格逻辑零反例仍真实存在。源逻辑0与旧映射物理0的反相编码不一致，不会因新程序通过而消失。因此必须区分两项成立的陈述：面积对照仍使用原默认基线；功能证明使用源逻辑零契约及新候选。不能同时要求旧基线物理0与新候选物理0直接等价，并声称它们都代表源逻辑0。')
h('第三部分  完成情况及性能测试',39)
h('完成情况',41)
p(f'以下结果仅对应{V}及本次绑定文件[9]。原4例和新增5例保持源文件字节与默认参数，未将扩展研发样本加入正式均值。版本、工具哈希、原始测量、每例证明端点和报告SHA-256保存于证据清单。')
if not D['release_ready']:p('工作稿所列候选在冻结前可更换，发布时必须同步更新全部表图。')
if M['individual_at_least_20_count']==9:
 lowest=min(cases,key=lambda c:c['area_reduction'])
 p(f"本轮九例各自均超过20%，最低为{short(lowest['id'])}的{100*lowest['area_reduction']:.4f}%。这是当前默认用例的逐项实测；FAQ规定的正式聚合口径仍是九例缩减率等权平均。")
table('表5  正式九例及结构范围',['用例','结构摘要','状态特征'],json.loads((R/'case_descriptions.json').read_text(encoding='utf-8')),[3.0,6.2,5.45])
p('test2原RTL敏感列表会影响事件驱动仿真的触发方式。源到候选EQY采用Yosys read_verilog/proc的综合解释；ModelSim比较的是映射参考与实际候选，不能据此声称已复现原RTL事件敏感列表的逐事件行为。形式和仿真各自说明输入、端点与初态，不利用修订源文件或缩小参数把面积、证明和波形混成同一项证据。')
h('工程成果',43)
sub('3.2.1  冻结工具与测量政策')
p('基线来自公开提交d0e71cfb7bcafe2b437f3edc1789b69e99ecd55a；候选包含内置pass及固定集成调用。官方FAQ提及的dirty补丁未公开，本地可复现对照不等于已认证官方未公开二进制。两臂使用同一ABC文件，逐次实际命令与SHA-256检查结果写入测量报告；不能由日志中的占位显示名称反推它忽略了ABC环境设置。')
p('当前采用'+SCOPE['title']+'。'+SCOPE['summary']+SCOPE['qualification'])
if V3:
 p('C145展示读取源文件与synth_intel流程，C87/C92要求从Yosys启动至结束的全生命周期；本轮按展示命令确定进程内容。synth_intel内置的统计、检查、日志以及等待ABC仍计入时间，没有在综合内部扣除某段耗时。全部初测及复测结束后才开始独立面积捕获，源文件、工具、ABC、门库和脚本散列一并核对。')
 p('独立捕获的JSON用于按叶实例分类LUT、标量取反及DFF；每臂均与全部计时记录及首例基线预热的内置最终top统计逐类型核对。该关系证明资源清单一致，不等于计时进程曾输出JSON，也不证明两次网表逐位相同。完整网表与候选生产端点的绑定、EQY仍各自单独验证。')
p('旧v2包含附加stat与JSON导出，历史成功和失败均按原范围保留。C92没有明确答复所有流程是否必须排除导出，因此本书不将v2称为无效数据；也不把v2与v3的时间差归因于算法改进。不同范围的结果不拼接为同一份通过报告。')
p('计时为Yosys主进程创建到退出的墙钟，覆盖完整综合与等待ABC的流程；峰值工作集来自同一次运行的主进程PeakWorkingSetSize。EQY和ModelSim不在综合效率计时内。正式政策先对首例基线预热10次；初测若时间比或内存比超过1.05且符合短例条件，就完整复测五对，分别取两臂算术均值，初测不加入复测均值。全部记录保留，不提前停止或挑选最快样本。')
if D.get('performance_environment_note'):
 p('主批r30_run01因已记录的C盘空间事件，原基线安装在C盘、优化安装在D盘；原输入和公共ABC在C盘，计时输出及子进程TEMP/TMP在D盘，未修改系统环境。各比值严格采用该批次自身两臂记录。随后实际迁移All将两侧程序和输入置于同一D盘，作为独立复现，不能混合两批样本、挑选较优值或把存储环境差异解释为算法收益。')
if rechecked:p(f'本次触发五对复测的用例为{rechecked}；其余用例采用初始一对。各表同时列明采用的对数，不能沿用旧版本“全部无复测”的描述。')
else:p('本次九例均未触发复测，每例采用初始一对；这仍是一轮固定政策下的机器测量，不代表跨硬件及任意后台负载的统计保证。')
eq('topt/tbase≤1.05，Mopt/Mbase≤1.05',r'\frac{t_{\mathrm{opt}}}{t_{\mathrm{base}}}\leq1.05,\qquad\frac{M_{\mathrm{opt}}}{M_{\mathrm{base}}}\leq1.05')
sub('3.2.2  逐例面积与算术平均')
table('表6  逐例LUT+NOT与缩减率'+('（独立捕获）' if V3 else '（v2进程内导出）'),['用例','原默认基线','当前候选','缩减率'],[[short(c['id']),c['baseline_cells']['logic_units'],c['optimized_cells']['logic_units'],f"{100*c['area_reduction']:.4f}%"] for c in cases]+[['总量／算术均值',M['baseline_sum'],M['optimized_sum'],mean]],[3.9,3.45,3.45,3.85])
p(f'最后一行的前两项为单元总量，末项为九个逐例缩减率的等权算术平均{mean}。按总量计算的加权缩减{weighted}另列，不用它代替评分均值。{M["individual_at_least_20_count"]}/9例单独达到20%；各例原始结果完整保留。')
fig('area_results.png','图6  九例缩减率；20%虚线仅作参考，不是单例门槛')
table('表7  面积分类及状态单元核对',['用例','DFF 基线→候选','LUT 基线→候选','NOT 基线→候选'],[[short(c['id']),f"{c['baseline_cells']['dff']}→{c['optimized_cells']['dff']}",f"{c['baseline_cells']['lut']}→{c['optimized_cells']['lut']}",f"{c['baseline_cells']['inverter']}→{c['optimized_cells']['inverter']}"] for c in cases],[3.9,3.6,3.6,3.55])
p('表7将触发器和逻辑单元分开报告，DFF变化不能混入LUT+NOT缩减率。源逻辑初态明确后可能影响状态优化结果，因此资源分类和功能证明必须绑定同一候选，不能从旧版本只拷贝更低的单元数。最终叶单元、I/O、unknown类别和默认参数原始统计均保留。')
sub('3.2.3  逐例效率与复测依据')
table('表8  '+SCOPE['short']+'：墙钟、比例及采用对数',['用例','基线/s','候选/s','时间比','对数'],[[short(c['id']),f"{c['baseline_mean_wall_seconds']:.6f}",f"{c['optimized_mean_wall_seconds']:.6f}",f"{c['time_ratio']:.4f}",c['pairs_in_aggregate']] for c in cases],[3.0,3.2,3.2,3.0,2.25])
table('表9  '+SCOPE['short']+'：主进程峰值工作集及比例',['用例','基线/字节','候选/字节','内存比'],[[short(c['id']),f"{c['baseline_mean_peak_ws_bytes']:.1f}",f"{c['optimized_mean_peak_ws_bytes']:.1f}",f"{c['memory_ratio']:.4f}"] for c in cases],[3.8,3.8,3.8,3.25])
p(f'最大时间比{M["max_time_ratio"]:.6f}，最大内存比{M["max_memory_ratio"]:.6f}；两项{eff}。采用五对均值时，平均峰值字节可能出现小数，它是进程峰值计数的算术平均，不是单次计数精度改变。候选最长墙钟{M["max_optimized_wall_seconds"]:.6f}秒、最大峰值工作集{M["max_optimized_peak_ws_bytes"]:.0f}字节。')
fig('performance_results.png','图7  '+SCOPE['short']+'时间与工作集比；初测或五对复测按规则采用')
p('面积下降与软件内存下降没有必然对应关系，局部重构也可能因扫描和构图增加运行时间。本项目把超过门槛的候选排除在当前最佳之外，保留其原始复测记录；不把更高均值包装成已达全部约束。'+('当前近千节点证据另见补充规模段，独立于正式九例。' if SCALE else '未绑定当前候选的旧954叶单元规模实测仅属于研发历史，不能据此宣称当前版本已完成近千节点验证。'))
sub('3.2.4  版本决策与完整证明')
history_rows=[['r09','24.0868%','早期含导出；定义行为精化，未证明源逻辑零初态']]
for x in D['history']:
 if x['measurement_schema']==2:history_rows.append([x['version'],f"{x['mean_area_percent']:.4f}%",'严格源初态证明；'+('本范围效率通过' if x['efficiency'] else '本范围效率失败')])
table('表10a  含导出范围的研发记录（早期及v2）',['版本','九例算术均值','证据与范围内结论'],history_rows,[2.4,3.7,8.55])
history_v3=[[x['version'],f"{x['mean_area_percent']:.4f}%",'严格源初态证明；'+('本范围效率通过' if x['efficiency'] else '本范围效率失败')] for x in D['history'] if x['measurement_schema']==3]
if history_v3:table('表10b  v3两命令范围的研发记录',['版本','九例算术均值','证据与范围内结论'],history_v3,[2.4,3.7,8.55])
p('r10把初始化声明移到默认综合入口，r11补充受限可写RAM，r12加入小ROM余因子共享。此后候选即使扩大面积收益，仍可能因test2、test3等小例的额外开销未过逐例效率门槛。表10是联合研发轨迹，不是单因素消融；历史数据保留其当时二进制、证明设置和测量政策，不能挪作最终候选的证据。')
table('表11  当前九例完整形式结果',['用例','源逻辑0→实际候选','联合证明分区'],[[short(c['id']),c['proof'],'1'] for c in cases],[3.5,6.2,4.95])
p('九例分别在单一联合分区证明全部输出与必要状态关系，输入仅来自原设计外部端口；未加入输入约束或把待证状态关系作为假设。')
p('表11不代表旧默认映射基线的严格零反例已被修复。原报告中的角色名称由绑定器归一为源到候选，PASS标记、配置、输出位覆盖和实际端点哈希逐一检查；面积测量的原基线仍单独保存。评分取决于原题与FAQ的最终评审，不以表11自动推导总分。')
if D['proof_origin']['mode']=='exact_endpoint_reuse':
 p(f"本候选的形式结果复用{D['proof_origin']['version']}已经完成的完整证明。复用依据是当前全部实际IL端点与被证明端点逐字节SHA-256一致，并保持同一源文件、模型和配置；它不是当前候选重新启动九例EQY实跑。面积相同、最终资源JSON相同或删去metadata后相同，都不足以替代这一严格端点检查。")
elif D['proof_origin']['mode']=='fresh_run':
 p('当前绑定的九例完整形式证明为本候选实际重新执行的记录；没有把历史相似面积或归一化后的网表近似当成端点复用。原始PASS、执行日志、源文件和未修改端点哈希随交付保存。')
h('测试成果',48)
sub('3.3.1  当前版本波形与初始化观察')
if SIM:
 p(f'当前波形来自{V}本次ModelSim实际运行，共{SIM["total_checked"]}个有效采样，九例无输出差异、X/Z或初始化契约失败。参考侧由原编译器在顺序优化前声明同一逻辑零初态得到，候选侧为当前实际ABC9后端点；参考侧不是用于面积评分的原默认基线。')
 table('表12  当前ModelSim逐例记录',['用例','周期数','比较次数','差异/XZ/契约失败'],[[short(c['id']),c['cycles'],c['checked'],f"{c['mismatch_samples']}/{c['unknown_samples']}/{c['contract_failed']}"] for c in SIM['cases']],[3.7,3.0,3.3,4.65])
 notes=json.loads((R/'current_wave_notes.json').read_text(encoding='utf-8'))
 if 'hardware_sload' in FEATURES:
  p('本轮使用第2.3.8节独立验证的受限SCLR/SLOAD模型，保留实际ENA、SCLR、SLOAD、ASDATA和显式power_up；全部原语先做端口与参数检查。旧域保留真实异步CLRN，新域固定CLRN=PRN=1、ALOAD=0，正常器件全局控制隐含为1，按ENA、SCLR、SLOAD、D优先级取样。它不是通用厂家库，不是直接原RTL事件列表仿真，不覆盖任意四态或器件时序。')
 elif 'hardware_sclr' in FEATURES:
  p('本轮使用第2.3.7节独立验证的受限SCLR扩展模型，保留实际ENA、SCLR及显式power_up；所有实际原语端口逐项核对。旧SCLR=0域允许原异步清零，新域要求CLRN=PRN=1且ASDATA/ALOAD/SLOAD=0。两域均限于所述二值控制语义，不使用简化cells_sim.v代替行为模型，也不宣称完成通用厂商库或器件时序仿真。')
 elif D.get('simulation_model_scope'):
  p('本轮FF仿真使用未修改intel/common/ff_map.v的受限逆模型，保留正沿时钟、正使能ENA、低有效异步清零CLRN及实际显式power_up。每个FF均检查PRN=1，ASDATA、ALOAD、SCLR、SLOAD=0；其他控制配置拒绝。该模型不是通用厂商原语模型，也未把简化cells_sim.v用作FF行为源。这里没有验证非零SCLR等后续扩展配置。')
 fig('modelsim_zero_init.png','图8  当前test4无复位无边沿初态与异步复位观察');p(notes['paragraphs'][0])
 wave_offset=1 if D.get('sampling_waveform') else 0
 if wave_offset:
  fig('modelsim_zero_overview.png','图9  当前balanced全程激励阶段与检查计数');p(notes['overview_paragraph'])
 fig('modelsim_zero_detail.png',f'图{9+wave_offset}  当前代表例局部数据变化与逐点输出比较');p(notes['paragraphs'][1])
 fig('modelsim_zero_finish.png',f'图{10+wave_offset}  当前代表例结束窗口及比较计数');p(notes['paragraphs'][2]);p(notes['paragraphs'][3])
 if D.get('observable_waveform'):
  sub('test3：使能约束下的可观察状态')
  fig('modelsim_observable.png',f'图{11+wave_offset}  test3未使能D可异、可观察Q保持的实测示例')
  for paragraph in notes['observable_paragraphs']:p(paragraph)
 if D.get('sampling_waveform'):
  sub('pipeline：保持控制与复位优先级')
  fig('modelsim_sampling_boundary.png','图13  pipeline实际ENA关系及保持、复位的两个窗口')
  for paragraph in notes['sampling_paragraphs']:p(paragraph)
 if D.get('simulation_model_scope',{}).get('sload_waveform'):
  sub('pipeline：同步装载对实际数据来源的选择')
  fig('modelsim_sload_selection.png','图14  SLOAD=0取D、SLOAD=1取ASDATA的实际采样窗口')
  for paragraph in notes['sload_paragraphs']:p(paragraph)
else:
 p('当前候选的ModelSim材料尚未绑定，本工作稿不插入旧版本图片。r11已有40684次零差异采样，test4在无复位、无时钟边沿时only_5b为0，随后仅断言低有效复位时为1；该记录属于r11研发证据，不能改名为r12、r13或更晚版本的当前结果。最终候选确定后须使用已改进的隔离采样runner重新运行并绑定端点。')
if SIM:
 p('本书波形由当次真实ModelSim导出的VCD重绘，并标注非GUI截图；原WLF、VCD、CSV、激励与工具日志保留。test4初态图使用六个隔离前导点，分别观察无时钟边沿的初态、复位断言及释放，正常周期激励随后开始。绘图取同时间戳最终记录值，判错以规定采样点CSV为准；有限仿真不证明delta-cycle无毛刺或真实器件时序。')
else:
 p('最终图必须由当次真实ModelSim导出的VCD重绘，并明确标注非GUI截图；初态与复位观察需独立于正常周期激励，原WLF、VCD、CSV、激励与工具日志一并保留。')
if SCALE:
 sub('3.3.2  接近千节点的独立规模验证')
 p(f"补充样例将四份原模块以默认参数装入同一wrapper，保留{SCALE['free_input_bits']}位外部输入、{SCALE['output_bits']}位原输出和四个自由时钟。节点按实际最终映射叶单元计数：原版{SCALE['baseline_actual_nodes']}、候选{SCALE['optimized_actual_nodes']}，不按RTL位宽推算或凑成1000。它不是第十个官方用例，不进入九例面积均值。")
 table('表12a  独立规模样例的资源与效率',['指标','原默认基线','当前候选'],[
  ['最终映射叶单元',SCALE['baseline_actual_nodes'],SCALE['optimized_actual_nodes']],['LUT+标量取反',SCALE['baseline_logic_units'],SCALE['optimized_logic_units']],['DFF',SCALE['baseline_dff'],SCALE['optimized_dff']],['墙钟/s',f"{SCALE['baseline_wall_seconds']:.7f}",f"{SCALE['optimized_wall_seconds']:.7f}"],['主进程峰值/字节',SCALE['baseline_peak_ws_bytes'],SCALE['optimized_peak_ws_bytes']]],[6.1,4.275,4.275])
 p(f"该样例逻辑面积下降{SCALE['area_reduction_pct']:.4f}%，时间比{SCALE['time_ratio']:.6f}、内存比{SCALE['memory_ratio']:.6f}；两臂均低于60秒与2GB，本候选的相对两项均不超过1.05。原版预热10次后采用初始一对，未触发五对复测。计时只有read_verilog及synth_intel，使用其默认flatten；面积在全部计时后独立捕获。")
 audit=SCALE['formal_audit'];power=audit['candidate_dffeas_explicit_power_up']
 p(f"完整EQY在同一分区证明全部{SCALE['output_bits']}位原输出和{SCALE['formal_joint_state_relation_bits']}位附加状态关系，后者为联合证明目标而非assume。{SCALE['free_input_bits']}位原输入中{audit['partition_relevant_input_bits']}位进入有效输出锥，其余原本未使用并自然消除；未新增输入约束。四个输入时钟的真实边沿由clk2fflogic保留。候选归一化无zinit或setundef，{SCALE['optimized_dff']}个状态的power_up均明确，其中{power.get('low',0)}个low、{power.get('high',0)}个high。")
 p(f"旧954节点记录采用额外前置hierarchy/flatten，与本轮默认综合流程不同，不能把两次数字相减当作版本收益。当前成功批次、端点哈希和归纳证明单独保存；前轮预检记录保留在其各自版本目录，不改写成本次执行。这个{SCALE['baseline_actual_nodes']}节点实例给出原题规模界限内的客观实测，不能推出所有不超过1000节点的电路都已验证。")
sub('3.3.3  复现及证据检查' if SCALE else '3.3.2  复现及证据检查')
p('复核顺序为：先核对版本和SHA-256，再确认原始九例与默认参数；检查默认脚本、两处内置调用和实际ABC路径；读逐例面积、同次效率和复测政策；最后检查源到候选的完整证明、初始化审计及当次ModelSim记录。任何二进制或源码修改都需要重新绑定相应结果，不以旧版本通过替代新端点验证。')
p('可迁移运行文件取自当前候选的冻结安装目录，程序SHA-256与正式测量一致；源码取自对应候选快照。持续研发的共享构建目录可能已是后续试验版本，不能直接复制它覆盖当前交付程序。')
if D.get('migration_qa'):
 p('r20迁移首先完成含空格目录下的test4不计时捕获与直接EQY启动检查。其后的首次完整All批次中，九例测量和端点绑定通过，但4个长名用例因Windows未规约路径过长出现工具读取ERROR，另5例证明通过；原失败目录与报告保留，不能将这4项错误解释为PASS或逻辑反例。')
if D.get('migration_all_qa'):
 p('路径修复后的r20新完整All批次通过PowerShell入口重新完成九例v3计时、独立面积与端点捕获，以及无候选补初值的九例完整EQY，退出码0、全部客观检查通过。证明在独立短目录运行，443个文件原样归档，完成时原目录、归档和清单的文件集合及SHA逐一相同。')
 add('code','RELOCATION_FIXED2_AUDIT.json\nSHA-256:\nabfe853ca672a5a32da7133d22acf47c519e459526c58abc2a6c49accedf4b8d')
 p('全部持久归档已逐文件重新核对；部分TEMP源文件当前已不可复核，不据此改写当时记录。此批次为r20历史路径修复证据，不替换当前候选主表，也不改名为当前候选运行。')
if D.get('current_migration_all_qa'):
 cm=D['current_migration_all_qa'];cmm=cm['prepared_metrics']
 recheck_note=('、'.join(short(x) for x in cmm['rechecked_ids'])+'按预定规则各完成5对复核并采用复核均值，其余使用初始一对') if cmm['recheck_count'] else '未触发复核'
 p(f"当前{V}另在含空格的迁移目录，经现有PowerShell 7入口实际完成一次完整All：{cm['timed_process_count']}个计时进程（含预热），{recheck_note}；全部计时结束后捕获面积与端点，再直接证明九例源逻辑0到实际候选，九例完整EQY均通过，退出码0。面积均值与主表相同；本迁移批次最大时间比{cmm['max_time_ratio']:.6f}、内存比{cmm['max_memory_ratio']:.6f}，均不超过1.05。该独立复现批次不替换主表正式批次，不据两次时间差推断算法收益。")
 p(f"迁移前后{cm['indexed_file_count']}项包文件及{cm['package_archive_mapping_count']}项原始路径映射保持，{cm['proof_archive_file_count']}份证明文件在完成时由短执行目录逐字节核对后归档，持久归档亦经逐文件复核。路径预检最大{cm['proof_archive_validation']['path_preflight_max_units_with_reserve']}个UTF-16单位，小于240。该迁移审计覆盖冻结程序和证据包，项目书未列入当次验收范围。")
 add('code',Path(D['sources']['current_migration_all_qa']['path']).name+'\nSHA-256:\n'+D['sources']['current_migration_all_qa']['sha256'])
 if 'current_migration_storage_history' in D['sources']:
  p('本次组包曾因C盘空间不足中断，未完成副本和错误记录已迁至D盘保留；另有只读准备阶段的旧路径适配错误，修正后才启动上述一次All。二者均未造成All重跑，也不记为算法失败。历史r23的Python别名取哈希及Windows PowerShell 5.1策略异常独立保留。')
 elif 'hardware_sload' in FEATURES:
  p('R30迁移前保留两项准备错误：生成脚本时旧header匹配条件不合，以及把波形ZIP条目误当成原目录文件全集。后者逐项确认ZIP内365项字节相同，目录另有200项受限ModelSim缓存和transcript；未删除或刷新stage。两项均未进入All，修正准备检查后实际只运行上述一次All。历史r23的Python Store别名取哈希与Windows PowerShell 5.1策略异常另存，不算作本次R30启动失败。全程未修改系统执行策略。')
 else:p('历史r23的两项前置异常也保留：Python Store别名无法取哈希，以及Windows PowerShell 5.1被既有策略阻止；均未进入该版All。该版改用真实Python和现有PowerShell 7后完成一次All，未修改系统执行策略。')
elif D.get('prior_r23_migration_all_qa'):
 p('历史r23另在含空格目录完成一次完整All，九例测量和直接EQY通过，443份证明归档经SHA核对。该批次只证明r23交付快照的迁移，不改名为当前候选复现成绩；原始审计及前置启动异常独立保留。')
 if not D['release_ready']:p('当前候选的完整迁移复现尚待单独绑定，准备稿不提前填写通过结论。')
p('使用时在PowerShell 7终端进入包目录，直接运行Run-OfficialTests.ps1；不要切换到Windows PowerShell 5.1，也不以修改执行策略或Bypass参数处理启动问题。入口只设置子进程ABC/PATH。源码重建助手使用当前PowerShell 7另起子进程；这项启动修正不代表本轮已重新编译程序，重建后仍须另做完整验证。')
table('表13  交付材料及复核重点',['材料','内容','重点'],[
['baseline / optimized','原默认基线、候选程序、依赖及入口','使用同一ABC；入口负责配置路径'],['source / cases','当前源码、原始九例和默认参数','无用例名特判；参数不覆盖'],['proof / evidence','源逻辑0证明、端点与测量报告','原始角色名称与实际端点对应'],['ModelSim证据',Path(D['sources']['modelsim']['path']).parent.name+'：WLF/VCD/CSV、图及重放脚本' if SIM else '当前仿真待绑定',('本次七图由新VCD生成；有限采样，非GUI截图' if 'hardware_sload' in FEATURES else '本次六图由新VCD生成；有限采样，非GUI截图') if D.get('sampling_waveform') else ('保留本次原运行与四图，追加test3观察图；未重跑仿真' if D.get('observable_waveform') else ('更正审计标签/生成器；原仿真和图字节复用，未重跑或重绘' if D.get('modelsim_evidence_revision') else '不是旧默认面积基线；当次候选哈希一致'))],['project_book','Word、LaTeX、PDF、图源和短对照报告','表图与同一冻结报告对应']],[3.2,5.5,5.95])
h('第四部分  总结',50)
h('可扩展之处',53)
p('下一步验证应沿明确边界展开：补充更多RAM类型和锁存器前，先定义可支持的初始化行为与失败策略；开展更大规模或不同参数测试时，独立记录输入、完整证明及性能。对控制恢复、bank、算术、DAG和ROM规则开展固定工具链下的消融，才有依据区分各模块贡献。当前九例成功不能外推全部设计。')
p('公开提交构建、原默认面积基线和源逻辑初态参考应持续分离。若获得官方完整补丁，应在相同政策下重建、重测、重证；不能仅替换版本字符串。为适应更严苛效率条件，优化应减少自定义pass的无效扫描和重复构图，同时保持通用结构判断，不能通过绕过其他综合步骤获得表面加速。')
h('心得体会',55)
p('本项目的主要经验来自反例：逻辑0与物理0不一定是同一个状态，晚补初值也不一定能找回早已删除的历史。把初始化声明放到顺序变换之前，让实际产物承担契约，再从源直接验证，才能使“通过”与交付行为对应。保留旧反例和未证出的中间记录，比只展示成功状态更有助于说明方法边界。')
p(f'当前绑定候选的面积均值为{mean}，{SCOPE["short"]}逐例效率结论为{eff}，完整源逻辑零证明九例通过。成果由内置程序、固定用例、同次测量和可追溯端点共同构成；不是任意初态强等价、理论最优或满分承诺。')
h('第五部分  参考文献',58)
for ref in json.loads((R/'references.json').read_text(encoding='utf-8')):add('reference',ref)
if __name__=='__main__':
 (R/'content.json').write_text(json.dumps(blocks,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'candidate':V,'release_ready':D['release_ready'],'blocks':len(blocks),'tables':sum(b['kind']=='table' for b in blocks),'figures':sum(b['kind']=='figure' for b in blocks),'length_limits':{k:[len(x),n] for k,(x,n) in limits.items()}},ensure_ascii=False))
