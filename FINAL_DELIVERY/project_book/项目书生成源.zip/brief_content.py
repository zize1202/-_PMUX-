"""Three-page comparison sharing all rules and numbers with the main manuscript."""
from content import D,M,V,cases,short,R,mean,weighted,eff,SCOPE,V3,SCALE,PROOF_SECTION
from requirements import brief_requirement_rows
import json
blocks=[];limits={}
def add(k,t,**kw):blocks.append(dict(kind=k,text=t,**kw))
def p(t):add('p',t)
def sub(t):add('sub',t)
def table(t,headers,rows,widths):add('table',t,headers=headers,rows=[[str(v) for v in row] for row in rows],widths=widths)
def page():add('pagebreak','')
add('title','原题要求与当前结果对照')
p(f'候选：{V}。依据原题印刷p4—6及FAQ答复列C；九例源文件、默认参数保持。功能按源逻辑零初态验证，面积仍对比原默认基线。')
table('表1  原题要求与当前证据',['要求／定位','当前结果／证据','边界'],brief_requirement_rows(D),[4.0,6.1,4.55])
p('C149第一问同时询问独立消融和最低收益，答复“一、不允许”指向不唯一，不能据此称组合或消融已获确认；本项目按其他明确规则实施。详细原文对照见主书表2a、2b。')
page();sub('九例逐项结果')
p('v3只计read_verilog与synth_intel的完整进程；全部计时后独立捕获面积，并核对逐次内置资源清单。时间与主进程峰值同次采集。')
table('表2  逐例面积与效率（'+SCOPE['short']+'）',['用例','基线','候选','缩减率','时间比','内存比'],[[short(c['id']),c['baseline_cells']['logic_units'],c['optimized_cells']['logic_units'],f"{c['area_reduction']*100:.2f}%",f"{c['time_ratio']:.4f}",f"{c['memory_ratio']:.4f}"] for c in cases]+[['总量／均值',M['baseline_sum'],M['optimized_sum'],mean,'逐例核验','逐例核验']],[3.0,1.6,1.6,2.7,2.8,2.95])
p(f'末行列单元总量和九例等权均值；加权缩减{weighted}另算。面积逐例不增，{M["individual_at_least_20_count"]}/9例单独≥20%。')
rechecked='、'.join(short(x) for x in M['rechecked_ids'])
p(('触发五对复测：'+rechecked+'；其余采用初始一对。' if rechecked else '九例均采用初始一对，未触发复测。')+'逐例时间和内存比均≤1.05。EQY/ModelSim不计入综合时间；v2历史另列，范围差异不算算法收益。')
p('完整EQY：原RTL逻辑0→实际候选，外部输入自由，全部输出及必要状态关系共同证明。runner中的baseline槽实际装入候选，由端点SHA核实。')
if SCALE:
 p(f"独立规模：{SCALE['baseline_actual_nodes']}→{SCALE['optimized_actual_nodes']}叶单元，逻辑面积{SCALE['baseline_logic_units']}→{SCALE['optimized_logic_units']}；完整单分区EQY通过，四时钟自由。该样例满足规模/时间/内存界限，不计入九例均值。")
else:p('近千节点运行与初始化微例是独立证据，不能混入九例均值。未与当前候选绑定的旧规模结果不写成当前版本已完成；ROM无关项不补0，未支持锁存器不列为通过。')
sub('复核入口')
p('在PowerShell 7当前终端运行包内入口，只设置子进程ABC/PATH；不调用Windows PowerShell 5.1，不改执行策略。按binding核对proof、performance、simulation_report及SHA。')
if D.get('current_migration_all_qa'):p('当前候选含空格目录迁移All九例通过，443份证明归档SHA一致；该复现批次独立于主表。旧r20四项路径ERROR及修复记录保留。')
elif D.get('migration_all_qa'):p('历史r20 pathfix2完整All九例通过，443文件归档SHA一致；旧4项路径ERROR保留。当前候选沿用短路径机制，该历史批次不改名为当前成绩。')
page();sub('当前波形与逻辑零初态')
if D['modelsim']:
 notes=json.loads((R/'current_wave_notes.json').read_text(encoding='utf-8'))
 p(f'当前{V}真实ModelSim九例共{D["modelsim"]["total_checked"]}次有效采样，无差异、X/Z或初始化契约失败。参考侧为原编译器前置同一逻辑零契约，不是原默认面积基线。')
 add('figure',notes['brief_caption'],file=notes['brief_figure'],width=12.6)
 p(notes['brief_reading'])
 p('图来自当前实际VCD重绘，明确非GUI截图；采样输出与CSV交叉核对。WLF、VCD、CSV、激励和日志均保留。有限采样不替代EQY，也不保证delta-cycle无毛刺或器件时序。')
else:p('工作稿尚未绑定当前候选波形；不以r11或r09旧波形替代。最终候选确定后，重新运行初始化隔离观察和正常向量，再生成此页。')
p('原题与FAQ逐项位置见项目书表2a、2b；初始化契约及旧反例关系见2.3.1、'+PROOF_SECTION+'，当前仿真证据见3.3.1。')
