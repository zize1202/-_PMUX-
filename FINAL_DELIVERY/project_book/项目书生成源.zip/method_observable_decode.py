"""Evidence-bounded r23 method section; no source-specific signal names in the rule."""
def add_section(p,sub,eq,table,cases,development=None,isolation=None,ablation=None):
    sub('2.3.5  可观察状态保持与公共译码因子联合重写')
    p('组合节点的每一时刻电平未必都被状态单元采样。该规则先检查PMUX完整输出Y的所有消费者：只允许未保护、使能高有效的DFFE，且D端完整同序连接Y，其他端口不再观察Y。再以该PMUX自身的等值码集合C构造active，而不是借用整个bank的选择信号。每个消费者的EN必须通过受限AND结构含有active这一必要因子；常量EN及未能证明的结构均跳过，不利用不可满足使能作为化简条件。')
    eq('EN⇒active=OR(SC)，∀c∈C：fj(c)=dj(c)',r'\mathrm{EN}\Rightarrow\mathrm{active}=\bigvee_{k\in C}S_k,\qquad f_j(c)=d_j(c)\quad(\forall c\in C)')
    p('对每一输出位，从常量0、1、某一选择输入位及其取反中，选取在C内所有码字都与原所选数据相等的函数f。以任一受影响触发器为例，EN=0时两侧均保持当前Q；EN=1时必有一个有效码，原D与f在该码上相同。因此改写保持任意二值当前Q下的下一状态。原PMUX默认输入须全部为X，已知默认值或Z不进入该规则；结论是受使能约束的采样状态转移保持，不能写成未使能时D在全域四态下相等。')
    eq('Q′=(EN?D:Q)=(EN?f:Q)',r'Q^{\prime}=(\mathrm{EN}\ ?\ D:Q)=(\mathrm{EN}\ ?\ f:Q)')
    p('同一选择变量的完整等值译码还可能含有共同文字。令H比较所有码字共有的位，Rk比较剩余位，则每个原比较可精确分解为H与Rk。实现保留原比较对象、输出连线、属性及全部消费者；这一因式分解自身保持0/1/X/Z的比较语义。它与前述状态投影职责不同：只有完整译码组、用作识别起点且继续保留的PMUX，以及至少两个可投影PMUX共同通过检查后才一次提交，不单独开启care投影。')
    eq('eqk(x,ck)=H(xcommon,ccommon) AND Rk(xremaining,ck,remaining)',r'\mathrm{eq}_k(x,c_k)=H(x_{\mathrm{common}},c_{\mathrm{common}})\land R_k(x_{\mathrm{remaining}},c_{k,\mathrm{remaining}})')
    p('适用范围有明确边界：选择宽度5—8位，完整bank含3—8个互异、已知的无符号等值比较，共同位2—4位、剩余位1—4位，care输出1—16位且有2—8臂。每个计划逐项复核全部32—256种二值赋值，数量由选择位宽确定。输入锥只接受明确白名单并在主输入或有时钟状态Q处截断；未知、缺失或冲突驱动、循环、计划输出回流、额外观察者以及受保护对象均拒绝。扫描深度、节点数和提交次数亦受预算限制。')
    if development:
        p(f"r23开发验证覆盖匿名重排总线、负文字投影和多个合法观察者：{development['positive_transition_sat_cases']}个正例完成任意当前Q的采样下一状态SAT证明；{development['rejected_unchanged_cases']}个拒绝例的完整JSON保持逐字节不变。公共因子另通过{development['four_state_factor_equations']}条四态等式检查，此检查不扩展为care投影的独立四态等价证明。这些记录用于检查通用守卫，未计入正式九例。")
    c=next(x for x in cases if x['id']=='test3')
    if ablation:
        a=ablation['comparison']
        p('为检查组合效果，补充实验固定同一r21中间快照、工具、ABC和映射后缀；各次对照端点逐字节相同，正常脚本仅输入路径不同。表3a是开发期中间网表原型记录；正式r23将通用守卫与联合重写编入C++ pass，外部入口仍是同一read_verilog和synth_intel。')
        table('表3a  同一冻结控制流下的四组原型结果',['配置','LUT+NOT','DFF','证明记录'],[
            ['对照',a['control']['logic_units'],a['control']['FF'],'本次未新增对照EQY'],
            ['仅care投影',a['care_only']['logic_units'],a['care_only']['FF'],'本次源逻辑0→实际端点PASS'],
            ['仅公共因子H',a['H_only']['logic_units'],a['H_only']['FF'],'既有完整PASS，重新核对端点'],
            ['care与H组合',a['care_plus_H']['logic_units'],a['care_plus_H']['FF'],'既有完整PASS，重新核对端点']],[3.6,2.6,1.8,6.65])
        p(f"四组映射结果的交互差值为{a['care_plus_H']['logic_units']}−{a['care_only']['logic_units']}−{a['H_only']['logic_units']}+{a['control']['logic_units']}={ablation['interaction_difference']}，说明该固定流程下收益不可相加；它不定位ABC内部机理，也不保证其他设计获益。只有新增care候选在本次新跑完整证明，不能说四组都重新证明或它们属于正式九例。旧r18b快照的care-only 12→13单列历史，不混入表3a。")
    elif isolation:
        a=isolation['arms']
        p(f"独立原型探索的结果分别为：仅care投影{a['care']['control']}→{a['care']['candidate']}，仅公共因子{a['factor']['control']}→{a['factor']['candidate']}，固定组合{a['combined']['control']}→{a['combined']['candidate']}个逻辑单元。care原型使用r18b快照，后两者使用r21捕获，后两者的对照端点逐字节相同；三次探索不是同一批原生消融，不能把差值相加，也不能据此宣称官方已认可组合方案的消融口径。")
    p(f"当前正式test3的原默认面积基线为{c['baseline_cells']['logic_units']}，本候选为{c['optimized_cells']['logic_units']}个LUT+NOT，按完整原生综合、源逻辑零EQY和v3测量共同核验。原型的12个逻辑单元不是这份正式面积基线；实验也不消除C149.1答复的解释歧义。第3.3.1节的真实波形展示一个可核实输出位的保持与采样过程，有限记录不替代形式证明。")
