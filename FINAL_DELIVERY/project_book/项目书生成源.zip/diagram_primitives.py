"""Three manuscript diagrams; exact vector geometry in millimetres, no experiment data altered."""
from pathlib import Path
import sys, json, hashlib, warnings
try:
    import matplotlib
except ModuleNotFoundError:
    sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'20261026_memory_lifetime_audit/figure_runtime/matplotlib'))
    import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Polygon
from matplotlib.path import Path as MPath
from PIL import Image, ImageOps
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'
FONT='C:/Windows/Fonts/msyh.ttc'
FONT_BOLD='C:/Windows/Fonts/msyhbd.ttc'
font_manager.fontManager.addfont(FONT)
font_manager.fontManager.addfont(FONT_BOLD)
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':9,
    'mathtext.fontset':'dejavusans','axes.unicode_minus':False,
    'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
    'figure.facecolor':'white','savefig.facecolor':'white'})
INK='#203444'; BLUE='#245C83'; TEAL='#137A72'; GRAY='#647480'
LINE='#637783'; LIGHT='#CDD6DC'; PALE='#F4F7F8'; WHITE='#FFFFFF'
WIDTH=144; DPI=400
warnings.filterwarnings('error', message='Glyph .* missing from font')

class Scene:
    def __init__(self,name,height):
        self.name=name;self.height=height;self.nodes=[];self.texts=[]
        self.fig=plt.figure(figsize=(WIDTH/25.4,height/25.4),dpi=DPI)
        self.ax=self.fig.add_axes([0,0,1,1]);self.ax.set(xlim=(0,WIDTH),ylim=(height,0));self.ax.axis('off')
    def text(self,x,y,s,size=9,color=INK,bold=False,ha='center',va='center',role='label',**kw):
        obj=self.ax.text(x,y,s,fontsize=size,color=color,weight='bold' if bold else 'normal',
            ha=ha,va=va,linespacing=1.45,**kw)
        self.texts.append((obj,role));return obj
    def line(self,p,color=LINE,width=.9,ls='solid',arrow=False):
        codes=[MPath.MOVETO]+[MPath.LINETO]*(len(p)-1)
        if arrow:
            obj=FancyArrowPatch(path=MPath(p,codes),arrowstyle='-|>',mutation_scale=7.5,
                linewidth=width,color=color,linestyle=ls,joinstyle='miter',zorder=1)
            self.ax.add_patch(obj)
        else:
            self.ax.plot(*zip(*p),color=color,lw=width,ls=ls,solid_capstyle='butt',zorder=1)
    def dot(self,x,y,color=LINE):self.ax.add_patch(Circle((x,y),.52,color=color,lw=0,zorder=2))
    def node(self,x,y,w,h,title,sub=None,color=INK,fill=WHITE,size=9.4):
        self.ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.1',
            fc=fill,ec=color,lw=.85,zorder=3))
        labels=[]
        if sub:
            labels.append(self.text(x+w/2,y+h/2-2.8,title,size,color,True,zorder=4,role='node_title'))
            labels.append(self.text(x+w/2,y+h/2+3.0,sub,7.7,GRAY,zorder=4,role='node_subtitle'))
        else:labels.append(self.text(x+w/2,y+h/2,title,size,color,True,zorder=4,role='node_title'))
        self.nodes.append((x,y,w,h,labels))
    def stage(self,n,y,label):
        self.ax.add_patch(Circle((8,y-2),3.3,fc=WHITE,ec=BLUE,lw=.9))
        self.text(8,y-2,f'{n:02}',7.5,BLUE,True)
        self.text(8,y+5,label,7.8,GRAY)
    def diamond(self,x,y,w,h,label):
        self.ax.add_patch(Polygon([(x-w/2,y),(x,y-h/2),(x+w/2,y),(x,y+h/2)],
            fc=WHITE,ec=BLUE,lw=.95,zorder=3))
        self.text(x,y,label,9.0,BLUE,True,zorder=4)
    def adder(self,x,y,color=BLUE):
        self.ax.add_patch(Circle((x,y),4.5,fc=WHITE,ec=color,lw=1,zorder=3))
        self.text(x,y-.2,'+',14,color,zorder=4)
    def mux(self,x,y,w,h,label,color=INK):
        self.ax.add_patch(Polygon([(x-w/2,y-h/2),(x+w/2,y-h/2),
                                  (x+w*.34,y+h/2),(x-w*.34,y+h/2)],
                                 closed=True,fc=WHITE,ec=color,lw=.9,zorder=3))
        self.text(x,y,label,8.4,color,True,zorder=4)
    def save(self):
        self.fig.canvas.draw();renderer=self.fig.canvas.get_renderer()
        outside=[];node_overflows=[]
        for t,role in self.texts:
            b=t.get_window_extent(renderer)
            if b.x0<0 or b.y0<0 or b.x1>self.fig.bbox.width or b.y1>self.fig.bbox.height:
                outside.append(t.get_text())
        for x,y,w,h,labels in self.nodes:
            a=self.ax.transData.transform((x+.8,y+.4));b=self.ax.transData.transform((x+w-.8,y+h-.4))
            for t in labels:
                box=t.get_window_extent(renderer)
                if box.x0<a[0] or box.x1>b[0] or box.y0<b[1] or box.y1>a[1]:node_overflows.append(t.get_text())
        assert not outside,(self.name,outside)
        assert not node_overflows,(self.name,node_overflows)
        for ext in ['png','pdf','svg']:
            self.fig.savefig(OUT/f'{self.name}.{ext}',dpi=DPI)
        image=Image.open(OUT/f'{self.name}.png');ImageOps.grayscale(image).save(ROOT/f'{self.name}_grayscale.png')
        fonts={}
        for pg in PdfReader(OUT/f'{self.name}.pdf').pages:
            for v in pg['/Resources']['/Font'].values():
                f=v.get_object();ds=f.get('/DescendantFonts');f2=ds[0].get_object() if ds else f
                fd=f2.get('/FontDescriptor');fd=fd.get_object() if fd else {}
                fonts[str(f.get('/BaseFont'))]=any(k in fd for k in ('/FontFile','/FontFile2','/FontFile3'))
        assert fonts and all(fonts.values()),fonts
        result={'width_mm':WIDTH,'height_mm':self.height,'dpi':DPI,'pixels':list(image.size),
                'outside_canvas':outside,'node_text_overflow':node_overflows,'embedded_fonts':fonts,
                'text': [t.get_text() for t,_ in self.texts],
                'files':{ext:hashlib.sha256((OUT/f'{self.name}.{ext}').read_bytes()).hexdigest() for ext in ['png','pdf','svg']}}
        plt.close(self.fig);return result

