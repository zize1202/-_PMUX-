"""One rule/result mapping shared by the full book and the short comparison."""
def requirement_rows(snapshot):
    m=snapshot['metrics'];v=snapshot['candidate'];scope=snapshot['measurement_scope']
    core=[
      ['新增自定义Tcl命令，识别、拆解、重构PMUX（印刷第4页）','C24/C37/C53/C145：内置pass，在synth_intel调用；两臂同脚本','opt_pmux内置C++；proc后声明初态；coarse中、cmp2lut前重构。source与构建清单','保持read_verilog;synth_intel外部接口；非外部候选择优或后ABC9重写'],
      ['技术缩减≥10%；面积评分满档门槛≥20%（第5页）','C25/C67/C115/C130/C150：九例LUT+NOT缩减率算术平均，逐例不增',f"{m['mean_area_percent']:.4f}%；{m['baseline_sum']}→{m['optimized_sum']}；逐例不增：{'是' if m['all_nonincrease'] else '否'}。performance与binding",f"{m['individual_at_least_20_count']}/9例单独≥20%；加权{m['weighted_percent']:.4f}%另列"],
      ['全部用例形式等价；任一不等价影响功能及其他计分（第5页）','C54：ABC后ILANG；C149.2：按0初始化，完整EQY PASS',f'{v}：原RTL逻辑零初态→实际候选端点，9/9完整PASS；配置与端点哈希绑定','显式0/1保持；不是任意初态全集等价。旧默认基线test4严格失败未被改写'],
      ['≤1000节点内完成优化≤60s、峰值≤2GB；效率5%/15%条款（第5页）','C92/C133/C134/C147：墙钟与主进程峰值同次采集；C145展示读取及综合命令',f"{scope['short']}：最长{m['max_optimized_wall_seconds']:.6f}s；最大{m['max_optimized_peak_ws_bytes']:.0f}字节；最大时间比{m['max_time_ratio']:.6f}、内存比{m['max_memory_ratio']:.6f}",'初测/触发后五对均值；v2/v3范围分列；九例不覆盖所有千节点电路']]
    other=[
      ['混合组合PMUX、标准Verilog用例（第4—5页）','C146/C147/C150：原4例+新增5例，默认参数','原始字节及默认参数冻结；清单、资源和证明逐例关联','不向任意参数、设计和器件外推'],
      ['参考EQ6HL130P；通用说明含eLinx编译仿真、无硬件（第4、6页）','C66/C71：选题二无需eLinx或板卡；C145：Cyclone IV流程','统一synth_intel -family cycloneiv；ModelSim作功能观察补充','有限仿真不替代EQY；无布局布线时序或上板结论'],
      ['设计文档5分；现场答辩15分（第5、6页）','仍由评审及现场综合判断','提供原理、架构、源码、逐例证据和复现入口','不以脚本计算100分或预测奖项']]
    scale=snapshot.get('supplemental_scale')
    if scale:
        core[3][2]+=f"；独立{scale['baseline_actual_nodes']}→{scale['optimized_actual_nodes']}叶单元样例及完整EQY通过"
        core[3][3]='规模实测不入九例平均；一个界限内实例不能覆盖所有千节点电路；v2/v3分列'
    build_evidence=('原生构建、安装退出0；冻结EXE与manifest/build.log绑定；正式九例综合日志均成功'
                    if snapshot.get('native_build') else '当前原生构建记录待绑定；正式九例综合日志见performance')
    if snapshot.get('current_migration_all_qa'):build_evidence+='；当前候选迁移All九例通过'
    elif snapshot.get('migration_all_qa'):build_evidence+='；'+snapshot.get('historical_migration_evidence_candidate',snapshot.get('migration_evidence_candidate','历史'))+'迁移All九例通过'
    core.append(['无编译、运行报错（第5页）','按原题检查程序构建与实际运行；完整EQY另列',build_evidence,
                 '不以EQY代替编译/运行检查；旧迁移4例路径ERROR保留，修复后另起完整批次'])
    return core,other

def brief_requirement_rows(snapshot):
    """Compact review map; detailed wording and citations stay in the main book."""
    m=snapshot['metrics'];scale=snapshot.get('supplemental_scale')
    return [
      ['内置命令与默认流程\n原题p4；C24/C145','opt_pmux内置C++；proc后声明初态，coarse阶段重构。证据：源码与构建日志','两臂同脚本、原源默认参数；标准pass和ABC保持'],
      ['面积≥10%；满档门槛≥20%\np5；C25/C130/C150',f"九例均不增；等权均值{m['mean_area_percent']:.4f}%；总量{m['baseline_sum']}→{m['optimized_sum']}",f"{m['individual_at_least_20_count']}/9例单独≥20%；加权{m['weighted_percent']:.4f}%另算"],
      ['完整形式等价\np5；C54/C149.2','原RTL逻辑零初态→实际候选：9/9完整EQY PASS，源与端点SHA绑定','显式初值保持；非任意初态等价；旧基线test4反例保留'],
      ['≤60s/2GB及逐例5%效率\np5；C92/C147',f"最长{m['max_optimized_wall_seconds']:.6f}s，最大{m['max_optimized_peak_ws_bytes']:.0f}字节；最大时间比{m['max_time_ratio']:.4f}、内存比{m['max_memory_ratio']:.4f}",'v3两命令完整进程；同次主进程峰值；逐例见次页'],
      ['无编译、运行报错\np5','原生构建/安装退出0；正式九例综合成功。构建及运行日志独立核验','不以EQY代替运行检查；历史路径错误及修复记录保留'],
      ['千节点范围与器件平台\np5—6；C66/C71/C145',(f"独立{scale['baseline_actual_nodes']}→{scale['optimized_actual_nodes']}叶单元，完整EQY PASS；" if scale else '')+'Cyclone IV；选题二无需板卡','规模样例不入九例均值，不覆盖全部千节点工程'],
      ['文档5分、答辩15分\np5—6','项目书、源码、原始证据和复现入口分别提供','由评审认定；不自动计算主观满分或奖项']]
