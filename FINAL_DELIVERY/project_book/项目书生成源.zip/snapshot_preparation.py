"""Save an immutable preparation snapshot; no document compilation or rendering."""
from pathlib import Path
import argparse, hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--name',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--output-dir');args=ap.parse_args()
    if not args.name.replace('_','').isalnum():raise ValueError('Use an ASCII snapshot name')
    config=json.loads((ROOT/'release_config.json').read_text(encoding='utf-8'))
    assert config['candidate']==args.candidate and config['phase']=='draft_unfrozen'
    output=Path(args.output_dir) if args.output_dir else ROOT/'checkpoints';output.mkdir(parents=True,exist_ok=True)
    dest=output/(args.name+'.zip');meta=dest.with_suffix('.json')
    if dest.exists() or meta.exists():raise FileExistsError('Snapshots are never overwritten')
    old={p:sha(p) for p in (ROOT/'checkpoints').glob('*.zip')}
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and 'checkpoints' not in p.relative_to(ROOT).parts and '__pycache__' not in p.parts and p.suffix!='.pyc']
    index=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)} for p in files]
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
        for p in files:archive.write(p,p.relative_to(ROOT).as_posix())
        archive.writestr('SNAPSHOT_INDEX.json',json.dumps(index,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(dest) as archive:
        for item in index:assert hashlib.sha256(archive.read(item['path'])).hexdigest()==item['sha256']
    assert all(sha(p)==digest for p,digest in old.items())
    result={'candidate':args.candidate,'archive':str(dest),'sha256':sha(dest),'files':len(index),'not_final':True,'older_archives_unchanged':True}
    meta.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
