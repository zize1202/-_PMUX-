"""Copy reviewed current-checkpoint figures and derive notes; no plotting or publication."""
from pathlib import Path
import json, hashlib, shutil
from book_settings import ROOT, CONFIG, CONFIG_PATH
from vcd_evidence import VCDReader

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
    d=json.loads((ROOT/'evidence_snapshot.json').read_text(encoding='utf-8'))
    assert d['configuration_sha256']==digest(CONFIG_PATH)
    assert d['modelsim'] and CONFIG['use_checkpoint_wave_assets']
    source=Path(d['sources']['modelsim']['path']).parent
    cases={c['id']:c for c in d['modelsim']['cases']};qa=[]
    t=VCDReader('test4',cases,source,qa,sample_scope='prelude');b=VCDReader('pmux_case01_balanced',cases,source,qa)
    initial=json.loads((source/'initialization_figure/FIGURE_AUDIT.json').read_text(encoding='utf-8'))
    balanced=json.loads((source/'balanced_figures/FIGURE_AUDIT.json').read_text(encoding='utf-8'))
    assert initial['contract']['candidate_label']==balanced['checkpoint']==d['candidate']
    assert d['candidate'] in balanced['contract']['claim'],'Figure audit must name the actual bound candidate.'
    assert initial['shown_vcd_csv_points_match'] and balanced['all_output_values_match_csv']
    assert initial['visual_review']['passed'] and balanced['visual_review']['passed']
    for audit,case in [(initial,t),(balanced,b)]:
        assert audit['vcd_sha256']==digest(source/case.identifier/'simulation.vcd')
        assert audit['csv_sha256']==digest(source/case.identifier/'samples.csv')
        assert audit['candidate_json_sha256']==case.meta['candidate']['source_sha256']
    out=ROOT/'figures';out.mkdir(exist_ok=True);files=[]
    asset_stems=[('initialization_figure/test4_logical_zero','modelsim_zero_init'),('balanced_figures/detail','modelsim_zero_detail'),('balanced_figures/end','modelsim_zero_finish')]
    if d.get('observable_waveform'):asset_stems.append(('test3_observable_figure/test3_observable','modelsim_observable'))
    if d.get('sampling_waveform'):
        asset_stems += [('balanced_figures/overview','modelsim_zero_overview'),('pipeline_boundary_figure/pipeline_sampling_boundary','modelsim_sampling_boundary')]
    if d.get('simulation_model_scope',{}).get('sload_waveform'):
        asset_stems.append(('sload_selection_figure/sload_selection','modelsim_sload_selection'))
    for source_stem,stem in asset_stems:
        for ext in ['png','svg','pdf']:
            original=source/f'{source_stem}.{ext}';target=out/f'{stem}.{ext}'
            shutil.copyfile(original,target);assert digest(original)==digest(target)
            files.append({'source':str(original),'target':str(target),'sha256':digest(target)})
    lo,hi=balanced['windows_ns']['detail'];observed=[]
    for row in b.rows:
        if lo<=int(row['time_ps'])/1000<=hi and (not observed or observed[-1]!=row['candidate_hex']):observed.append(row['candidate_hex'])
    rst_fall=next(x for x,v in b.traces['rst'] if x>b.meta['vector_schedule_start_ns'] and v==0)
    notes={'candidate':d['candidate'],'source_report_sha256':d['sources']['modelsim']['sha256'],'paragraphs':[
        f"图8的1、5ns采样时reset_n=1、clk=0，两侧only_5b=0；11、15ns仅断言异步低复位，两侧为1；21、25ns释放复位而尚无时钟边沿，输出保持1。正常向量从{t.meta['vector_schedule_start_ns']}ns开始，首个边沿为{t.meta['first_clock_edge_ns']}ns。复位后输出1不能被误读为逻辑零初态。test4独立重放的4092条CSV与原次逐字节一致。",
        f"图9为{lo}—{hi}ns局部窗口，balanced于{rst_fall:g}ns撤销rst，采样输出依次为"+'、'.join(observed[:7])+"等。蓝色实线表示同逻辑零初态参考，橙色虚线表示当前候选；data_in仅展示原48位的低12位。",
        f"图10在{b.meta['finish_time_ns']}ns显示finished=1、failed=0、checked={b.meta['checked']}；两版末值均为{b.at('candidate_outputs',b.meta['finish_time_ns']):03X}。该例共{b.meta['cycles']}周期，seed={b.meta['seed']}。",
        f"三图来自{d['candidate']}当前ModelSim导出的真实VCD重绘，明确非GUI截图。图8所示6个隔离采样点及balanced全部{b.meta['checked']}条采样输出已再次与VCD核对。test4其他周期边界可能先采样再更新异步复位，同时间戳VCD末值不必等于较早delta的CSV值；判错采用CSV有效采样。参考侧不是原默认面积基线。"],
        'brief_figure':'modelsim_zero_init.png','brief_caption':'图1  当前test4真实VCD初态窗口（非GUI截图）',
        'brief_reading':f"未复位且无边沿时，两侧only_5b为0；仅施加异步低复位时变为1，释放复位后保持1。六个采样点与激励隔离，正常向量从{t.meta['vector_schedule_start_ns']}ns开始、首个时钟边沿为{t.meta['first_clock_edge_ns']}ns。参考侧为源逻辑零契约下的映射模型。"}
    if d.get('observable_waveform'):
        caption=Path(d['sources']['observable_caption']['path']).read_text(encoding='utf-8').strip()
        # Preserve the independently reviewed claim and its event/sampling qualifications.
        left,right=caption.split('完整记录中的',1)
        notes['observable_paragraphs']=[left,'完整记录中的'+right]
        notes['observable_source_caption_sha256']=d['sources']['observable_caption']['sha256']
    if d.get('sampling_waveform'):
        notes['paragraphs']=[p.replace('图9','图10').replace('图10在','图11在').replace('三图来自','图8—11来自') for p in notes['paragraphs']]
        notes['overview_paragraph']=f"图9覆盖0—{b.meta['stop_time_ns']}ns，显示初态、复位、定向激励与固定seed随机激励的先后阶段；checked最终为{b.meta['checked']}，failed与unknown保持0，finished在{b.meta['finish_time_ns']}ns置1。该全程图用于定位记录范围，不能从压缩时间轴推断所有瞬态。"
        caption=Path(d['sources']['sampling_caption']['path']).read_text(encoding='utf-8').strip()
        left,right=caption.split('全程',1)
        notes['sampling_paragraphs']=[left,'全程'+right]
        notes['sampling_source_caption_sha256']=d['sources']['sampling_caption']['sha256']
    if d.get('simulation_model_scope',{}).get('sload_waveform'):
        caption=Path(d['sources']['sload_caption']['path']).read_text(encoding='utf-8').strip()
        left,right=caption.split('全程',1)
        notes['sload_paragraphs']=[left,'全程'+right]
        notes['sload_source_caption_sha256']=d['sources']['sload_caption']['sha256']
    (ROOT/'current_wave_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'CURRENT_WAVEFORM_QA.json').write_text(json.dumps({'candidate':d['candidate'],'source':'real ModelSim VCD, not GUI screenshot','status':'PASS_CHECKPOINT_ASSET_BINDING','cases':qa,'assets':files,'rendered_new_figures':False,'same_timestamp_policy':'last VCD record at timestamp; pass/fail at CSV samples'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'candidate':d['candidate'],'verified_samples':sum(x['csv_samples_verified'] for x in qa),'copied_current_assets':len(files),'new_render':False},ensure_ascii=False))

if __name__=='__main__':prepare()
