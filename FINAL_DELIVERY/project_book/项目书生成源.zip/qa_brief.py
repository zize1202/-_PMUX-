from book_settings import require_render, OUTPUT
require_render()
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from pypdf import PdfReader
import pypdfium2 as pdfium
from PIL import Image,ImageDraw
import json,re,hashlib,sys
sys.stdout.reconfigure(encoding='utf-8')
from brief_content import blocks
R=Path(__file__).resolve().parent;O=OUTPUT;N='原题要求与当前结果对照'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def norm(t):return re.sub(r'\s+','',t).replace('−','-').replace('\ufffe','')
expected=[]
for b in blocks:
 if b['kind']=='pagebreak':continue
 expected.append(b['text'])
 if b['kind']=='table':expected.extend(b['headers']+[v for row in b['rows'] for v in row])
with ZipFile(O/(N+'.docx')) as z:
 d=E.fromstring(z.read('word/document.xml'));txt=norm(''.join(d.xpath('//w:t/text()',namespaces=ns)))
 assert all(norm(t) in txt for t in expected)
 tables=d.xpath('//w:tbl',namespaces=ns);assert len(tables)==2
 for table in tables:
  b={E.QName(e).localname:e.get('{'+ns['w']+'}val') for e in table.find('w:tblPr/w:tblBorders',ns)}
  assert all(b[x]=='nil' for x in ['left','right','insideH','insideV'])
  assert b['top']==b['bottom']=='single'
  assert all(c.find('w:tcPr/w:tcBorders/w:bottom',ns).get('{'+ns['w']+'}val')=='single' for c in table.xpath('./w:tr[1]/w:tc',namespaces=ns))
pdf=O/(N+'.pdf');doc=pdfium.PdfDocument(str(pdf));out=R/'render_brief';out.mkdir(exist_ok=True);texts=[]
for i,pg in enumerate(doc):
 t=pg.get_textpage().get_text_range();t=re.sub(r'^'+str(i+1)+r'\r?\n','',t);t=re.sub(r'\r?\n'+str(i+1)+r'\s*$','',t);texts.append(t)
 pg.render(scale=1.5).to_pil().save(out/f'page-{i+1:02}.png')
missing=[s for s in expected if norm(s) not in norm('\n'.join(texts))]
sheet=Image.new('RGB',(600*len(doc),850),'#dddddd');dr=ImageDraw.Draw(sheet)
for i in range(len(doc)):
 im=Image.open(out/f'page-{i+1:02}.png');im.thumbnail((580,810));sheet.paste(im,(i*600+10,25));dr.text((i*600+10,5),f'page {i+1}',fill='black')
sheet.save(out/'contact.jpg',quality=94)
fonts={}
for pg in PdfReader(pdf).pages:
 for v in pg.get('/Resources',{}).get('/Font',{}).values():
  f=v.get_object();ds=f.get('/DescendantFonts');f2=ds[0].get_object() if ds else f;fd=f2.get('/FontDescriptor');fd=fd.get_object() if fd else {}
  fonts[str(f.get('/BaseFont'))]=any(k in fd for k in ['/FontFile','/FontFile2','/FontFile3'])
report={'pages':len(doc),'target_pages':[2,3],'missing_text':missing,'all_tables_three_line':True,'fonts':fonts,'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'status':'PASS' if not missing and all(fonts.values()) and 2<=len(doc)<=3 else 'REVIEW'}
(R/'BRIEF_STRUCTURAL_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
