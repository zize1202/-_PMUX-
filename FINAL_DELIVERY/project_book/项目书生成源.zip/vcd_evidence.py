"""Read actual VCD events and cross-check sampled CSV values; no plotting."""
from pathlib import Path
import csv,re,bisect,hashlib

class VCDReader:
 def __init__(self,identifier,case_metadata,source_root,audit,sample_scope='all'):
  self.identifier=identifier;self.meta=case_metadata[identifier];folder=source_root/identifier
  data=(folder/'simulation.vcd').read_text(encoding='ascii');assert re.search(r'\$timescale\s+1ps\s+\$end',data)
  groups={};values={};scope=[];codes={};time=0;started=False;self.traces={}
  wanted={'clk','rst','reset_n','en','ena','ctrl_in','data_in','reference_outputs','candidate_outputs','reference_only_5b','candidate_only_5b','checked','failed','finished','mismatch','unknown_output','contract_failed'}
  def decode(name):
   entries=groups[name]
   if len(entries)==1 and entries[0][1] is None:
    v=values.get(entries[0][0],'x');return None if re.search('[xz]',v,re.I) else int(v,2)
   result=0
   for code,bit in entries:
    v=values.get(code,'x')
    if re.search('[xz]',v,re.I):return None
    result|=int(v,2)<<bit
   return result
  def flush():
   for name in groups:
    value=decode(name);trace=self.traces.setdefault(name,[])
    if not trace or trace[-1][1]!=value:trace.append((time/1000,value))
  for raw in data.splitlines():
   line=raw.strip()
   if not started:
    if line.startswith('$scope'):scope.append(line.split()[2])
    elif line.startswith('$upscope'):scope.pop()
    elif line.startswith('$var') and len(scope)==1:
     a=line.split();code=a[3];name=a[4]
     if name in wanted:
      bit=int(a[5].strip('[]')) if len(a)>6 and ':' not in a[5] else None
      groups.setdefault(name,[]).append((code,bit));codes[code]=name
    elif line.startswith('$enddefinitions'):started=True
    continue
   if line.startswith('#'):flush();time=int(line[1:])
   elif line and line[0] in 'bB':
    v,code=line[1:].split()
    if code in codes:values[code]=v
   elif line and line[0] in '01xXzZ' and line[1:] in codes:values[line[1:]]=line[0]
  flush()
  self.rows=list(csv.DictReader((folder/'samples.csv').open(encoding='utf-8')))
  assert len(self.rows)==self.meta['checked']
  assert sample_scope in ['all','prelude']
  shown=self.rows if sample_scope=='all' else self.meta['prelude_samples']
  for row in self.rows:
   assert int(row['mismatch'])==int(row['unknown_output'])==int(row['contract_failed'])==0
  for row in shown:
   t=int(row['time_ps'])/1000
   assert self.at('reference_outputs',t)==int(row['reference_hex'],16),(identifier,t,self.at('reference_outputs',t),row['reference_hex'],self.traces['reference_outputs'][:5])
   assert self.at('candidate_outputs',t)==int(row['candidate_hex'],16)
   assert int(row['mismatch'])==int(row['unknown_output'])==int(row['contract_failed'])==0
  t=self.meta['finish_time_ns']
  assert self.at('checked',t)==self.meta['checked'] and self.at('failed',t)==0 and self.at('finished',t)==1
  audit.append({'case':identifier,'csv_samples_verified':len(shown),'csv_samples_total':len(self.rows),'sample_scope':sample_scope,'selected_outputs_match_csv':True,'vcd_sha256':hashlib.sha256((folder/'simulation.vcd').read_bytes()).hexdigest(),'csv_sha256':hashlib.sha256((folder/'samples.csv').read_bytes()).hexdigest()})
 def at(self,name,t):
  trace=self.traces[name];index=bisect.bisect_right([x[0] for x in trace],t)-1
  return None if index<0 else trace[index][1]
 def segments(self,name,lo,hi):
  start=lo;value=self.at(name,lo)
  for t,new in self.traces[name]:
   if lo<t<hi:yield start,t,value;start=t;value=new
  yield start,hi,value
 def low12(self):
  self.traces['data_low12']=[]
  for t,v in self.traces['data_in']:
   value=None if v is None else v&0xfff;trace=self.traces['data_low12']
   if not trace or trace[-1][1]!=value:trace.append((t,value))
