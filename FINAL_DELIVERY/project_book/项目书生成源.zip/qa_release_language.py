"""Check draft/release prose in memory; never freeze or compile a document."""
from pathlib import Path
from unittest.mock import patch
import copy,hashlib,json,runpy,sys
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root))
ep=root/'evidence_snapshot.json';original=Path.read_text
snapshot=json.loads(original(ep,encoding='utf-8'));before=hashlib.sha256(ep.read_bytes()).hexdigest()
def load(data):
    def reader(path,*args,**kwargs):
        return json.dumps(data,ensure_ascii=False) if path.resolve()==ep.resolve() else original(path,*args,**kwargs)
    with patch.object(Path,'read_text',reader):return runpy.run_path(str(root/'content.py'),run_name='language_check')
draft_snapshot=copy.deepcopy(snapshot);draft_snapshot['release_ready']=False;draft=load(draft_snapshot);candidate=copy.deepcopy(snapshot);candidate['release_ready']=True;final=load(candidate)
joined='\n'.join(b['text'] for b in final['blocks'])
for phrase in ['工作稿','准备稿','冻结前可更换','最终发布应','发布时必须','最终图必须','尚待单独绑定']:
    assert phrase not in joined,phrase
for phrase in ['C149','未指定','旧默认','非GUI','无zinit','ERROR']:
    assert phrase in joined,phrase
rejected=[]
for key,value in [('modelsim',None),('candidate_side_normalization_has_zinit',True),('native_build',None)]:
    invalid=copy.deepcopy(candidate);invalid[key]=value
    try:load(invalid)
    except AssertionError:rejected.append(key)
    else:raise AssertionError('Release branch accepted missing evidence: '+key)
assert hashlib.sha256(ep.read_bytes()).hexdigest()==before
qa={'status':'PASS_TEXT_GATING_ONLY','candidate':snapshot['candidate'],'draft_notice_preserved':any('工作稿' in b['text'] for b in draft['blocks']),
    'in_memory_release_branch_checked':True,'final_internal_workflow_phrases_found':[],
    'specific_limitations_preserved':True,'missing_evidence_release_branches_rejected':rejected,
    'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['content.py','brief_content.py','requirements.py','prepare_text_sources.py']},
    'release_ready_on_disk':snapshot['release_ready'],'configuration_and_evidence_snapshot_not_modified':True,'render_or_synthesis_or_measurement_run':False}
(root/'RELEASE_LANGUAGE_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':qa['status'],'candidate':qa['candidate']}))
