"""State-transition-preserving PMUX sampling-boundary method, qualified at r28."""
def add_section(p,sub,eq,table,cases,development):
    sub('2.3.6  PMUX采样边界的同步复位与使能重述')
    p('只整理组合数据树仍可能留下由保持行为形成的反馈选择。厂商指南指出，专用寄存器控制按异步清零、使能、同步清零、同步装载、数据的顺序生效；当RTL把同步复位放在使能之前时，综合可能用数据路径逻辑实现使能[10]。该说明提示表示方式会影响硬件控制端的利用，但并不保证某次Yosys改写必然节省LUT；本项目另以实际网表和完整证明核验。')
    p('本规则只识别私有完整PMUX输出连接到正沿、正使能、正同步复位且复位值全0的$sdffe。令R为原同步复位、E为原使能，D与Q分别为输入和当前状态，其上升沿转移为：')
    eq('Q′=R?0:(E?D:Q)',r'Q^{\prime}=R\ ?\ 0:(E\ ?\ D:Q)')
    p('此重述阶段保持同一FF对象及D、Q、CLK、SRST、参数、属性和线网初值，只把类型重述为使能优先的$sdffce，并令新使能E′=E∨R。新转移写为：')
    eq('E′=E OR R；Q′=E′?(R?0:D):Q',r'E^{\prime}=E\lor R,\qquad Q^{\prime}=E^{\prime}\ ?\ (R\ ?\ 0:D):Q')
    table('表3b  任意二值D、Q下的控制分解',['R','E','E′','两种表示的下一状态'],[
        ['1','任意','1','0：复位不被外部使能屏蔽'],['0','1','1','D：正常采样'],['0','0','0','Q：保持当前状态']],[1.7,2.0,2.0,8.95])
    p('R=1时新使能必为1，R=0时新使能等于原E，因此三行覆盖全部二值控制组合与任意当前Q、D。该规则不移动时钟边沿、不插入流水级，也不改变源初态契约；结论限于此同步状态转移，不宣称未知控制下的任意四态事件调度等价。标准kernel/ff.cc中的convert_ce_over_srst已有同类控制恒等式；当前实现只在自定义pass的PMUX边界内选择结构，标准FF处理、dfflegalize和ABC均保持原样。')
    p('守卫逐项检查所有消费者，要求每个完整D端与PMUX.Y同序相连；其他读取端、公共Y输出、保护对象或别名、驱动冲突、缺失连接、非零或未知复位、负/非法极性及不支持FF均拒绝。Q可作为原有公开输出。宽度与PMUX臂数各限1—64，单根最多8个FF消费者；每模块最多保存64个候选、改写32个FF，整个设计最多检查128根、改写64个FF。全部只读计划完成后再提交，避免改写使已有消费者索引失效；相同控制对共享一个OR。')
    p(f"r28开发记录共36项：{development['positive_next_state_sat']}个正例覆盖宽度1、3、64及两个完整FF消费者，对实际改写后网络进行任意前态Q、自由原输入的下一状态SAT证明；{development['negative_unchanged']}个拒绝例与冻结r23输出JSON相同。另1项非法极性参数为2时未发生改写，进程以3221225725（0xC00000FD）退出，崩溃记录保留，不列为合法设计运行成功或完整等价通过。原对象、非EN端口、参数、属性和init另行逐项核对。")
    c=next(x for x in cases if x['id']=='pmux_case02_pipeline')
    p(f"r28生产pipeline为{c['baseline_cells']['logic_units']}→{development['native_pipeline_logic']}个LUT+NOT，较r23的{development['prior_pipeline_logic']}再少{development['prior_pipeline_logic']-development['native_pipeline_logic']}个，DFF仍为24。实际命中{development['native_rewritten_ff_objects']}个三位FF对象；其最终24个dffeas共用非恒定ENA，驱动LUT的四种控制赋值逐项满足ENA=en∨rst。r28的SCLR仍接0，只能说明保持控制转到实际硬件使能端。后续目标专用映射与当期完整端点另行核验，不把旧开发记录改名为新运行，也不把单例减少量推广为普遍收益。")
    p('FAQ C34答复以最终网表效果评价其他优化方法[2]。本策略位于自定义pass的PMUX—FF采样边界，在分支常量传播之后、优先链与控制恢复之前执行；没有改动其他标准pass或依赖程序。该答复并未点名批准这一具体FF重述，C149.1的歧义仍保留。第3.3.1节仅用一个已核实对应输出位的真实有限波形解释保持与复位过程，整设计结论来自源逻辑零到实际端点的完整EQY。')
