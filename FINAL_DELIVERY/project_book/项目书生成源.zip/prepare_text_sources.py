"""Export human-readable Word/common manuscript text without compiling documents."""
import json
from pathlib import Path
import content, brief_content

def export(name, blocks):
    target=content.R/'prepared_text';target.mkdir(exist_ok=True)
    status='冻结版本；与Word/LaTeX共用内容源。' if content.D['release_ready'] else '准备稿，非最终发布；与Word/LaTeX共用内容源。'
    text=[status, '绑定候选：'+content.V, '']
    for block in blocks:
        text.append(block['text'])
        if block['kind']=='table':
            text.append('\t'.join(block['headers']))
            text.extend('\t'.join(row) for row in block['rows'])
        elif block['kind']=='equation':text.append(block['tex'])
        elif block['kind']=='figure':text.append('图源：'+str(content.R/'figures'/block['file']))
        text.append('')
    (target/(name+'.txt')).write_text('\n'.join(text),encoding='utf-8')

export('项目书共同正文',content.blocks)
export('原题结果对照共同正文',brief_content.blocks)
(content.R/'brief_content.json').write_text(json.dumps(brief_content.blocks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'candidate':content.V,'main_blocks':len(content.blocks),'brief_blocks':len(brief_content.blocks),'document_compilation':False},ensure_ascii=False))
